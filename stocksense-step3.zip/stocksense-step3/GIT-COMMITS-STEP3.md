# StockSense — Step 3 Git Commits Guide

This document outlines the recommended conventional Git commits for **Step 3: Receipts (Incoming Stock), Delivery Orders (Outgoing Stock) & Real-Time Stock Engine**.

---

### Commit 1: Receipts Module (Incoming Stock)
- **Commit Message**:
  ```text
  feat(receipts): implement incoming stock receipts and atomic validation

  - Add Receipt API with supplier, warehouse, and multi-line item tracking
  - Build atomic validation endpoint: increases StockLevel, writes StockLedger record, and sets status to 'done'
  - Implement ReceiptsPage UI with status filters, search, modal creation, and drawer view
  - Emit Socket.io 'stock:update' and 'stock:updated' on validation
  ```
- **Files**:
  - `server/src/routes/receiptRoutes.js`
  - `client/src/pages/receipts/ReceiptsPage.jsx`

---

### Commit 2: Delivery Orders & Negative Stock Prevention
- **Commit Message**:
  ```text
  feat(deliveries): implement outgoing delivery orders with negative stock prevention

  - Add DeliveryOrder API with customer, warehouse, and picking/packing lifecycle
  - Pre-validate stock availability and strictly reject negative stock with HTTP 400
  - Decrement StockLevel, write negative StockLedger record, and emit live socket updates on validation
  - Implement DeliveryOrdersPage UI with per-line stock sufficiency indicator badges
  ```
- **Files**:
  - `server/src/routes/deliveryRoutes.js`
  - `client/src/pages/deliveries/DeliveryOrdersPage.jsx`

---

### Commit 3: Server Integration & Step 3 Full Loop Verification
- **Commit Message**:
  ```text
  chore(step3): mount receipt and delivery routes, add full loop integration test

  - Mount /api/receipts and /api/deliveries in server.js
  - Update socket.js to broadcast dual event contracts ('stock:update' and 'stock:updated')
  - Add testStep3.js verifying receipt validation (+50), negative stock block (670 units), and delivery deduction (-20)
  ```
- **Files**:
  - `server/src/server.js`
  - `server/src/socket.js`
  - `server/src/testStep3.js`

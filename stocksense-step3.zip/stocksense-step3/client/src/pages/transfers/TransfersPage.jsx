import React from 'react';
import { ArrowLeftRight, Plus, Building2, Layers } from 'lucide-react';

export default function TransfersPage() {
  const demoTransfers = [
    {
      id: 'TRF-2026-001',
      from: 'Main Central Warehouse (MW-01)',
      to: 'Production Assembly Floor (PF-01)',
      items: 'Steel Rods (25 kg)',
      status: 'waiting',
      date: '2026-09-26',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Internal Transfers
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
              Inter-facility
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Move stock between internal locations (e.g. Main Store &rarr; Production Rack). Total stock remains unchanged while location balances update.
          </p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white shadow-glow transition-all">
          <Plus className="w-4 h-4" />
          <span>New Transfer</span>
        </button>
      </div>

      {/* Info Card */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 bg-gradient-to-r from-cyan-950/30 via-slate-900 to-slate-900 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-200">
              Internal Stock Balancing
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Transfers log simultaneous transfer_out and transfer_in entries to the Stock Ledger.
            </p>
          </div>
        </div>
      </div>

      {/* Transfers Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-3 px-4 font-semibold">Transfer Ref</th>
                <th className="py-3 px-4 font-semibold">Source Location</th>
                <th className="py-3 px-4 font-semibold">Destination Location</th>
                <th className="py-3 px-4 font-semibold">Transfer Items</th>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {demoTransfers.map((t) => (
                <tr key={t.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-cyan-400">
                    {t.id}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {t.from}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {t.to}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-200">
                    {t.items}
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-mono">
                    {t.date}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

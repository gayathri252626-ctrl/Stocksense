import React from 'react';
import { SlidersHorizontal, Plus, Scale, AlertCircle } from 'lucide-react';

export default function AdjustmentsPage() {
  const demoAdjustments = [
    {
      id: 'ADJ-2026-001',
      product: 'Steel Rods (10mm x 3m)',
      warehouse: 'Main Central Warehouse (MW-01)',
      systemQty: 123,
      countedQty: 120,
      diff: -3,
      reason: 'Damaged during material handling',
      status: 'applied',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Stock Adjustments
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
              Audit & Count
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Reconcile physical inventory counts against system records. Automatically calculates diffs and records ledger adjustments.
          </p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-amber-600 hover:bg-amber-500 text-white shadow-glow transition-all">
          <Plus className="w-4 h-4" />
          <span>New Adjustment</span>
        </button>
      </div>

      {/* Info card */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 bg-gradient-to-r from-amber-950/30 via-slate-900 to-slate-900 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-200">
              Inventory Discrepancy Reconciliation
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Diff Formula: Counted Qty &minus; System Recorded Qty. When applied, StockLevel is synchronized immediately.
            </p>
          </div>
        </div>
      </div>

      {/* Adjustments Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-3 px-4 font-semibold">Adjustment #</th>
                <th className="py-3 px-4 font-semibold">Product</th>
                <th className="py-3 px-4 font-semibold">Location</th>
                <th className="py-3 px-4 font-semibold text-right">System Qty</th>
                <th className="py-3 px-4 font-semibold text-right">Counted Qty</th>
                <th className="py-3 px-4 font-semibold text-right">Difference</th>
                <th className="py-3 px-4 font-semibold">Reason</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {demoAdjustments.map((a) => (
                <tr key={a.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-amber-400">
                    {a.id}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-200">
                    {a.product}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {a.warehouse}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-400">
                    {a.systemQty}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-semibold text-slate-200">
                    {a.countedQty}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-400">
                    {a.diff}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {a.reason}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

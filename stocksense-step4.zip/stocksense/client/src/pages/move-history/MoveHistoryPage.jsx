import React, { useState, useEffect } from 'react';
import {
  History,
  Filter,
  Download,
  Search,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  SlidersHorizontal,
  RefreshCw,
  Calendar,
  Layers,
  Building2,
  Package,
} from 'lucide-react';
import api from '../../api/axios';
import { useSocket } from '../../context/SocketContext';

export default function MoveHistoryPage() {
  const [movements, setMovements] = useState([]);
  const [metrics, setMetrics] = useState({
    totalMovements: 0,
    totalInflow: 0,
    totalOutflow: 0,
    netDelta: 0,
  });
  const [products, setProducts] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [productFilter, setProductFilter] = useState('all');
  const [warehouseFilter, setWarehouseFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const socket = useSocket();

  // Fetch Ledger Movements
  const fetchLedger = async () => {
    try {
      setLoading(true);
      const [ledgerRes, prodRes, whRes] = await Promise.all([
        api.get('/ledger', {
          params: {
            search: search || undefined,
            productId: productFilter !== 'all' ? productFilter : undefined,
            warehouseId: warehouseFilter !== 'all' ? warehouseFilter : undefined,
            type: typeFilter !== 'all' ? typeFilter : undefined,
            startDate: startDate || undefined,
            endDate: endDate || undefined,
          },
        }),
        api.get('/products'),
        api.get('/warehouses'),
      ]);

      setMovements(ledgerRes.data.movements || []);
      setMetrics(
        ledgerRes.data.metrics || {
          totalMovements: 0,
          totalInflow: 0,
          totalOutflow: 0,
          netDelta: 0,
        }
      );
      setProducts(prodRes.data.products || []);
      setWarehouses(whRes.data.warehouses || []);
    } catch (err) {
      console.error('Failed to load ledger movements:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLedger();
  }, [productFilter, warehouseFilter, typeFilter, startDate, endDate]);

  // Live Socket.io Updates
  useEffect(() => {
    if (!socket) return;
    const handleUpdate = () => {
      fetchLedger();
    };
    socket.on('stock:update', handleUpdate);
    socket.on('stock:updated', handleUpdate);
    return () => {
      socket.off('stock:update', handleUpdate);
      socket.off('stock:updated', handleUpdate);
    };
  }, [socket, productFilter, warehouseFilter, typeFilter, startDate, endDate, search]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchLedger();
  };

  const handleClearFilters = () => {
    setSearch('');
    setProductFilter('all');
    setWarehouseFilter('all');
    setTypeFilter('all');
    setStartDate('');
    setEndDate('');
  };

  // Export CSV Function
  const handleExportCSV = () => {
    if (movements.length === 0) return;

    const headers = ['Timestamp', 'Type', 'Product Name', 'SKU', 'Warehouse Code', 'Warehouse Name', 'Quantity Change', 'Unit of Measure', 'Audit Notes'];
    const rows = movements.map((m) => [
      `"${new Date(m.timestamp).toISOString()}"`,
      `"${m.type}"`,
      `"${m.product?.name || ''}"`,
      `"${m.product?.sku || ''}"`,
      `"${m.warehouse?.code || ''}"`,
      `"${m.warehouse?.name || ''}"`,
      m.qtyChange,
      `"${m.product?.unitOfMeasure || 'pcs'}"`,
      `"${(m.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `stocksense_ledger_audit_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Type Badges Helper
  const renderTypeBadge = (type) => {
    switch (type) {
      case 'receipt':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <ArrowDownLeft className="w-3 h-3" /> Receipt (In)
          </span>
        );
      case 'delivery':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/30">
            <ArrowUpRight className="w-3 h-3" /> Delivery (Out)
          </span>
        );
      case 'transfer_out':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            <ArrowLeftRight className="w-3 h-3" /> Transfer (Out)
          </span>
        );
      case 'transfer_in':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/30">
            <ArrowLeftRight className="w-3 h-3" /> Transfer (In)
          </span>
        );
      case 'adjustment':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <SlidersHorizontal className="w-3 h-3" /> Adjustment
          </span>
        );
      case 'initial':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/30">
            <Layers className="w-3 h-3" /> Initial Baseline
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
            {type}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <History className="w-6 h-6 text-brand-400" />
              Stock Movement History
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 font-semibold border border-slate-700/60">
              Audit Ledger
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Complete, immutable chronological log of every inventory transaction: receipts, deliveries, internal transfers, and physical count adjustments.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          disabled={movements.length === 0}
          className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 shadow-sm disabled:opacity-50 transition"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Ledger CSV</span>
        </button>
      </div>

      {/* Audit KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Total Movements
          </span>
          <div className="text-2xl font-extrabold text-white mt-1">{metrics.totalMovements}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Recorded transactions</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
            Total Inflow (+)
          </span>
          <div className="text-2xl font-extrabold text-emerald-400 mt-1">
            +{metrics.totalInflow}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Receipts & incoming stock</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-rose-400 uppercase tracking-wider">
            Total Outflow (-)
          </span>
          <div className="text-2xl font-extrabold text-rose-400 mt-1">
            -{metrics.totalOutflow}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Deliveries & outgoing stock</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
            Net Inventory Delta
          </span>
          <div
            className={`text-2xl font-extrabold mt-1 ${
              metrics.netDelta >= 0 ? 'text-cyan-400' : 'text-rose-400'
            }`}
          >
            {metrics.netDelta >= 0 ? `+${metrics.netDelta}` : metrics.netDelta}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Net inventory balance change</div>
        </div>
      </div>

      {/* Multi-Dimensional Filter Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search SKU, product name, or notes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </form>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {/* Movement Type Filter */}
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Movement Types</option>
              <option value="receipt">Receipts (Incoming +)</option>
              <option value="delivery">Deliveries (Outgoing -)</option>
              <option value="transfer_out">Transfers (Origin -)</option>
              <option value="transfer_in">Transfers (Destination +)</option>
              <option value="adjustment">Stock Adjustments (Audit)</option>
              <option value="initial">Initial Baseline Registration</option>
            </select>

            {/* Warehouse Filter */}
            <select
              value={warehouseFilter}
              onChange={(e) => setWarehouseFilter(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Warehouses</option>
              {warehouses.map((w) => (
                <option key={w._id} value={w._id}>
                  {w.code} - {w.name}
                </option>
              ))}
            </select>

            {/* Product Filter */}
            <select
              value={productFilter}
              onChange={(e) => setProductFilter(e.target.value)}
              className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="all">All Products</option>
              {products.map((p) => (
                <option key={p._id} value={p._id}>
                  {p.name} ({p.sku})
                </option>
              ))}
            </select>

            <button
              onClick={fetchLedger}
              title="Refresh"
              className="p-2 bg-slate-900 border border-slate-700/80 rounded-xl text-slate-400 hover:text-white transition"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Date Range Sub-Bar */}
        <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>Date Range:</span>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2.5 py-1 bg-slate-900 border border-slate-700/80 rounded-lg text-xs text-slate-300 focus:outline-none"
            />
            <span>to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2.5 py-1 bg-slate-900 border border-slate-700/80 rounded-lg text-xs text-slate-300 focus:outline-none"
            />
          </div>

          {(startDate || endDate || productFilter !== 'all' || warehouseFilter !== 'all' || typeFilter !== 'all' || search) && (
            <button
              onClick={handleClearFilters}
              className="text-xs text-brand-400 hover:text-brand-300 font-semibold underline ml-auto"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Movements Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading ledger movements...</p>
          </div>
        ) : movements.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            No stock movements match the specified filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-semibold">Timestamp</th>
                  <th className="py-3 px-4 font-semibold">Movement Type</th>
                  <th className="py-3 px-4 font-semibold">Product Name & SKU</th>
                  <th className="py-3 px-4 font-semibold">Facility / Warehouse</th>
                  <th className="py-3 px-4 font-semibold text-right">Quantity Delta</th>
                  <th className="py-3 px-4 font-semibold">Audit Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {movements.map((m) => {
                  const isPositive = m.qtyChange > 0;
                  const isZero = m.qtyChange === 0;
                  return (
                    <tr key={m._id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4 text-slate-400 font-mono text-[11px] whitespace-nowrap">
                        {new Date(m.timestamp).toLocaleString()}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        {renderTypeBadge(m.type)}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-200">
                          {m.product?.name || 'Unknown Product'}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400">
                          SKU: {m.product?.sku || 'N/A'}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-slate-300 whitespace-nowrap">
                        <div className="font-semibold text-slate-200">
                          {m.warehouse?.code || '—'}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {m.warehouse?.name || '—'}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <span
                          className={`font-mono font-bold text-sm ${
                            isZero
                              ? 'text-slate-400'
                              : isPositive
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {isPositive ? `+${m.qtyChange}` : m.qtyChange}{' '}
                          <span className="text-[10px] font-normal text-slate-400">
                            {m.product?.unitOfMeasure || 'pcs'}
                          </span>
                        </span>
                      </td>

                      <td className="py-3 px-4 text-slate-300 text-xs max-w-sm">
                        {m.notes || '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

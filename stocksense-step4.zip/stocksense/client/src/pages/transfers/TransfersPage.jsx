import React, { useState, useEffect } from 'react';
import {
  ArrowLeftRight,
  Plus,
  Building2,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  X,
  Trash2,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  RefreshCw,
  Box,
} from 'lucide-react';
import api from '../../api/axios';
import { useSocket } from '../../context/SocketContext';

export default function TransfersPage() {
  const [transfers, setTransfers] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [fromFilter, setFromFilter] = useState('all');
  const [toFilter, setToFilter] = useState('all');

  // Modals & Drawers
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState('');
  const [actionSuccess, setActionSuccess] = useState('');

  // Form State
  const [fromWarehouse, setFromWarehouse] = useState('');
  const [toWarehouse, setToWarehouse] = useState('');
  const [notes, setNotes] = useState('');
  const [lines, setLines] = useState([{ product: '', qty: 1 }]);
  const [formError, setFormError] = useState('');
  const [formLoading, setFormLoading] = useState(false);

  const socket = useSocket();

  // Load Initial Data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [transfersRes, whRes, prodRes] = await Promise.all([
        api.get('/transfers', {
          params: {
            search: search || undefined,
            status: statusFilter !== 'all' ? statusFilter : undefined,
            fromWarehouse: fromFilter !== 'all' ? fromFilter : undefined,
            toWarehouse: toFilter !== 'all' ? toFilter : undefined,
          },
        }),
        api.get('/warehouses'),
        api.get('/products'),
      ]);

      setTransfers(transfersRes.data.transfers || []);
      setWarehouses(whRes.data.warehouses || []);
      setProducts(prodRes.data.products || []);
    } catch (err) {
      console.error('Failed to load transfers data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [statusFilter, fromFilter, toFilter]);

  // Live Socket.io Updates
  useEffect(() => {
    if (!socket) return;
    const handleUpdate = () => {
      fetchData();
    };
    socket.on('stock:update', handleUpdate);
    socket.on('stock:updated', handleUpdate);
    return () => {
      socket.off('stock:update', handleUpdate);
      socket.off('stock:updated', handleUpdate);
    };
  }, [socket, statusFilter, fromFilter, toFilter, search]);

  // Handle Search Debounce
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchData();
  };

  // Open Details Drawer
  const handleOpenDetails = async (id) => {
    try {
      setActionError('');
      setActionSuccess('');
      const res = await api.get(`/transfers/${id}`);
      setSelectedTransfer(res.data.transfer);
    } catch (err) {
      console.error('Failed to fetch transfer details:', err);
    }
  };

  // Add & Remove Line Items in Modal
  const addLine = () => setLines([...lines, { product: '', qty: 1 }]);
  const removeLine = (idx) => {
    if (lines.length > 1) {
      setLines(lines.filter((_, i) => i !== idx));
    }
  };
  const updateLine = (idx, field, value) => {
    const updated = [...lines];
    updated[idx][field] = value;
    setLines(updated);
  };

  // Get current stock for selected product at fromWarehouse in form
  const getFromStockHint = (prodId) => {
    if (!fromWarehouse || !prodId) return null;
    const prod = products.find((p) => p._id === prodId);
    if (!prod || !prod.stockPerWarehouse) return null;
    const whStock = prod.stockPerWarehouse.find(
      (sw) => (sw.warehouse?._id || sw.warehouse) === fromWarehouse
    );
    return whStock ? whStock.quantity : 0;
  };

  // Submit Create Transfer
  const handleCreateTransfer = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!fromWarehouse || !toWarehouse) {
      setFormError('Please select both origin and destination warehouses.');
      return;
    }
    if (fromWarehouse === toWarehouse) {
      setFormError('Origin and destination warehouses cannot be the same location.');
      return;
    }

    const validLines = lines.filter((l) => l.product && Number(l.qty) > 0);
    if (validLines.length === 0) {
      setFormError('Please add at least one line item with a valid product and quantity.');
      return;
    }

    try {
      setFormLoading(true);
      await api.post('/transfers', {
        fromWarehouse,
        toWarehouse,
        lines: validLines,
        notes,
        status: 'draft',
      });

      setShowCreateModal(false);
      setFromWarehouse('');
      setToWarehouse('');
      setNotes('');
      setLines([{ product: '', qty: 1 }]);
      fetchData();
    } catch (err) {
      setFormError(err.response?.data?.message || 'Failed to create transfer.');
    } finally {
      setFormLoading(false);
    }
  };

  // Validate Transfer Action
  const handleValidateTransfer = async (id) => {
    try {
      setActionLoading(true);
      setActionError('');
      setActionSuccess('');

      const res = await api.post(`/transfers/${id}/validate`);
      setActionSuccess(res.data.message || 'Transfer validated and stock relocated successfully!');

      // Refresh drawer details
      const updated = await api.get(`/transfers/${id}`);
      setSelectedTransfer(updated.data.transfer);

      fetchData();
    } catch (err) {
      setActionError(
        err.response?.data?.message || 'Validation failed. Check warehouse stock availability.'
      );
    } finally {
      setActionLoading(false);
    }
  };

  // Metrics
  const totalTransfersCount = transfers.length;
  const pendingCount = transfers.filter((t) => ['draft', 'waiting', 'ready'].includes(t.status)).length;
  const completedCount = transfers.filter((t) => t.status === 'done').length;
  const totalRelocatedUnits = transfers
    .filter((t) => t.status === 'done')
    .reduce((sum, t) => sum + (t.lines || []).reduce((lineSum, l) => lineSum + (l.qty || 0), 0), 0);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <ArrowLeftRight className="w-6 h-6 text-cyan-400" />
              Internal Transfers
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
              Inter-Facility
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Relocate stock between warehouses and staging bays. Total company inventory remains unchanged while location balances update atomically.
          </p>
        </div>

        <button
          onClick={() => {
            setFormError('');
            setShowCreateModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white shadow-glow transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Internal Transfer</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Total Transfers
          </span>
          <div className="text-2xl font-extrabold text-white mt-1">{totalTransfersCount}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Recorded in system</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
            Pending / In-Transit
          </span>
          <div className="text-2xl font-extrabold text-cyan-400 mt-1">{pendingCount}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Awaiting validation</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
            Completed Transfers
          </span>
          <div className="text-2xl font-extrabold text-emerald-400 mt-1">{completedCount}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Stock relocated & logged</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-indigo-400 uppercase tracking-wider">
            Total Units Relocated
          </span>
          <div className="text-2xl font-extrabold text-indigo-400 mt-1">{totalRelocatedUnits}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Balance shifted safely</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 flex flex-col md:flex-row gap-3 items-center justify-between">
        <form onSubmit={handleSearchSubmit} className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search transfer # or notes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
        </form>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          >
            <option value="all">All Statuses</option>
            <option value="draft">Draft</option>
            <option value="waiting">Waiting</option>
            <option value="ready">Ready</option>
            <option value="done">Done (Completed)</option>
            <option value="cancelled">Cancelled</option>
          </select>

          {/* From Warehouse Filter */}
          <select
            value={fromFilter}
            onChange={(e) => setFromFilter(e.target.value)}
            className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          >
            <option value="all">All Origin Locations</option>
            {warehouses.map((w) => (
              <option key={w._id} value={w._id}>
                From: {w.code} ({w.name})
              </option>
            ))}
          </select>

          {/* To Warehouse Filter */}
          <select
            value={toFilter}
            onChange={(e) => setToFilter(e.target.value)}
            className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          >
            <option value="all">All Destination Locations</option>
            {warehouses.map((w) => (
              <option key={w._id} value={w._id}>
                To: {w.code} ({w.name})
              </option>
            ))}
          </select>

          <button
            onClick={fetchData}
            title="Refresh"
            className="p-2 bg-slate-900 border border-slate-700/80 rounded-xl text-slate-400 hover:text-white transition"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Transfers Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading internal transfers...</p>
          </div>
        ) : transfers.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            No internal transfers match your search/filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-semibold">Transfer Reference</th>
                  <th className="py-3 px-4 font-semibold">Origin Facility</th>
                  <th className="py-3 px-4 font-semibold">Destination Facility</th>
                  <th className="py-3 px-4 font-semibold">Items</th>
                  <th className="py-3 px-4 font-semibold">Date Created</th>
                  <th className="py-3 px-4 font-semibold text-center">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {transfers.map((t) => {
                  const isDone = t.status === 'done';
                  const isCancelled = t.status === 'cancelled';
                  return (
                    <tr
                      key={t._id}
                      onClick={() => handleOpenDetails(t._id)}
                      className="hover:bg-slate-900/50 transition-colors cursor-pointer"
                    >
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-cyan-400">{t.transferNumber}</span>
                        {t.notes && (
                          <div className="text-[11px] text-slate-400 truncate max-w-xs">{t.notes}</div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-slate-300">
                        <div className="font-semibold text-slate-200">
                          {t.fromWarehouse?.code || '—'}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {t.fromWarehouse?.name || 'Unknown'}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-slate-300">
                        <div className="font-semibold text-slate-200">
                          {t.toWarehouse?.code || '—'}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {t.toWarehouse?.name || 'Unknown'}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-slate-300">
                        <span className="font-semibold text-white">{t.lines?.length || 0}</span> product(s)
                        <div className="text-[11px] text-slate-400">
                          Total {t.lines?.reduce((s, l) => s + (l.qty || 0), 0)} units
                        </div>
                      </td>

                      <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                        {new Date(t.createdAt).toLocaleDateString()}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider border ${
                            isDone
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : isCancelled
                              ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                              : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                          }`}
                        >
                          {t.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        {!isDone && !isCancelled ? (
                          <button
                            onClick={() => handleValidateTransfer(t._id)}
                            className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold shadow-sm transition"
                          >
                            Validate
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-400">
                            {isDone ? 'Validated' : 'Archived'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Details Drawer */}
      {selectedTransfer && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex justify-end">
          <div className="w-full max-w-2xl bg-slate-900 border-l border-slate-800 p-6 flex flex-col h-full overflow-y-auto animate-slide-left">
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white">
                    Transfer: {selectedTransfer.transferNumber}
                  </h2>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${
                      selectedTransfer.status === 'done'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : selectedTransfer.status === 'cancelled'
                        ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                        : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                    }`}
                  >
                    {selectedTransfer.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Created on {new Date(selectedTransfer.createdAt).toLocaleString()}
                </p>
              </div>

              <button
                onClick={() => setSelectedTransfer(null)}
                className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Notifications */}
            {actionError && (
              <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-400 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{actionError}</span>
              </div>
            )}
            {actionSuccess && (
              <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-emerald-400 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{actionSuccess}</span>
              </div>
            )}

            {/* Route Card */}
            <div className="mt-5 p-4 rounded-2xl border border-slate-800 bg-slate-950/60 flex items-center justify-between">
              <div className="flex-1">
                <span className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider">
                  Origin Location (From)
                </span>
                <div className="text-sm font-bold text-white mt-1">
                  {selectedTransfer.fromWarehouse?.name}
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Code: {selectedTransfer.fromWarehouse?.code}
                </div>
                <div className="text-[11px] text-slate-500">
                  {selectedTransfer.fromWarehouse?.location}
                </div>
              </div>

              <div className="px-4 text-cyan-400 flex flex-col items-center">
                <ArrowRight className="w-6 h-6 animate-pulse" />
                <span className="text-[10px] font-semibold mt-1">Transit</span>
              </div>

              <div className="flex-1 text-right">
                <span className="text-[10px] font-semibold text-emerald-400 uppercase tracking-wider">
                  Destination Location (To)
                </span>
                <div className="text-sm font-bold text-white mt-1">
                  {selectedTransfer.toWarehouse?.name}
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Code: {selectedTransfer.toWarehouse?.code}
                </div>
                <div className="text-[11px] text-slate-500">
                  {selectedTransfer.toWarehouse?.location}
                </div>
              </div>
            </div>

            {selectedTransfer.notes && (
              <div className="mt-4 p-3 bg-slate-950/40 rounded-xl border border-slate-800 text-xs text-slate-300">
                <span className="font-semibold text-slate-400 block mb-1">Notes:</span>
                {selectedTransfer.notes}
              </div>
            )}

            {/* Line Items with Stock Sufficiency */}
            <div className="mt-6 flex-1">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
                Transfer Line Items
              </h3>

              <div className="space-y-2">
                {(selectedTransfer.linesWithStock || selectedTransfer.lines || []).map((line, idx) => {
                  const prod = line.product || {};
                  const isSufficient = line.isSufficient !== undefined ? line.isSufficient : true;
                  return (
                    <div
                      key={idx}
                      className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-slate-200 text-xs">{prod.name}</div>
                        <div className="text-[11px] font-mono text-slate-400">SKU: {prod.sku}</div>
                        {selectedTransfer.status !== 'done' && line.currentFromStock !== undefined && (
                          <div className="text-[11px] mt-1 text-slate-400">
                            Available in {selectedTransfer.fromWarehouse?.code}:{' '}
                            <span className="font-mono font-semibold text-slate-200">
                              {line.currentFromStock} {prod.unitOfMeasure}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="text-right">
                        <div className="text-xs font-mono font-bold text-cyan-400">
                          Transfer: {line.qty} {prod.unitOfMeasure}
                        </div>
                        {selectedTransfer.status !== 'done' && (
                          <span
                            className={`inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-semibold border ${
                              isSufficient
                                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                                : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                            }`}
                          >
                            {isSufficient ? 'In Stock' : 'Insufficient Stock'}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Drawer Actions */}
            <div className="pt-4 border-t border-slate-800 mt-6 flex items-center justify-between gap-3">
              <button
                onClick={() => setSelectedTransfer(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
              >
                Close
              </button>

              {selectedTransfer.status !== 'done' && selectedTransfer.status !== 'cancelled' && (
                <button
                  disabled={actionLoading}
                  onClick={() => handleValidateTransfer(selectedTransfer._id)}
                  className="flex items-center gap-2 px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold shadow-glow disabled:opacity-50 transition"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{actionLoading ? 'Relocating Stock...' : 'Validate & Relocate Stock'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Transfer Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl animate-scale-up">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ArrowLeftRight className="w-5 h-5 text-cyan-400" />
                <h2 className="text-base font-bold text-white">Create Internal Stock Transfer</h2>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-400 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleCreateTransfer} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Origin Warehouse (From) *
                  </label>
                  <select
                    required
                    value={fromWarehouse}
                    onChange={(e) => setFromWarehouse(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  >
                    <option value="">Select Origin Location</option>
                    {warehouses.map((w) => (
                      <option key={w._id} value={w._id}>
                        {w.code} - {w.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Destination Warehouse (To) *
                  </label>
                  <select
                    required
                    value={toWarehouse}
                    onChange={(e) => setToWarehouse(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  >
                    <option value="">Select Destination Location</option>
                    {warehouses.map((w) => (
                      <option key={w._id} value={w._id} disabled={w._id === fromWarehouse}>
                        {w.code} - {w.name} {w._id === fromWarehouse ? '(Cannot be same)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Line Items */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-medium text-slate-300">Products to Relocate *</label>
                  <button
                    type="button"
                    onClick={addLine}
                    className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Product
                  </button>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {lines.map((line, idx) => {
                    const hintStock = getFromStockHint(line.product);
                    const isExceeding = hintStock !== null && Number(line.qty) > hintStock;
                    return (
                      <div
                        key={idx}
                        className="p-2.5 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center gap-2"
                      >
                        <div className="flex-1">
                          <select
                            required
                            value={line.product}
                            onChange={(e) => updateLine(idx, 'product', e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none"
                          >
                            <option value="">Select Product...</option>
                            {products.map((p) => (
                              <option key={p._id} value={p._id}>
                                {p.name} ({p.sku})
                              </option>
                            ))}
                          </select>
                          {hintStock !== null && (
                            <span className="text-[10px] text-slate-400 mt-1 block">
                              Available in source:{' '}
                              <span className="font-semibold text-slate-200">{hintStock} units</span>
                            </span>
                          )}
                        </div>

                        <div className="w-24">
                          <input
                            type="number"
                            min="1"
                            required
                            placeholder="Qty"
                            value={line.qty}
                            onChange={(e) => updateLine(idx, 'qty', e.target.value)}
                            className={`w-full px-2.5 py-1.5 bg-slate-900 border rounded-lg text-xs text-white focus:outline-none ${
                              isExceeding ? 'border-rose-500 text-rose-300' : 'border-slate-700'
                            }`}
                          />
                          {isExceeding && (
                            <span className="text-[10px] text-rose-400 font-semibold block mt-0.5">
                              Exceeds stock
                            </span>
                          )}
                        </div>

                        {lines.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeLine(idx)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Transfer Notes / Reason (Optional)
                </label>
                <textarea
                  rows="2"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Replenishment for assembly line production run"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formLoading}
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold shadow-glow disabled:opacity-50 transition"
                >
                  {formLoading ? 'Creating...' : 'Create Transfer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

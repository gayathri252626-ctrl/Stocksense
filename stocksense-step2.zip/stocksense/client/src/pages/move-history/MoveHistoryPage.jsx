import React, { useState, useEffect } from 'react';
import { History, Filter, Download, ArrowDownLeft, ArrowUpRight, ArrowLeftRight, SlidersHorizontal } from 'lucide-react';
import api from '../../api/axios';

export default function MoveHistoryPage() {
  const [movements, setMovements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovements = async () => {
      try {
        setLoading(true);
        const res = await api.get('/dashboard/stats');
        setMovements(res.data.recentMovements || []);
      } catch (err) {
        console.error('Failed to fetch history:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchMovements();
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Move History & Ledger
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-semibold border border-slate-700/60">
              Audit Trail
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Comprehensive immutable audit log of every stock movement: receipts, deliveries, internal transfers, and adjustments.
          </p>
        </div>

        <button className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700 transition-all">
          <Download className="w-3.5 h-3.5" />
          <span>Export Ledger CSV</span>
        </button>
      </div>

      {/* Movements Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading ledger movements...</p>
          </div>
        ) : movements.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            No stock movements found in current ledger.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-semibold">Timestamp</th>
                  <th className="py-3 px-4 font-semibold">Product SKU & Name</th>
                  <th className="py-3 px-4 font-semibold">Warehouse Location</th>
                  <th className="py-3 px-4 font-semibold">Movement Type</th>
                  <th className="py-3 px-4 font-semibold text-right">Qty Delta</th>
                  <th className="py-3 px-4 font-semibold">Audit Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {movements.map((m) => {
                  const isPositive = m.qtyChange > 0;
                  return (
                    <tr key={m._id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                        {new Date(m.timestamp).toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-200">
                          {m.product?.name || 'Product'}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400">
                          {m.product?.sku}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-300">
                        {m.warehouse?.code} - {m.warehouse?.name}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium capitalize bg-slate-800 text-slate-300 border border-slate-700/60">
                          {m.type?.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span
                          className={`font-mono font-bold ${
                            isPositive ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isPositive ? `+${m.qtyChange}` : m.qtyChange}{' '}
                          <span className="text-[10px] font-normal text-slate-400">
                            {m.product?.unitOfMeasure}
                          </span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        {m.notes || '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

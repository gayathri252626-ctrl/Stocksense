import React, { useState, useEffect } from 'react';
import {
  Boxes,
  Plus,
  Search,
  Filter,
  AlertTriangle,
  Edit2,
  Trash2,
  X,
  CheckCircle2,
  AlertCircle,
  Warehouse,
  Tag,
  ArrowUpDown,
  Building,
} from 'lucide-react';
import api from '../../api/axios';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import LowStockAlertBanner from '../../components/common/LowStockAlertBanner';

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [lowStockAlerts, setLowStockAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedWarehouse, setSelectedWarehouse] = useState('all');
  const [stockStatusFilter, setStockStatusFilter] = useState('all');

  // Modals
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  // Form Fields
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [unitOfMeasure, setUnitOfMeasure] = useState('pcs');
  const [reorderPoint, setReorderPoint] = useState(10);
  const [description, setDescription] = useState('');
  const [initialWarehouseId, setInitialWarehouseId] = useState('');
  const [initialStock, setInitialStock] = useState('');
  const [stockUpdates, setStockUpdates] = useState({});

  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const { user } = useAuth();
  const { socket } = useSocket();
  const isManager = user?.role === 'manager';

  const loadData = async () => {
    try {
      setLoading(true);
      const [prodRes, catRes, warRes, dashRes] = await Promise.all([
        api.get('/products'),
        api.get('/categories'),
        api.get('/warehouses'),
        api.get('/dashboard/stats'),
      ]);

      setProducts(prodRes.data.products || []);
      setCategories(catRes.data.categories || []);
      setWarehouses(warRes.data.warehouses || []);
      setLowStockAlerts(dashRes.data.lowStockAlerts || []);
    } catch (err) {
      console.error('Failed to load products data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Listen for real-time stock updates
  useEffect(() => {
    if (!socket) return;
    const handleUpdate = () => {
      loadData();
    };
    socket.on('stock:updated', handleUpdate);
    return () => {
      socket.off('stock:updated', handleUpdate);
    };
  }, [socket]);

  const openCreateModal = () => {
    setEditingProduct(null);
    setName('');
    setSku('');
    setCategoryId(categories[0]?._id || '');
    setUnitOfMeasure('pcs');
    setReorderPoint(10);
    setDescription('');
    setInitialWarehouseId(warehouses[0]?._id || '');
    setInitialStock('');
    setStockUpdates({});
    setError('');
    setModalOpen(true);
  };

  const openEditModal = (p) => {
    setEditingProduct(p);
    setName(p.name);
    setSku(p.sku);
    setCategoryId(p.category?._id || p.category || '');
    setUnitOfMeasure(p.unitOfMeasure || 'pcs');
    setReorderPoint(p.reorderPoint !== undefined ? p.reorderPoint : 10);
    setDescription(p.description || '');

    // Map existing stock levels for editing
    const stocksMap = {};
    if (p.stockPerWarehouse) {
      p.stockPerWarehouse.forEach((sw) => {
        stocksMap[sw.warehouse._id] = sw.quantity;
      });
    }
    setStockUpdates(stocksMap);
    setError('');
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setEditingProduct(null);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setSubmitting(true);

    try {
      if (editingProduct) {
        // Convert stockUpdates object to array for API
        const stockUpdatesArray = Object.entries(stockUpdates).map(([wId, qty]) => ({
          warehouseId: wId,
          quantity: Number(qty) || 0,
        }));

        await api.put(`/products/${editingProduct._id}`, {
          name,
          sku,
          category: categoryId,
          unitOfMeasure,
          reorderPoint: Number(reorderPoint),
          description,
          stockUpdates: stockUpdatesArray,
        });
        setMessage(`Product "${name}" updated successfully.`);
      } else {
        await api.post('/products', {
          name,
          sku,
          category: categoryId,
          unitOfMeasure,
          reorderPoint: Number(reorderPoint),
          description,
          initialWarehouseId,
          initialStock: initialStock ? Number(initialStock) : 0,
        });
        setMessage(`Product "${name}" created with SKU ${sku.toUpperCase()}.`);
      }

      closeModal();
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Operation failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (p) => {
    if (!window.confirm(`Are you sure you want to delete product "${p.name}" (${p.sku})?`)) {
      return;
    }
    setError('');
    setMessage('');

    try {
      await api.delete(`/products/${p._id}`);
      setMessage(`Product "${p.name}" deleted successfully.`);
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete product.');
    }
  };

  // Filtered products list
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.sku?.toLowerCase().includes(search.toLowerCase());

    const matchesCategory =
      selectedCategory === 'all' ||
      (p.category?._id || p.category) === selectedCategory;

    let matchesWarehouse = true;
    if (selectedWarehouse !== 'all') {
      const wStock = p.stockPerWarehouse?.find(
        (sw) => sw.warehouse._id === selectedWarehouse
      );
      matchesWarehouse = wStock && wStock.quantity > 0;
    }

    let matchesStatus = true;
    if (stockStatusFilter === 'low_stock') {
      matchesStatus = p.isLowStock;
    } else if (stockStatusFilter === 'out_of_stock') {
      matchesStatus = p.isOutOfStock;
    } else if (stockStatusFilter === 'in_stock') {
      matchesStatus = !p.isLowStock && p.totalQty > 0;
    }

    return matchesSearch && matchesCategory && matchesWarehouse && matchesStatus;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Low-Stock Alert Banner */}
      <LowStockAlertBanner alerts={lowStockAlerts} onRefresh={loadData} />

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">Product Catalog</h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-brand-500/20 text-brand-300 font-semibold border border-brand-500/30 font-mono">
              {products.length} Items
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Create, update, and manage master products, location-wise availability, and reorder threshold rules.
          </p>
        </div>

        {isManager && (
          <button
            onClick={openCreateModal}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-brand-600 hover:bg-brand-500 text-white shadow-glow transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create Product</span>
          </button>
        )}
      </div>

      {message && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {error && (
        <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 animate-in fade-in">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        {/* SKU Search */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search SKU or Product Name..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-400 focus:outline-none focus:border-brand-500"
          />
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <Tag className="w-3.5 h-3.5 text-brand-400" />
            <span className="text-slate-400">Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Categories</option>
              {categories.map((c) => (
                <option key={c._id} value={c._id} className="bg-slate-900">
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Location Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <Building className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400">Location:</span>
            <select
              value={selectedWarehouse}
              onChange={(e) => setSelectedWarehouse(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Facilities</option>
              {warehouses.map((w) => (
                <option key={w._id} value={w._id} className="bg-slate-900">
                  {w.code} - {w.name}
                </option>
              ))}
            </select>
          </div>

          {/* Stock Level Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <Filter className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">Level:</span>
            <select
              value={stockStatusFilter}
              onChange={(e) => setStockStatusFilter(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Stock Statuses</option>
              <option value="low_stock" className="bg-slate-900">Low Stock Alert (&le; Min)</option>
              <option value="out_of_stock" className="bg-slate-900">Out of Stock (0 Qty)</option>
              <option value="in_stock" className="bg-slate-900">Optimal Stock</option>
            </select>
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading master product catalog & stock levels...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="p-12 text-center">
            <Boxes className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-slate-300">No products match your criteria</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
              Try adjusting your SKU search keywords or category filters.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Product Name & SKU</th>
                  <th className="py-3.5 px-4 font-semibold">Category</th>
                  <th className="py-3.5 px-4 font-semibold">Unit</th>
                  <th className="py-3.5 px-4 font-semibold text-center">Reorder Point</th>
                  <th className="py-3.5 px-4 font-semibold">Stock Availability per Warehouse</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Total Available</th>
                  <th className="py-3.5 px-4 font-semibold text-center">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredProducts.map((p) => {
                  const isLow = p.isLowStock;
                  return (
                    <tr key={p._id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-100 text-sm">
                          {p.name}
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="font-mono font-bold text-brand-300 px-1.5 py-0.5 rounded bg-brand-500/10 border border-brand-500/20 text-[11px]">
                            {p.sku}
                          </span>
                          {p.description && (
                            <span className="text-[11px] text-slate-400 truncate max-w-xs">
                              {p.description}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-lg text-[11px] font-medium bg-slate-800/80 text-slate-300 border border-slate-700/60">
                          {p.category?.name || 'General'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-slate-300 font-medium">
                        {p.unitOfMeasure}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className="font-mono font-semibold text-slate-300 px-2 py-0.5 rounded bg-slate-950 border border-slate-800">
                          {p.reorderPoint !== undefined ? p.reorderPoint : 10}
                        </span>
                      </td>

                      {/* Stock availability per warehouse breakdown */}
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {p.stockPerWarehouse && p.stockPerWarehouse.length > 0 ? (
                            p.stockPerWarehouse.map((sw, sIdx) => {
                              const isWarehouseLow = sw.quantity <= (p.reorderPoint || 10);
                              return (
                                <span
                                  key={sIdx}
                                  title={`${sw.warehouse.name}: ${sw.quantity} ${p.unitOfMeasure}`}
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-mono border ${
                                    isWarehouseLow
                                      ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                                      : 'bg-slate-950/80 text-slate-300 border-slate-800'
                                  }`}
                                >
                                  <span className="font-bold text-slate-400">{sw.warehouse.code}:</span>
                                  <span className={sw.quantity > 0 ? 'text-white font-bold' : 'text-slate-500'}>
                                    {sw.quantity}
                                  </span>
                                </span>
                              );
                            })
                          ) : (
                            <span className="text-[11px] text-slate-500 italic">No warehouse stock mapped</span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <span
                          className={`font-mono text-base font-bold ${
                            p.totalQty === 0
                              ? 'text-rose-400'
                              : isLow
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                          }`}
                        >
                          {p.totalQty}{' '}
                          <span className="text-[10px] font-normal text-slate-400">
                            {p.unitOfMeasure}
                          </span>
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${
                            p.totalQty === 0
                              ? 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                              : isLow
                              ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                              : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                          }`}
                        >
                          {isLow && <AlertTriangle className="w-3 h-3" />}
                          {p.totalQty === 0 ? 'Out of Stock' : isLow ? 'Low Stock' : 'Optimal'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        {isManager && (
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => openEditModal(p)}
                              className="p-1.5 text-slate-400 hover:text-brand-300 hover:bg-slate-800 rounded-lg transition-colors"
                              title="Edit Product & Stock"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDelete(p)}
                              className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                              title="Delete Product"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal for Create / Edit Product */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="glass-panel w-full max-w-xl p-6 rounded-2xl border border-slate-700/80 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-base font-bold text-white mb-4">
              {editingProduct ? `Edit Product: ${editingProduct.sku}` : 'Register New Inventory Product'}
            </h3>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Product Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Copper Tubing (15mm)"
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Unique SKU / Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={sku}
                    onChange={(e) => setSku(e.target.value.toUpperCase())}
                    placeholder="e.g. CPR-TUB-015"
                    className="w-full px-3.5 py-2 text-xs font-mono uppercase bg-slate-950/80 border border-slate-800 rounded-xl text-brand-300 focus:outline-none focus:border-brand-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Category *
                  </label>
                  <select
                    required
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500 cursor-pointer"
                  >
                    <option value="" disabled>Select Category</option>
                    {categories.map((c) => (
                      <option key={c._id} value={c._id} className="bg-slate-900">
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Unit of Measure *
                  </label>
                  <select
                    value={unitOfMeasure}
                    onChange={(e) => setUnitOfMeasure(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500 cursor-pointer"
                  >
                    <option value="pcs">pcs (Pieces)</option>
                    <option value="kg">kg (Kilograms)</option>
                    <option value="m">m (Meters)</option>
                    <option value="sheets">sheets (Sheets)</option>
                    <option value="box">box (Boxes)</option>
                    <option value="liters">liters (Liters)</option>
                    <option value="set">set (Sets)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Reorder Point Rule *
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={reorderPoint}
                    onChange={(e) => setReorderPoint(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs font-mono bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Product Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Optional material specs, grade, or dimensions..."
                  className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                />
              </div>

              {/* Initial stock section (when creating) */}
              {!editingProduct && (
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200">
                      Initial Stock Level (Optional)
                    </span>
                    <span className="text-[11px] text-slate-400">Can also be added via Receipts later</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">
                        Select Target Warehouse
                      </label>
                      <select
                        value={initialWarehouseId}
                        onChange={(e) => setInitialWarehouseId(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                      >
                        {warehouses.map((w) => (
                          <option key={w._id} value={w._id}>
                            {w.code} - {w.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">
                        Starting Quantity
                      </label>
                      <input
                        type="number"
                        min={0}
                        value={initialStock}
                        onChange={(e) => setInitialStock(e.target.value)}
                        placeholder="0"
                        className="w-full px-3 py-1.5 text-xs font-mono bg-slate-900 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Stock breakdown editor (when editing) */}
              {editingProduct && (
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200">
                      Stock Quantities per Location
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Edits automatically log to Stock Ledger
                    </span>
                  </div>

                  <div className="space-y-2">
                    {warehouses.map((w) => (
                      <div
                        key={w._id}
                        className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 text-xs"
                      >
                        <div>
                          <span className="font-bold text-white font-mono mr-2">{w.code}</span>
                          <span className="text-slate-300">{w.name}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <input
                            type="number"
                            min={0}
                            value={stockUpdates[w._id] !== undefined ? stockUpdates[w._id] : 0}
                            onChange={(e) =>
                              setStockUpdates({
                                ...stockUpdates,
                                [w._id]: e.target.value,
                              })
                            }
                            className="w-20 px-2 py-1 text-xs font-mono font-bold text-right bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-brand-500"
                          />
                          <span className="text-[11px] text-slate-400">{unitOfMeasure}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-xs font-semibold text-white bg-brand-600 rounded-xl hover:bg-brand-500 disabled:opacity-50 shadow-glow"
                >
                  {submitting ? 'Saving...' : editingProduct ? 'Save Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

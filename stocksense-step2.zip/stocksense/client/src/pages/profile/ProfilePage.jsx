import React from 'react';
import { User, Mail, ShieldCheck, KeyRound, LogOut, Calendar, Layers } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-white">My Profile</h1>
        <p className="text-xs text-slate-400 mt-1">
          User account details, access authorization, and operational security
        </p>
      </div>

      {/* Profile Card */}
      <div className="glass-panel p-6 sm:p-8 rounded-2xl border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-500 text-white font-bold text-2xl shadow-glow">
              {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">{user?.name}</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs px-2.5 py-0.5 rounded-full capitalize font-semibold bg-brand-500/10 text-brand-300 border border-brand-500/30">
                  {user?.role || 'Staff'} Role
                </span>
                <span className="text-xs text-slate-400">• Active Session</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-xl transition-all"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>Sign Out</span>
          </button>
        </div>

        {/* User Info Fields */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
              <Mail className="w-3.5 h-3.5 text-brand-400" />
              <span>Registered Work Email</span>
            </span>
            <p className="text-sm font-semibold text-slate-100">{user?.email}</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Permission Tier</span>
            </span>
            <p className="text-sm font-semibold text-slate-100 capitalize">
              {user?.role === 'manager'
                ? 'Full Operations & System Approvals (Manager)'
                : 'Fulfillment, Transfers & Counting (Staff)'}
            </p>
          </div>
        </div>

        {/* Security / Password Reset Callout */}
        <div className="p-4 rounded-xl bg-brand-950/20 border border-brand-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-brand-500/20 text-brand-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-slate-200">
                Password Security & OTP Reset
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Update your login credentials using 6-digit OTP email verification
              </p>
            </div>
          </div>

          <button
            onClick={() => navigate('/forgot-password')}
            className="px-3.5 py-1.5 text-xs font-semibold text-brand-300 hover:text-white bg-brand-600/40 hover:bg-brand-600 rounded-lg transition-all"
          >
            Reset Password
          </button>
        </div>
      </div>
    </div>
  );
}

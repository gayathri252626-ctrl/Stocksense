import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Boxes,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  SlidersHorizontal,
  RefreshCw,
  Building2,
  CheckCircle2,
  Clock,
  ChevronRight,
  Filter,
  Plus,
  Radio,
  FileText,
  Activity,
  Sparkles,
} from 'lucide-react';
import api from '../../api/axios';
import { useSocket } from '../../context/SocketContext';
import LowStockAlertBanner from '../../components/common/LowStockAlertBanner';

export default function Dashboard({ activeWarehouse, setActiveWarehouse, warehouses }) {
  const [stats, setStats] = useState(null);
  const [lowStockAlerts, setLowStockAlerts] = useState([]);
  const [operationsList, setOperationsList] = useState([]);
  const [recentMovements, setRecentMovements] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  // Dynamic Filters
  const [selectedDocType, setSelectedDocType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Socket notification toast state
  const [lastLiveEvent, setLastLiveEvent] = useState(null);

  const { socket, isConnected } = useSocket();

  const fetchStats = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();

      if (activeWarehouse && activeWarehouse !== 'all') {
        params.append('warehouseId', activeWarehouse);
      }
      if (selectedDocType && selectedDocType !== 'all') {
        params.append('docType', selectedDocType);
      }
      if (selectedStatus && selectedStatus !== 'all') {
        params.append('status', selectedStatus);
      }
      if (selectedCategory && selectedCategory !== 'all') {
        params.append('categoryId', selectedCategory);
      }

      const res = await api.get(`/dashboard/stats?${params.toString()}`);
      setStats(res.data.stats);
      setLowStockAlerts(res.data.lowStockAlerts || []);
      setOperationsList(res.data.operationsList || []);
      setRecentMovements(res.data.recentMovements || []);
      setCategories(res.data.categories || []);
    } catch (err) {
      console.error('Failed to fetch dashboard stats:', err);
    } finally {
      setLoading(false);
    }
  }, [activeWarehouse, selectedDocType, selectedStatus, selectedCategory]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // Wire real-time Socket.io listener
  useEffect(() => {
    if (!socket) return;

    const handleStockUpdate = (data) => {
      console.log('[Socket] Received stock:updated event:', data);
      setLastLiveEvent({
        type: data?.type || 'Stock Balance Updated',
        timestamp: new Date().toLocaleTimeString(),
      });
      fetchStats();

      // Clear toast after 4s
      setTimeout(() => setLastLiveEvent(null), 4000);
    };

    socket.on('stock:updated', handleStockUpdate);
    socket.on('inventory:changed', handleStockUpdate);
    socket.on('ledger:entry', handleStockUpdate);

    return () => {
      socket.off('stock:updated', handleStockUpdate);
      socket.off('inventory:changed', handleStockUpdate);
      socket.off('ledger:entry', handleStockUpdate);
    };
  }, [socket, fetchStats]);

  const kpis = [
    {
      label: 'Total Products in Stock',
      value: stats ? stats.totalProducts : '—',
      icon: Boxes,
      color: 'from-blue-500/20 to-indigo-500/10',
      border: 'border-blue-500/30',
      textColor: 'text-blue-400',
      description: 'Active catalog SKUs',
      link: '/products',
    },
    {
      label: 'Low / Out of Stock',
      value: stats ? stats.totalLowStockAlerts : '—',
      icon: AlertTriangle,
      color: 'from-amber-500/20 to-rose-500/10',
      border: stats?.totalLowStockAlerts > 0 ? 'border-amber-500/50' : 'border-slate-800',
      textColor: stats?.totalLowStockAlerts > 0 ? 'text-amber-400' : 'text-slate-400',
      alert: stats?.totalLowStockAlerts > 0,
      description: 'Requires reorder attention',
      link: '/products',
    },
    {
      label: 'Pending Receipts',
      value: stats ? stats.pendingReceiptsCount : '—',
      icon: ArrowDownLeft,
      color: 'from-emerald-500/20 to-teal-500/10',
      border: 'border-emerald-500/30',
      textColor: 'text-emerald-400',
      description: 'Inbound supplier shipments',
      link: '/receipts',
    },
    {
      label: 'Pending Deliveries',
      value: stats ? stats.pendingDeliveriesCount : '—',
      icon: ArrowUpRight,
      color: 'from-purple-500/20 to-pink-500/10',
      border: 'border-purple-500/30',
      textColor: 'text-purple-400',
      description: 'Outbound customer orders',
      link: '/deliveries',
    },
    {
      label: 'Internal Transfers',
      value: stats ? stats.internalTransfersCount : '—',
      icon: ArrowLeftRight,
      color: 'from-cyan-500/20 to-sky-500/10',
      border: 'border-cyan-500/30',
      textColor: 'text-cyan-400',
      description: 'Scheduled floor moves',
      link: '/transfers',
    },
  ];

  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case 'done':
      case 'applied':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'ready':
        return 'bg-purple-500/10 text-purple-300 border-purple-500/30';
      case 'waiting':
        return 'bg-amber-500/10 text-amber-300 border-amber-500/30';
      case 'cancelled':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/30';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700/60';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Live Event Notification Pill */}
      {lastLiveEvent && (
        <div className="p-3 rounded-2xl bg-indigo-600/30 border border-brand-500/50 text-brand-200 text-xs flex items-center justify-between shadow-glow animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-brand-300 animate-spin" />
            <span>
              <strong>Real-Time Sync:</strong> {lastLiveEvent.type} received via WebSocket at {lastLiveEvent.timestamp}.
            </span>
          </div>
          <span className="font-mono text-[10px] text-brand-400">Live Updated</span>
        </div>
      )}

      {/* Low-Stock Alert Banner */}
      <LowStockAlertBanner alerts={lowStockAlerts} onRefresh={fetchStats} />

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Inventory Operations Dashboard
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time status of multi-warehouse operations, stock balances, and dynamic fulfillment tracking.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchStats}
            className="flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700/60 transition-all"
            title="Refresh metrics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <Link
            to="/products"
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-brand-600 hover:bg-brand-500 text-white shadow-glow transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Catalog SKUs</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon;
          return (
            <Link
              to={kpi.link}
              key={index}
              className={`p-4 rounded-2xl bg-gradient-to-br ${kpi.color} bg-slate-900/80 border ${kpi.border} backdrop-blur-md relative overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-glow block`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">{kpi.label}</span>
                <div className={`p-2 rounded-xl bg-slate-950/60 ${kpi.textColor}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>

              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold tracking-tight text-white font-mono">
                  {kpi.value}
                </span>
                {kpi.alert && (
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Action Req.
                  </span>
                )}
              </div>

              <p className="text-[11px] text-slate-400 mt-1">{kpi.description}</p>
            </Link>
          );
        })}
      </div>

      {/* Dynamic Filters Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
            <Filter className="w-4 h-4 text-brand-400" />
            <span>Dynamic Operations Filter:</span>
          </div>

          <button
            onClick={() => {
              setSelectedDocType('all');
              setSelectedStatus('all');
              setSelectedCategory('all');
              setActiveWarehouse('');
            }}
            className="text-[11px] text-brand-400 hover:text-brand-300 font-medium"
          >
            Reset Filters
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          {/* Document Type Filter */}
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Document Type
            </label>
            <select
              value={selectedDocType}
              onChange={(e) => setSelectedDocType(e.target.value)}
              className="w-full bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Operations</option>
              <option value="receipts" className="bg-slate-900">Receipts (Incoming)</option>
              <option value="delivery" className="bg-slate-900">Delivery Orders (Outgoing)</option>
              <option value="internal" className="bg-slate-900">Internal Transfers</option>
              <option value="adjustments" className="bg-slate-900">Stock Adjustments</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Operation Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Statuses</option>
              <option value="draft" className="bg-slate-900">Draft</option>
              <option value="waiting" className="bg-slate-900">Waiting</option>
              <option value="ready" className="bg-slate-900">Ready</option>
              <option value="done" className="bg-slate-900">Done / Applied</option>
              <option value="cancelled" className="bg-slate-900">Canceled</option>
            </select>
          </div>

          {/* Warehouse Location Filter */}
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Warehouse Facility
            </label>
            <select
              value={activeWarehouse || ''}
              onChange={(e) => setActiveWarehouse(e.target.value)}
              className="w-full bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="" className="bg-slate-900">All Facilities</option>
              {warehouses.map((w) => (
                <option key={w._id} value={w._id} className="bg-slate-900">
                  {w.code} - {w.name}
                </option>
              ))}
            </select>
          </div>

          {/* Category Filter */}
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Product Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Categories</option>
              {categories.map((c) => (
                <option key={c._id} value={c._id} className="bg-slate-900">
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Filtered Operations View Table */}
      <div className="glass-panel p-5 rounded-2xl border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">
                Filtered Inventory Operations
              </h2>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-semibold border border-slate-700/60">
                {operationsList.length} matching
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Live filtered records based on document type, status, warehouse, and category criteria.
            </p>
          </div>
        </div>

        {operationsList.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            <FileText className="w-8 h-8 text-slate-600 mx-auto mb-2 opacity-60" />
            No operations match the selected filter combination. Adjust your filters above.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-semibold">Document #</th>
                  <th className="py-3 px-4 font-semibold">Type</th>
                  <th className="py-3 px-4 font-semibold">Partner / Flow</th>
                  <th className="py-3 px-4 font-semibold">Facility Location</th>
                  <th className="py-3 px-4 font-semibold text-center">Items</th>
                  <th className="py-3 px-4 font-semibold text-center">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {operationsList.map((op) => (
                  <tr key={op.id} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-brand-300">
                      {op.number}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase bg-slate-800 text-slate-300 border border-slate-700/60">
                        {op.typeBadge}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-200">{op.partner}</div>
                      <div className="text-[10px] text-slate-500">{op.partnerLabel}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {op.warehouse}
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-semibold text-slate-300">
                      {op.itemCount}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase border ${getStatusBadge(
                          op.status
                        )}`}
                      >
                        {op.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-400 text-[11px]">
                      {new Date(op.date).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Launchpad & Live Movement Ledger Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Operations Launchpad */}
        <div className="glass-panel p-5 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-white">Operations Launchpad</h2>
            <span className="text-xs text-slate-400">Quick Actions</span>
          </div>

          <div className="space-y-2.5">
            <Link
              to="/receipts"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:scale-105 transition-transform">
                  <ArrowDownLeft className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-200 group-hover:text-emerald-300">
                    New Incoming Receipt
                  </h4>
                  <p className="text-[10px] text-slate-400">Receive goods from vendor</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
            </Link>

            <Link
              to="/deliveries"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-purple-500/50 hover:bg-slate-900 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 group-hover:scale-105 transition-transform">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-200 group-hover:text-purple-300">
                    New Delivery Order
                  </h4>
                  <p className="text-[10px] text-slate-400">Ship items to customer</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
            </Link>

            <Link
              to="/transfers"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-900 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 group-hover:scale-105 transition-transform">
                  <ArrowLeftRight className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300">
                    Internal Transfer
                  </h4>
                  <p className="text-[10px] text-slate-400">Shift stock between bays</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
            </Link>

            <Link
              to="/adjustments"
              className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-900 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 group-hover:scale-105 transition-transform">
                  <SlidersHorizontal className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-200 group-hover:text-amber-300">
                    Inventory Adjustment
                  </h4>
                  <p className="text-[10px] text-slate-400">Reconcile counted vs system</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:translate-x-0.5 transition-transform" />
            </Link>
          </div>
        </div>

        {/* Live Movements Table */}
        <div className="lg:col-span-2 glass-panel p-5 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-white">
                Recent Stock Movements (Ledger)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Immutable audit history from StockLedger collection
              </p>
            </div>
            <Link
              to="/move-history"
              className="text-xs text-brand-400 hover:text-brand-300 font-medium inline-flex items-center gap-1"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {recentMovements.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              No stock movements recorded yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="pb-3 font-semibold">Timestamp</th>
                    <th className="pb-3 font-semibold">Product</th>
                    <th className="pb-3 font-semibold">Location</th>
                    <th className="pb-3 font-semibold">Type</th>
                    <th className="pb-3 font-semibold text-right">Delta</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {recentMovements.map((m) => {
                    const isPositive = m.qtyChange > 0;
                    return (
                      <tr key={m._id} className="hover:bg-slate-900/40 transition-colors">
                        <td className="py-2.5 text-slate-400 font-mono text-[11px]">
                          {new Date(m.timestamp).toLocaleDateString()} {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="py-2.5">
                          <div className="font-semibold text-slate-200">
                            {m.product?.name || 'Product'}
                          </div>
                          <div className="text-[11px] font-mono text-slate-400">
                            {m.product?.sku}
                          </div>
                        </td>
                        <td className="py-2.5 text-slate-300">
                          {m.warehouse?.code} - {m.warehouse?.name}
                        </td>
                        <td className="py-2.5">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-medium capitalize bg-slate-800 text-slate-300 border border-slate-700/60">
                            {m.type?.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-2.5 text-right font-mono font-bold">
                          <span className={isPositive ? 'text-emerald-400' : 'text-rose-400'}>
                            {isPositive ? `+${m.qtyChange}` : m.qtyChange} {m.product?.unitOfMeasure}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

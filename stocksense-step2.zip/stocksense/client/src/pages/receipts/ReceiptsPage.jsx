import React from 'react';
import { ArrowDownLeft, Plus, CheckCircle2, Clock, Filter, FileText, ArrowRight } from 'lucide-react';

export default function ReceiptsPage() {
  const demoReceipts = [
    {
      id: 'REC-2026-001',
      supplier: 'Apex Metallurgy Corp',
      warehouse: 'Main Central Warehouse (MW-01)',
      items: 'Steel Rods (50kg), Aluminum Sheets (30 sheets)',
      status: 'waiting',
      date: '2026-09-26',
    },
    {
      id: 'REC-2026-002',
      supplier: 'Fastener Dynamics Ltd',
      warehouse: 'Main Central Warehouse (MW-01)',
      items: 'Hex Flange Bolts (500 pcs)',
      status: 'ready',
      date: '2026-09-26',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Receipts (Incoming Stock)
            </h1>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
              Inbound
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Register and validate shipments arriving from suppliers. Validating updates stock automatically.
          </p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-glow transition-all">
          <Plus className="w-4 h-4" />
          <span>New Receipt</span>
        </button>
      </div>

      {/* Process Flow Banner */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 bg-gradient-to-r from-emerald-950/30 via-slate-900 to-slate-900">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-2">
          Receipt Workflow Lifecycle
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-slate-200">1. Draft</span>
            <p className="text-[11px] text-slate-400 mt-0.5">Specify supplier & product lines</p>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-slate-200">2. Waiting</span>
            <p className="text-[11px] text-slate-400 mt-0.5">Awaiting carrier transit/arrival</p>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="font-bold text-slate-200">3. Ready</span>
            <p className="text-[11px] text-slate-400 mt-0.5">Items in staging bay for count check</p>
          </div>
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
            <span className="font-bold">4. Validate Done</span>
            <p className="text-[11px] text-emerald-400/80 mt-0.5">Stock increases automatically (+qty)</p>
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-3 px-4 font-semibold">Receipt Number</th>
                <th className="py-3 px-4 font-semibold">Supplier</th>
                <th className="py-3 px-4 font-semibold">Destination Warehouse</th>
                <th className="py-3 px-4 font-semibold">Items</th>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {demoReceipts.map((r) => (
                <tr key={r.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-emerald-400">
                    {r.id}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-200">
                    {r.supplier}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {r.warehouse}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {r.items}
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-mono">
                    {r.date}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase bg-amber-500/10 text-amber-300 border border-amber-500/30">
                      {r.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

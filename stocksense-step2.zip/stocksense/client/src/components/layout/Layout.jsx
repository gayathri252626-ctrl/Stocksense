import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Navbar from './Navbar';

export default function Layout({ activeWarehouse, setActiveWarehouse, warehouses }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-950 font-sans">
      {/* Left Sidebar */}
      <Sidebar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 min-w-0 lg:pl-72">
        {/* Top Navbar */}
        <Navbar
          setMobileOpen={setMobileOpen}
          activeWarehouse={activeWarehouse}
          setActiveWarehouse={setActiveWarehouse}
          warehouses={warehouses}
        />

        {/* Scrollable Page Outlet */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

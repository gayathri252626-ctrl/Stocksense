import React from 'react';
import { Menu, Radio, Bell, Search } from 'lucide-react';
import { useSocket } from '../../context/SocketContext';
import { useAuth } from '../../context/AuthContext';

export default function Navbar({ setMobileOpen, activeWarehouse, setActiveWarehouse, warehouses = [] }) {
  const { isConnected } = useSocket();
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 sm:px-6 bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80">
      {/* Left: Mobile Toggle & Search */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setMobileOpen(true)}
          className="p-2 -ml-2 text-slate-400 rounded-lg lg:hidden hover:text-white hover:bg-slate-800"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="relative hidden md:block w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search SKU, product, transfer #..."
            className="w-full pl-9 pr-4 py-1.5 text-xs bg-slate-950/60 border border-slate-800 rounded-xl text-slate-200 placeholder-slate-400 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500/50 transition-all"
          />
        </div>
      </div>

      {/* Right: Live Socket Indicator, Warehouse Selector, Notifications */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* Real-time Socket status indicator */}
        <div
          title={isConnected ? 'Real-time WebSocket connected' : 'Connecting to real-time engine...'}
          className={`flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
            isConnected
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
              : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
          }`}
        >
          <span
            className={`w-2 h-2 rounded-full ${
              isConnected ? 'bg-emerald-400 badge-pulse' : 'bg-amber-400 animate-pulse'
            }`}
          />
          <span className="hidden sm:inline">
            {isConnected ? 'Live Sync Active' : 'Connecting Sync'}
          </span>
        </div>

        {/* Warehouse Selector (if available) */}
        {warehouses.length > 0 && (
          <div className="hidden sm:flex items-center gap-1.5 text-xs bg-slate-950/60 border border-slate-800 px-2.5 py-1.5 rounded-xl">
            <span className="text-slate-400">Warehouse:</span>
            <select
              value={activeWarehouse || ''}
              onChange={(e) => setActiveWarehouse(e.target.value)}
              className="bg-transparent text-slate-200 text-xs font-medium focus:outline-none cursor-pointer"
            >
              <option value="" className="bg-slate-900 text-white">All Warehouses</option>
              {warehouses.map((w) => (
                <option key={w._id} value={w._id} className="bg-slate-900 text-white">
                  {w.code} - {w.name}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Notifications Icon */}
        <button
          className="relative p-2 text-slate-400 rounded-xl hover:text-white hover:bg-slate-800 transition-colors"
          title="Notifications"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-500 rounded-full" />
        </button>

        {/* User Mini Avatar */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-tr from-brand-600 to-indigo-500 text-white font-semibold text-xs shadow-glow">
            {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
          </div>
          <span className="hidden xl:inline text-xs font-medium text-slate-300">
            {user?.name}
          </span>
        </div>
      </div>
    </header>
  );
}

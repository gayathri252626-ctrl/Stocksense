import React, { useState } from 'react';
import { AlertTriangle, ChevronRight, X, ArrowDownLeft, ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function LowStockAlertBanner({ alerts = [], onRefresh }) {
  const [collapsed, setCollapsed] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  if (!alerts || alerts.length === 0 || dismissed) {
    return null;
  }

  return (
    <div className="rounded-2xl border border-amber-500/40 bg-gradient-to-r from-amber-950/50 via-slate-900/90 to-amber-950/30 backdrop-blur-md p-4 shadow-glow-amber animate-in fade-in slide-in-from-top-2 duration-200">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0 mt-0.5">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-amber-200 tracking-tight">
                Low Stock Threshold Alerts ({alerts.length})
              </h3>
              <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                Action Required
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              One or more inventory items have dropped to or below their configured minimum reorder points.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="text-xs text-amber-400 hover:text-amber-300 font-medium px-2 py-1 rounded-lg hover:bg-amber-500/10 transition-colors"
          >
            {collapsed ? 'Show Items' : 'Hide'}
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {!collapsed && (
        <div className="mt-3.5 pt-3 border-t border-amber-500/20">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {alerts.map((item, idx) => (
              <div
                key={idx}
                className="p-2.5 rounded-xl bg-slate-950/70 border border-amber-500/20 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-semibold text-slate-200 truncate max-w-[170px]">
                    {item.productName}
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono mt-0.5">
                    <span>{item.sku}</span>
                    <span>•</span>
                    <span className="text-brand-300">{item.warehouseCode}</span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="font-mono font-bold text-amber-400">
                    {item.currentQty} / {item.reorderPoint} {item.unitOfMeasure}
                  </div>
                  <div className="text-[10px] text-rose-400 font-semibold">
                    {item.deficit > 0 ? `-${item.deficit} ${item.unitOfMeasure}` : 'At Reorder Point'}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-3 flex items-center justify-between text-xs">
            <span className="text-slate-400 text-[11px]">
              Prompt replenishment prevents production stops and fulfillment delays.
            </span>
            <Link
              to="/receipts"
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 transition-all shadow-glow-amber"
            >
              <ArrowDownLeft className="w-3.5 h-3.5" />
              <span>Create Replenishment Receipt</span>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

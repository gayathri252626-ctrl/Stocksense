const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const { User, OtpToken } = require('../models');
const { JWT_SECRET } = require('../middleware/auth');

// Helper to generate JWT token
const generateToken = (user) => {
  return jwt.sign(
    {
      id: user._id,
      email: user.email,
      role: user.role,
      name: user.name,
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// Signup
const signup = async (req, res, next) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are required.',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    const existingUser = await User.findOne({ email: normalizedEmail });
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'An account with this email already exists.',
      });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const userRole = role === 'manager' ? 'manager' : 'staff';

    const user = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      passwordHash,
      role: userRole,
    });

    const token = generateToken(user);

    res.status(201).json({
      success: true,
      message: 'Account registered successfully.',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (err) {
    next(err);
  }
};

// Login
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.',
      });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: normalizedEmail });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      });
    }

    const token = generateToken(user);

    res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (err) {
    next(err);
  }
};

// Forgot Password - Generate 6-digit OTP
const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email address is required.',
      });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: normalizedEmail });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'No registered user found with this email address.',
      });
    }

    // Generate random 6-digit code
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Invalidate existing tokens for this email
    await OtpToken.deleteMany({ email: normalizedEmail });

    // Store new OTP token
    await OtpToken.create({
      email: normalizedEmail,
      code: otpCode,
      expiresAt,
    });

    // Check if SMTP is configured
    const hasSmtp =
      process.env.SMTP_HOST &&
      process.env.SMTP_PORT &&
      process.env.SMTP_USER &&
      process.env.SMTP_PASS;

    if (hasSmtp) {
      try {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: Number(process.env.SMTP_PORT) || 587,
          secure: process.env.SMTP_SECURE === 'true',
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
        });

        await transporter.sendMail({
          from: `"StockSense Support" <${process.env.SMTP_FROM || process.env.SMTP_USER}>`,
          to: normalizedEmail,
          subject: 'StockSense - Password Reset Verification Code',
          text: `Your password reset code is ${otpCode}. It is valid for 10 minutes.`,
          html: `<div style="font-family: sans-serif; padding: 20px;">
            <h2>StockSense Password Reset</h2>
            <p>You requested a password reset. Use the following 6-digit verification code:</p>
            <h1 style="letter-spacing: 5px; color: #2563eb;">${otpCode}</h1>
            <p>This code will expire in <strong>10 minutes</strong>.</p>
            <p>If you did not request this, please disregard this email.</p>
          </div>`,
        });
        console.log(`[OTP] Email dispatched successfully to ${normalizedEmail}`);
      } catch (emailError) {
        console.warn(`[OTP] Failed sending email via SMTP: ${emailError.message}`);
        logOtpToConsole(normalizedEmail, otpCode);
      }
    } else {
      // If no SMTP is configured, log the OTP to the server console
      logOtpToConsole(normalizedEmail, otpCode);
    }

    res.json({
      success: true,
      message: 'A 6-digit OTP code has been sent. Check your inbox or server logs.',
      // Return code in dev/testing mode if explicitly enabled for convenience
      ...(process.env.EXPOSE_OTP_IN_RESPONSE === 'true' && { debugOtp: otpCode }),
    });
  } catch (err) {
    next(err);
  }
};

const logOtpToConsole = (email, code) => {
  console.log('\n========================================================');
  console.log(`  [STOCKSENSE OTP VERIFICATION CODE]`);
  console.log(`  Target Email : ${email}`);
  console.log(`  OTP Code     : >>>  ${code}  <<<`);
  console.log(`  Validity     : 10 minutes`);
  console.log('========================================================\n');
};

// Reset Password - Verify OTP & Update Password
const resetPassword = async (req, res, next) => {
  try {
    const { email, code, newPassword } = req.body;

    if (!email || !code || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Email, OTP code, and new password are required.',
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 6 characters long.',
      });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const trimmedCode = code.toString().trim();

    // Verify OTP token
    const otpRecord = await OtpToken.findOne({
      email: normalizedEmail,
      code: trimmedCode,
      expiresAt: { $gt: new Date() },
    });

    if (!otpRecord) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired OTP code. Please request a new code.',
      });
    }

    // Find User and update password
    const user = await User.findOne({ email: normalizedEmail });
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User account not found.',
      });
    }

    const salt = await bcrypt.genSalt(10);
    user.passwordHash = await bcrypt.hash(newPassword, salt);
    await user.save();

    // Delete used OTP
    await OtpToken.deleteMany({ email: normalizedEmail });

    res.json({
      success: true,
      message: 'Password reset successful. You may now log in with your new password.',
    });
  } catch (err) {
    next(err);
  }
};

// Current User Profile
const getMe = async (req, res) => {
  res.json({
    success: true,
    user: req.user,
  });
};

module.exports = {
  signup,
  login,
  forgotPassword,
  resetPassword,
  getMe,
};

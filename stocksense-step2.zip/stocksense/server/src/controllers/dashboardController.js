const {
  Product,
  StockLevel,
  Receipt,
  DeliveryOrder,
  InternalTransfer,
  Adjustment,
  StockLedger,
  Warehouse,
  Category,
} = require('../models');

const getDashboardStats = async (req, res, next) => {
  try {
    const { warehouseId, docType, status, categoryId } = req.query;

    const warehouseFilter = warehouseId && warehouseId !== 'all' ? { warehouse: warehouseId } : {};

    // 1. Total Products Count
    const productQuery = {};
    if (categoryId && categoryId !== 'all') {
      productQuery.category = categoryId;
    }
    const totalProducts = await Product.countDocuments(productQuery);

    // 2. Stock levels & Low Stock items
    const stockLevels = await StockLevel.find(warehouseFilter)
      .populate({
        path: 'product',
        populate: { path: 'category', select: 'name' },
      })
      .populate('warehouse', 'name code location');

    // Aggregate low stock alerts per location
    const allProducts = await Product.find(productQuery).populate('category', 'name');
    const allWarehouses = await Warehouse.find().select('name code location');

    const lowStockAlerts = [];
    const productOverallQty = {};

    // Map stocks
    stockLevels.forEach((sl) => {
      if (sl.product && sl.warehouse) {
        const pId = sl.product._id.toString();
        productOverallQty[pId] = (productOverallQty[pId] || 0) + sl.quantity;

        const threshold = sl.product.reorderPoint !== undefined ? sl.product.reorderPoint : 10;
        if (sl.quantity <= threshold) {
          lowStockAlerts.push({
            productId: sl.product._id,
            productName: sl.product.name,
            sku: sl.product.sku,
            unitOfMeasure: sl.product.unitOfMeasure,
            categoryName: sl.product.category?.name || 'General',
            warehouseId: sl.warehouse._id,
            warehouseName: sl.warehouse.name,
            warehouseCode: sl.warehouse.code,
            currentQty: sl.quantity,
            reorderPoint: threshold,
            deficit: threshold - sl.quantity,
            isZero: sl.quantity === 0,
          });
        }
      }
    });

    // Check if any product has zero total stock or unstocked warehouse
    let outOfStockCount = 0;
    let lowStockCount = 0;

    allProducts.forEach((p) => {
      const total = productOverallQty[p._id.toString()] || 0;
      const reorder = p.reorderPoint !== undefined ? p.reorderPoint : 10;
      if (total === 0) {
        outOfStockCount++;
      } else if (total <= reorder) {
        lowStockCount++;
      }
    });

    // 3. Pending Operations Count
    const receiptQuery = {
      status: { $in: ['draft', 'waiting', 'ready'] },
      ...(warehouseId && warehouseId !== 'all' && { warehouse: warehouseId }),
    };
    const pendingReceiptsCount = await Receipt.countDocuments(receiptQuery);

    const deliveryQuery = {
      status: { $in: ['draft', 'waiting', 'ready'] },
      ...(warehouseId && warehouseId !== 'all' && { warehouse: warehouseId }),
    };
    const pendingDeliveriesCount = await DeliveryOrder.countDocuments(deliveryQuery);

    const transferQuery = {
      status: { $in: ['draft', 'waiting', 'ready'] },
      ...(warehouseId && warehouseId !== 'all' && {
        $or: [{ fromWarehouse: warehouseId }, { toWarehouse: warehouseId }],
      }),
    };
    const internalTransfersCount = await InternalTransfer.countDocuments(transferQuery);

    // 4. Filtered Operations List for Dynamic Filters Table
    const activeDocType = docType || 'all';
    const activeStatus = status && status !== 'all' ? status : null;

    let operationsList = [];

    // Helper status match
    const matchStatus = (itemStatus) => (!activeStatus || itemStatus === activeStatus);

    // Fetch Receipts
    if (activeDocType === 'all' || activeDocType === 'receipts') {
      const q = {
        ...(activeStatus && { status: activeStatus }),
        ...(warehouseId && warehouseId !== 'all' && { warehouse: warehouseId }),
      };
      const receipts = await Receipt.find(q)
        .populate('warehouse', 'name code')
        .populate('lines.product', 'name sku')
        .sort({ createdAt: -1 })
        .limit(15);

      receipts.forEach((r) => {
        operationsList.push({
          id: r._id,
          docType: 'Receipt',
          typeBadge: 'Incoming',
          number: r.receiptNumber || `REC-${r._id.toString().slice(-6).toUpperCase()}`,
          partner: r.supplier,
          partnerLabel: 'Supplier',
          warehouse: `${r.warehouse?.code} - ${r.warehouse?.name}`,
          itemCount: r.lines?.length || 0,
          status: r.status,
          date: r.createdAt,
          notes: r.notes,
        });
      });
    }

    // Fetch Deliveries
    if (activeDocType === 'all' || activeDocType === 'delivery') {
      const q = {
        ...(activeStatus && { status: activeStatus }),
        ...(warehouseId && warehouseId !== 'all' && { warehouse: warehouseId }),
      };
      const deliveries = await DeliveryOrder.find(q)
        .populate('warehouse', 'name code')
        .populate('lines.product', 'name sku')
        .sort({ createdAt: -1 })
        .limit(15);

      deliveries.forEach((d) => {
        operationsList.push({
          id: d._id,
          docType: 'Delivery',
          typeBadge: 'Outgoing',
          number: d.orderNumber || `DEL-${d._id.toString().slice(-6).toUpperCase()}`,
          partner: d.customer,
          partnerLabel: 'Customer',
          warehouse: `${d.warehouse?.code} - ${d.warehouse?.name}`,
          itemCount: d.lines?.length || 0,
          status: d.status,
          date: d.createdAt,
          notes: d.notes,
        });
      });
    }

    // Fetch Internal Transfers
    if (activeDocType === 'all' || activeDocType === 'internal') {
      const q = {
        ...(activeStatus && { status: activeStatus }),
        ...(warehouseId && warehouseId !== 'all' && {
          $or: [{ fromWarehouse: warehouseId }, { toWarehouse: warehouseId }],
        }),
      };
      const transfers = await InternalTransfer.find(q)
        .populate('fromWarehouse', 'name code')
        .populate('toWarehouse', 'name code')
        .populate('lines.product', 'name sku')
        .sort({ createdAt: -1 })
        .limit(15);

      transfers.forEach((t) => {
        operationsList.push({
          id: t._id,
          docType: 'Transfer',
          typeBadge: 'Internal',
          number: t.transferNumber || `TRF-${t._id.toString().slice(-6).toUpperCase()}`,
          partner: `${t.fromWarehouse?.code} → ${t.toWarehouse?.code}`,
          partnerLabel: 'Route',
          warehouse: `${t.fromWarehouse?.name} → ${t.toWarehouse?.name}`,
          itemCount: t.lines?.length || 0,
          status: t.status,
          date: t.createdAt,
          notes: t.notes,
        });
      });
    }

    // Fetch Adjustments
    if (activeDocType === 'all' || activeDocType === 'adjustments') {
      const q = {
        ...(activeStatus && { status: activeStatus }),
        ...(warehouseId && warehouseId !== 'all' && { warehouse: warehouseId }),
      };
      const adjustments = await Adjustment.find(q)
        .populate('warehouse', 'name code')
        .populate('product', 'name sku')
        .sort({ createdAt: -1 })
        .limit(15);

      adjustments.forEach((a) => {
        operationsList.push({
          id: a._id,
          docType: 'Adjustment',
          typeBadge: 'Audit',
          number: a.adjustmentNumber || `ADJ-${a._id.toString().slice(-6).toUpperCase()}`,
          partner: `${a.product?.name} (${a.diff >= 0 ? '+' : ''}${a.diff})`,
          partnerLabel: 'Stock Diff',
          warehouse: `${a.warehouse?.code} - ${a.warehouse?.name}`,
          itemCount: 1,
          status: a.status,
          date: a.createdAt,
          notes: a.reason,
        });
      });
    }

    // Sort combined operations by date descending
    operationsList.sort((a, b) => new Date(b.date) - new Date(a.date));

    // 5. Recent Movements from StockLedger
    const recentMovements = await StockLedger.find(warehouseFilter)
      .sort({ timestamp: -1 })
      .limit(8)
      .populate('product', 'name sku unitOfMeasure')
      .populate('warehouse', 'name code');

    // 6. Warehouses and Categories list for filters
    const warehouses = await Warehouse.find().select('name code location');
    const categories = await Category.find().select('name');

    res.json({
      success: true,
      stats: {
        totalProducts,
        lowStockCount,
        outOfStockCount,
        totalLowStockAlerts: lowStockAlerts.length,
        pendingReceiptsCount,
        pendingDeliveriesCount,
        internalTransfersCount,
      },
      lowStockAlerts,
      operationsList,
      recentMovements,
      warehouses,
      categories,
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getDashboardStats,
};

const express = require('express');
const router = express.Router();
const { Warehouse, StockLevel } = require('../models');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { emitStockUpdate } = require('../socket');

// GET all warehouses with stock summary
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const warehouses = await Warehouse.find().sort({ code: 1 });

    const warehousesWithStats = await Promise.all(
      warehouses.map(async (w) => {
        const stocks = await StockLevel.find({ warehouse: w._id });
        const totalItems = stocks.reduce((sum, s) => sum + s.quantity, 0);
        const distinctProducts = stocks.filter((s) => s.quantity > 0).length;
        return {
          ...w.toObject(),
          totalItems,
          distinctProducts,
        };
      })
    );

    res.json({ success: true, warehouses: warehousesWithStats });
  } catch (err) {
    next(err);
  }
});

// POST create warehouse
router.post('/', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const { name, code, location } = req.body;
    if (!name || !code || !location) {
      return res.status(400).json({ success: false, message: 'Name, code, and location are required.' });
    }

    const trimmedCode = code.trim().toUpperCase();
    const existing = await Warehouse.findOne({ code: trimmedCode });
    if (existing) {
      return res.status(409).json({ success: false, message: `Warehouse code ${trimmedCode} is already in use.` });
    }

    const warehouse = await Warehouse.create({
      name: name.trim(),
      code: trimmedCode,
      location: location.trim(),
    });

    emitStockUpdate({ type: 'warehouse_created', warehouseId: warehouse._id });

    res.status(201).json({ success: true, warehouse });
  } catch (err) {
    next(err);
  }
});

// PUT update warehouse
router.put('/:id', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const { name, code, location } = req.body;
    const warehouse = await Warehouse.findById(req.params.id);
    if (!warehouse) {
      return res.status(404).json({ success: false, message: 'Warehouse not found.' });
    }

    if (code) {
      const trimmedCode = code.trim().toUpperCase();
      const existing = await Warehouse.findOne({
        code: trimmedCode,
        _id: { $ne: req.params.id },
      });
      if (existing) {
        return res.status(409).json({ success: false, message: `Warehouse code ${trimmedCode} is already in use.` });
      }
      warehouse.code = trimmedCode;
    }

    if (name) warehouse.name = name.trim();
    if (location) warehouse.location = location.trim();

    await warehouse.save();
    emitStockUpdate({ type: 'warehouse_updated', warehouseId: warehouse._id });

    res.json({ success: true, warehouse });
  } catch (err) {
    next(err);
  }
});

// DELETE warehouse
router.delete('/:id', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const activeStock = await StockLevel.findOne({
      warehouse: req.params.id,
      quantity: { $gt: 0 },
    });

    if (activeStock) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete warehouse: It still contains recorded inventory quantities. Transfer or adjust stock to 0 first.',
      });
    }

    const warehouse = await Warehouse.findByIdAndDelete(req.params.id);
    if (!warehouse) {
      return res.status(404).json({ success: false, message: 'Warehouse not found.' });
    }

    // Clean up empty StockLevels for this warehouse
    await StockLevel.deleteMany({ warehouse: req.params.id });

    emitStockUpdate({ type: 'warehouse_deleted', warehouseId: req.params.id });

    res.json({ success: true, message: 'Warehouse deleted successfully.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

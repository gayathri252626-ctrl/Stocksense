const express = require('express');
const router = express.Router();
const { Category, Product } = require('../models');
const { authenticateToken, requireRole } = require('../middleware/auth');

// GET all categories with product counts
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const categories = await Category.find().sort({ name: 1 });
    
    // Count products per category
    const categoriesWithCount = await Promise.all(
      categories.map(async (cat) => {
        const productCount = await Product.countDocuments({ category: cat._id });
        return {
          ...cat.toObject(),
          productCount,
        };
      })
    );

    res.json({ success: true, categories: categoriesWithCount });
  } catch (err) {
    next(err);
  }
});

// POST create category
router.post('/', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const { name, description } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Category name is required.' });
    }

    const trimmedName = name.trim();
    const existing = await Category.findOne({ name: new RegExp(`^${trimmedName}$`, 'i') });
    if (existing) {
      return res.status(409).json({ success: false, message: 'A category with this name already exists.' });
    }

    const category = await Category.create({
      name: trimmedName,
      description: description ? description.trim() : '',
    });

    res.status(201).json({ success: true, category });
  } catch (err) {
    next(err);
  }
});

// PUT update category
router.put('/:id', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const { name, description } = req.body;
    const category = await Category.findById(req.params.id);
    if (!category) {
      return res.status(404).json({ success: false, message: 'Category not found.' });
    }

    if (name && name.trim()) {
      const trimmedName = name.trim();
      const existing = await Category.findOne({
        name: new RegExp(`^${trimmedName}$`, 'i'),
        _id: { $ne: req.params.id },
      });
      if (existing) {
        return res.status(409).json({ success: false, message: 'Another category with this name already exists.' });
      }
      category.name = trimmedName;
    }

    if (description !== undefined) {
      category.description = description.trim();
    }

    await category.save();
    res.json({ success: true, category });
  } catch (err) {
    next(err);
  }
});

// DELETE category
router.delete('/:id', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const productCount = await Product.countDocuments({ category: req.params.id });
    if (productCount > 0) {
      return res.status(400).json({
        success: false,
        message: `Cannot delete category: ${productCount} product(s) are assigned to it. Reassign them first.`,
      });
    }

    const category = await Category.findByIdAndDelete(req.params.id);
    if (!category) {
      return res.status(404).json({ success: false, message: 'Category not found.' });
    }

    res.json({ success: true, message: 'Category deleted successfully.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const { Product, StockLevel, StockLedger, Category, Warehouse } = require('../models');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { emitStockUpdate } = require('../socket');

// GET all products with warehouse breakdown and filters
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const { search, category, warehouseId } = req.query;

    const filter = {};
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      filter.$or = [{ name: searchRegex }, { sku: searchRegex }];
    }
    if (category && category !== 'all') {
      filter.category = category;
    }

    const products = await Product.find(filter)
      .populate('category', 'name')
      .sort({ createdAt: -1 });

    const allWarehouses = await Warehouse.find().select('name code');
    const stockLevels = await StockLevel.find().populate('warehouse', 'name code location');

    // Enrich each product
    const enrichedProducts = products.map((prod) => {
      const prodStocks = stockLevels.filter(
        (sl) => sl.product.toString() === prod._id.toString()
      );

      // Map stock for each known warehouse (even if 0)
      const stockPerWarehouse = allWarehouses.map((w) => {
        const matchingLevel = prodStocks.find(
          (sl) => sl.warehouse?._id?.toString() === w._id.toString()
        );
        return {
          warehouse: w,
          quantity: matchingLevel ? matchingLevel.quantity : 0,
        };
      });

      const totalQty = stockPerWarehouse.reduce((sum, s) => sum + s.quantity, 0);

      // Check if low stock at any warehouse or overall
      const reorderPoint = prod.reorderPoint !== undefined ? prod.reorderPoint : 10;
      const isOutOfStock = totalQty === 0;
      const isLowStock = totalQty <= reorderPoint;

      // Warehouse-specific low stock check
      const lowStockWarehouses = stockPerWarehouse.filter(
        (s) => s.quantity <= reorderPoint
      );

      return {
        ...prod.toObject(),
        totalQty,
        stockPerWarehouse,
        isOutOfStock,
        isLowStock,
        lowStockWarehouses,
      };
    });

    // Optional filter by warehouse availability if specified
    let finalProducts = enrichedProducts;
    if (warehouseId && warehouseId !== 'all') {
      finalProducts = enrichedProducts.filter((p) => {
        const wStock = p.stockPerWarehouse.find(
          (sw) => sw.warehouse._id.toString() === warehouseId
        );
        return wStock && wStock.quantity > 0;
      });
    }

    res.json({ success: true, products: finalProducts });
  } catch (err) {
    next(err);
  }
});

// GET single product by ID
router.get('/:id', authenticateToken, async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id).populate('category');
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    const stockLevels = await StockLevel.find({ product: product._id }).populate(
      'warehouse',
      'name code location'
    );

    const totalQty = stockLevels.reduce((sum, s) => sum + s.quantity, 0);

    res.json({
      success: true,
      product: {
        ...product.toObject(),
        totalQty,
        stockLevels,
      },
    });
  } catch (err) {
    next(err);
  }
});

// POST create product
router.post('/', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const {
      name,
      sku,
      category,
      unitOfMeasure,
      reorderPoint,
      initialWarehouseId,
      initialStock,
      description,
    } = req.body;

    if (!name || !sku || !category) {
      return res.status(400).json({
        success: false,
        message: 'Product name, SKU, and category are required.',
      });
    }

    const trimmedSku = sku.trim().toUpperCase();
    const existing = await Product.findOne({ sku: trimmedSku });
    if (existing) {
      return res.status(409).json({
        success: false,
        message: `Product SKU "${trimmedSku}" is already in use. SKUs must be unique.`,
      });
    }

    const product = await Product.create({
      name: name.trim(),
      sku: trimmedSku,
      category,
      unitOfMeasure: unitOfMeasure ? unitOfMeasure.trim() : 'pcs',
      reorderPoint: reorderPoint !== undefined && reorderPoint !== '' ? Number(reorderPoint) : 10,
      description: description ? description.trim() : '',
    });

    // Handle optional initial stock
    const parsedInitialStock = Number(initialStock);
    if (initialWarehouseId && parsedInitialStock > 0) {
      await StockLevel.findOneAndUpdate(
        { product: product._id, warehouse: initialWarehouseId },
        { quantity: parsedInitialStock },
        { upsert: true, new: true }
      );

      // Record in StockLedger
      await StockLedger.create({
        product: product._id,
        warehouse: initialWarehouseId,
        qtyChange: parsedInitialStock,
        type: 'initial',
        notes: `Initial stock registration for ${product.name}`,
        timestamp: new Date(),
      });
    }

    emitStockUpdate({ type: 'product_created', productId: product._id });

    const populated = await Product.findById(product._id).populate('category');
    res.status(201).json({ success: true, product: populated });
  } catch (err) {
    next(err);
  }
});

// PUT update product
router.put('/:id', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const {
      name,
      sku,
      category,
      unitOfMeasure,
      reorderPoint,
      description,
      stockUpdates, // Optional array: [{ warehouseId, quantity }]
    } = req.body;

    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    if (sku) {
      const trimmedSku = sku.trim().toUpperCase();
      const existing = await Product.findOne({
        sku: trimmedSku,
        _id: { $ne: req.params.id },
      });
      if (existing) {
        return res.status(409).json({
          success: false,
          message: `Product SKU "${trimmedSku}" is already assigned to another product.`,
        });
      }
      product.sku = trimmedSku;
    }

    if (name) product.name = name.trim();
    if (category) product.category = category;
    if (unitOfMeasure) product.unitOfMeasure = unitOfMeasure.trim();
    if (reorderPoint !== undefined) product.reorderPoint = Number(reorderPoint);
    if (description !== undefined) product.description = description.trim();

    await product.save();

    // If stock updates are provided per location
    if (Array.isArray(stockUpdates)) {
      for (const update of stockUpdates) {
        if (update.warehouseId && update.quantity !== undefined) {
          const newQty = Math.max(0, Number(update.quantity));
          const current = await StockLevel.findOne({
            product: product._id,
            warehouse: update.warehouseId,
          });

          const oldQty = current ? current.quantity : 0;
          const diff = newQty - oldQty;

          if (diff !== 0) {
            await StockLevel.findOneAndUpdate(
              { product: product._id, warehouse: update.warehouseId },
              { quantity: newQty },
              { upsert: true }
            );

            await StockLedger.create({
              product: product._id,
              warehouse: update.warehouseId,
              qtyChange: diff,
              type: 'adjustment',
              notes: `Manual stock level adjustment on product edit (old: ${oldQty}, new: ${newQty})`,
              timestamp: new Date(),
            });
          }
        }
      }
    }

    emitStockUpdate({ type: 'product_updated', productId: product._id });

    const updated = await Product.findById(product._id).populate('category');
    res.json({ success: true, product: updated });
  } catch (err) {
    next(err);
  }
});

// DELETE product
router.delete('/:id', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    // Check if positive stock exists
    const stockLevels = await StockLevel.find({ product: product._id });
    const totalQty = stockLevels.reduce((sum, s) => sum + s.quantity, 0);

    if (totalQty > 0) {
      return res.status(400).json({
        success: false,
        message: `Cannot delete product: There are still ${totalQty} ${product.unitOfMeasure} recorded in warehouse stock. Adjust or deliver stock to 0 first.`,
      });
    }

    await StockLevel.deleteMany({ product: product._id });
    await Product.findByIdAndDelete(req.params.id);

    emitStockUpdate({ type: 'product_deleted', productId: req.params.id });

    res.json({ success: true, message: 'Product deleted successfully.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const mongoose = require('mongoose');

const stockLevelSchema = new mongoose.Schema(
  {
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: [true, 'Product reference is required'],
    },
    warehouse: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Warehouse',
      required: [true, 'Warehouse reference is required'],
    },
    quantity: {
      type: Number,
      required: true,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

// Compound index to guarantee uniqueness per product per warehouse
stockLevelSchema.index({ product: 1, warehouse: 1 }, { unique: true });

module.exports = mongoose.model('StockLevel', stockLevelSchema);

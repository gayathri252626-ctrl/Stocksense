const mongoose = require('mongoose');

const stockLedgerSchema = new mongoose.Schema(
  {
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: [true, 'Product reference is required'],
    },
    warehouse: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Warehouse',
      required: [true, 'Warehouse reference is required'],
    },
    qtyChange: {
      type: Number,
      required: [true, 'Quantity change is required'],
    },
    type: {
      type: String,
      enum: ['receipt', 'delivery', 'transfer_in', 'transfer_out', 'adjustment', 'initial'],
      required: [true, 'Movement type is required'],
    },
    refDocId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null,
    },
    refDocType: {
      type: String,
      enum: ['Receipt', 'DeliveryOrder', 'InternalTransfer', 'Adjustment', 'InitialStock', null],
      default: null,
    },
    timestamp: {
      type: Date,
      default: Date.now,
      index: true,
    },
    notes: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('StockLedger', stockLedgerSchema);

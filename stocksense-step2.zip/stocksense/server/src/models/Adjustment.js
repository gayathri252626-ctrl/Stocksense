const mongoose = require('mongoose');

const adjustmentSchema = new mongoose.Schema(
  {
    adjustmentNumber: {
      type: String,
      unique: true,
      trim: true,
    },
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: [true, 'Product reference is required'],
    },
    warehouse: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Warehouse',
      required: [true, 'Warehouse reference is required'],
    },
    systemQty: {
      type: Number,
      required: [true, 'System recorded quantity is required'],
    },
    countedQty: {
      type: Number,
      required: [true, 'Counted physical quantity is required'],
    },
    diff: {
      type: Number,
      required: [true, 'Quantity difference is required'],
    },
    reason: {
      type: String,
      trim: true,
      default: '',
    },
    status: {
      type: String,
      enum: ['draft', 'applied'],
      default: 'draft',
    },
  },
  {
    timestamps: true,
  }
);

// Calculate diff before saving if not set
adjustmentSchema.pre('validate', function (next) {
  if (this.countedQty !== undefined && this.systemQty !== undefined) {
    this.diff = this.countedQty - this.systemQty;
  }
  next();
});

module.exports = mongoose.model('Adjustment', adjustmentSchema);

const mongoose = require('mongoose');

let mongodInstance = null;

const connectDB = async () => {
  const uri = process.env.MONGODB_URI;

  // Option 1: If MONGODB_URI is provided and not forced to memory, try connecting
  if (uri && process.env.USE_MEMORY_DB !== 'true') {
    try {
      const conn = await mongoose.connect(uri, {
        serverSelectionTimeoutMS: 4000,
      });
      console.log(`[Database] MongoDB connected: ${conn.connection.host}`);
      return conn;
    } catch (err) {
      console.warn(`[Database] Could not connect to configured MONGODB_URI: ${err.message}`);
      console.log('[Database] Falling back to MongoMemoryServer for instant zero-config operation...');
    }
  }

  // Option 2: Fallback to MongoMemoryServer
  try {
    const { MongoMemoryServer } = require('mongodb-memory-server');
    mongodInstance = await MongoMemoryServer.create({
      instance: {
        dbName: 'stocksense',
      },
    });
    const memoryUri = mongodInstance.getUri();
    const conn = await mongoose.connect(memoryUri);
    console.log(`[Database] Connected to in-memory MongoMemoryServer: ${memoryUri}`);
    return conn;
  } catch (err) {
    console.error(`[Database] Fatal: Unable to initialize in-memory database: ${err.message}`);
    // If MongoMemoryServer download failed, still attempt standard local connection
    try {
      const fallbackUri = uri || 'mongodb://127.0.0.1:27017/stocksense';
      const conn = await mongoose.connect(fallbackUri);
      console.log(`[Database] Connected to local MongoDB: ${fallbackUri}`);
      return conn;
    } catch (finalErr) {
      console.error(`[Database] Failed all database connections: ${finalErr.message}`);
      throw finalErr;
    }
  }
};

const disconnectDB = async () => {
  try {
    await mongoose.disconnect();
    if (mongodInstance) {
      await mongodInstance.stop();
    }
  } catch (err) {
    console.error('[Database] Disconnect error:', err);
  }
};

module.exports = { connectDB, disconnectDB };

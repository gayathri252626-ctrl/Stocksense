require('dotenv').config();
const http = require('http');
const { app, server } = require('./server');
const { connectDB, disconnectDB } = require('./config/db');
const { User, OtpToken } = require('./models');
const { io: ClientIO } = require('socket.io-client');

const runTests = async () => {
  console.log('🧪 Starting StockSense Auth & System Integration Tests...\n');

  let testServer;
  const TEST_PORT = 5055;

  try {
    await connectDB();

    await new Promise((resolve) => {
      testServer = server.listen(TEST_PORT, () => {
        console.log(`[Test Server] Running on http://127.0.0.1:${TEST_PORT}`);
        resolve();
      });
    });

    const baseUrl = `http://127.0.0.1:${TEST_PORT}/api`;

    const request = async (endpoint, method = 'GET', body = null, token = null) => {
      const headers = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`${baseUrl}${endpoint}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : null,
      });

      const data = await res.json();
      return { status: res.status, data };
    };

    // Test 1: Health check
    console.log('--- Test 1: Health Check ---');
    const health = await request('/health');
    console.log('Health status:', health.status, health.data);
    if (health.status !== 200 || health.data.status !== 'healthy') throw new Error('Health check failed');
    console.log('✅ Health check passed\n');

    // Test 2: Signup
    console.log('--- Test 2: User Signup ---');
    const testEmail = `tester_${Date.now()}@example.com`;
    const signupRes = await request('/auth/signup', 'POST', {
      name: 'John Inventory Tester',
      email: testEmail,
      password: 'password123',
      role: 'manager',
    });
    console.log('Signup status:', signupRes.status, signupRes.data.message);
    if (signupRes.status !== 201 || !signupRes.data.token) throw new Error('Signup failed');
    console.log('✅ Signup passed with token\n');

    // Test 3: Login
    console.log('--- Test 3: User Login ---');
    const loginRes = await request('/auth/login', 'POST', {
      email: testEmail,
      password: 'password123',
    });
    console.log('Login status:', loginRes.status, loginRes.data.user);
    if (loginRes.status !== 200 || !loginRes.data.token) throw new Error('Login failed');
    const userToken = loginRes.data.token;
    console.log('✅ Login passed\n');

    // Test 4: Protected route `/auth/me`
    console.log('--- Test 4: Protected Profile (/api/auth/me) ---');
    const meRes = await request('/auth/me', 'GET', null, userToken);
    console.log('Me status:', meRes.status, meRes.data.user.name, meRes.data.user.email);
    if (meRes.status !== 200 || meRes.data.user.email !== testEmail) throw new Error('Auth /me failed');
    console.log('✅ Protected /me passed\n');

    // Test 5: Forgot Password (OTP Generation)
    console.log('--- Test 5: Forgot Password (OTP) ---');
    const forgotRes = await request('/auth/forgot-password', 'POST', {
      email: testEmail,
    });
    console.log('Forgot status:', forgotRes.status, forgotRes.data.message);
    if (forgotRes.status !== 200) throw new Error('Forgot password request failed');

    // Verify OTP exists in OtpToken model
    const otpDoc = await OtpToken.findOne({ email: testEmail });
    if (!otpDoc || !otpDoc.code || otpDoc.code.length !== 6) {
      throw new Error('OTP token not found in database or invalid length');
    }
    console.log(`Found OTP in database: ${otpDoc.code}, expires: ${otpDoc.expiresAt}`);
    console.log('✅ Forgot password OTP generated and persisted\n');

    // Test 6: Reset Password with OTP
    console.log('--- Test 6: Reset Password ---');
    const resetRes = await request('/auth/reset-password', 'POST', {
      email: testEmail,
      code: otpDoc.code,
      newPassword: 'newSecretPassword456',
    });
    console.log('Reset status:', resetRes.status, resetRes.data.message);
    if (resetRes.status !== 200) throw new Error('Reset password failed');

    // Check OTP was consumed
    const consumedOtp = await OtpToken.findOne({ email: testEmail });
    if (consumedOtp) throw new Error('OTP should be deleted after use');
    console.log('✅ Reset password passed and OTP was invalidated\n');

    // Test 7: Login with old password should fail, new should succeed
    console.log('--- Test 7: Verify New Credentials ---');
    const oldLogin = await request('/auth/login', 'POST', {
      email: testEmail,
      password: 'password123',
    });
    if (oldLogin.status === 200) throw new Error('Old password should not work anymore');
    console.log('Old password rejected as expected (401)');

    const newLogin = await request('/auth/login', 'POST', {
      email: testEmail,
      password: 'newSecretPassword456',
    });
    if (newLogin.status !== 200) throw new Error('Login with new password failed');
    console.log('New password login successful (200)');
    console.log('✅ Credential change verification passed\n');

    // Test 8: Dashboard KPIs
    console.log('--- Test 8: Dashboard KPIs API ---');
    const statsRes = await request('/dashboard/stats', 'GET', null, newLogin.data.token);
    console.log('Stats status:', statsRes.status, 'Total Products:', statsRes.data.stats.totalProducts);
    if (statsRes.status !== 200 || statsRes.data.stats === undefined) throw new Error('Stats API failed');
    console.log('✅ Dashboard stats endpoint verified\n');

    // Test 9: Socket.io Client Connection
    console.log('--- Test 9: Socket.io Connection ---');
    const socketClient = ClientIO(`http://127.0.0.1:${TEST_PORT}`, {
      transports: ['websocket', 'polling'],
      reconnection: false,
    });

    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Socket.io connection timed out')), 4000);
      socketClient.on('connect', () => {
        clearTimeout(timeout);
        console.log(`Socket client connected successfully: ${socketClient.id}`);
        socketClient.emit('join:warehouse', 'MW-01');
        socketClient.disconnect();
        resolve();
      });
      socketClient.on('connect_error', (err) => {
        clearTimeout(timeout);
        reject(err);
      });
    });
    console.log('✅ Socket.io client connection verified\n');

    console.log('🎉 ALL INTEGRATION TESTS PASSED WITH 100% SUCCESS!');
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exitCode = 1;
  } finally {
    if (testServer) {
      testServer.close();
    }
    await disconnectDB();
    process.exit(process.exitCode || 0);
  }
};

runTests();

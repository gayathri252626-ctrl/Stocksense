require('dotenv').config();
const bcrypt = require('bcryptjs');
const { connectDB, disconnectDB } = require('./config/db');
const {
  User,
  Warehouse,
  Category,
  Product,
  StockLevel,
  Receipt,
  DeliveryOrder,
  InternalTransfer,
  Adjustment,
  StockLedger,
  OtpToken,
} = require('./models');

const seedData = async () => {
  console.log('🌱 Starting StockSense database seeding...');

  try {
    // 1. Clear existing collections
    await Promise.all([
      User.deleteMany({}),
      Warehouse.deleteMany({}),
      Category.deleteMany({}),
      Product.deleteMany({}),
      StockLevel.deleteMany({}),
      Receipt.deleteMany({}),
      DeliveryOrder.deleteMany({}),
      InternalTransfer.deleteMany({}),
      Adjustment.deleteMany({}),
      StockLedger.deleteMany({}),
      OtpToken.deleteMany({}),
    ]);
    console.log('🧹 Cleaned existing database collections');

    // 2. Create Demo Users (Manager + Staff)
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash('password123', salt);

    const [managerUser, staffUser] = await User.create([
      {
        name: 'Alex Vance (Manager)',
        email: 'manager@stocksense.com',
        passwordHash,
        role: 'manager',
      },
      {
        name: 'Sam Fisher (Staff)',
        email: 'staff@stocksense.com',
        passwordHash,
        role: 'staff',
      },
    ]);
    console.log('✅ Created 2 demo users:');
    console.log('   - manager@stocksense.com / password123 (Manager)');
    console.log('   - staff@stocksense.com   / password123 (Staff)');

    // 3. Create 2 Warehouses
    const [warehouseMain, warehouseProd] = await Warehouse.create([
      {
        name: 'Main Central Warehouse',
        code: 'MW-01',
        location: 'Bay 4, 100 Logistics Blvd, Austin TX',
      },
      {
        name: 'Production Assembly Floor',
        code: 'PF-01',
        location: 'Building B, 200 Fabrication Way, Austin TX',
      },
    ]);
    console.log('✅ Created 2 warehouses: MW-01 and PF-01');

    // 4. Create Categories
    const categories = await Category.create([
      { name: 'Raw Materials', description: 'Metals, polymers, and raw stock' },
      { name: 'Finished Goods', description: 'Complete assembled consumer products' },
      { name: 'Hardware & Fasteners', description: 'Bolts, nuts, screws, and brackets' },
      { name: 'Packaging Supplies', description: 'Boxes, bubble wrap, tape, and labels' },
    ]);
    const [rawCat, finishedCat, hardwareCat, packagingCat] = categories;
    console.log('✅ Created 4 categories');

    // 5. Create 5 Products
    const products = await Product.create([
      {
        name: 'Steel Rods (10mm x 3m)',
        sku: 'STL-ROD-010',
        category: rawCat._id,
        unitOfMeasure: 'kg',
        reorderPoint: 50,
        description: 'High tensile structural grade steel rods',
      },
      {
        name: 'Executive Ergonomic Chair',
        sku: 'CHR-OFF-EXEC',
        category: finishedCat._id,
        unitOfMeasure: 'pcs',
        reorderPoint: 15,
        description: 'Mesh back ergonomic chair with adjustable lumbar support',
      },
      {
        name: 'Aluminum Sheets (4x8ft)',
        sku: 'ALM-SHT-4X8',
        category: rawCat._id,
        unitOfMeasure: 'sheets',
        reorderPoint: 25,
        description: 'Anodized 6061 aluminum alloy sheets',
      },
      {
        name: 'Heavy-Duty Corrugated Boxes (Large)',
        sku: 'BOX-PKG-LRG',
        category: packagingCat._id,
        unitOfMeasure: 'box',
        reorderPoint: 100,
        description: 'Double-walled corrugated shipping containers',
      },
      {
        name: 'Hex Flange Bolts (M8 x 40mm)',
        sku: 'BLT-HEX-M840',
        category: hardwareCat._id,
        unitOfMeasure: 'pcs',
        reorderPoint: 200,
        description: 'Zinc-plated grade 8.8 metric fasteners',
      },
    ]);
    console.log('✅ Created 5 products');

    // 6. Initial StockLevel entries & StockLedger initial records
    const stockEntries = [
      // Steel Rods: 120 in MW-01, 30 in PF-01 (Total 150 > Reorder 50) -> Normal
      { product: products[0]._id, warehouse: warehouseMain._id, quantity: 120 },
      { product: products[0]._id, warehouse: warehouseProd._id, quantity: 30 },

      // Executive Chair: 35 in MW-01, 0 in PF-01 (Total 35 > Reorder 15) -> Normal
      { product: products[1]._id, warehouse: warehouseMain._id, quantity: 35 },
      { product: products[1]._id, warehouse: warehouseProd._id, quantity: 0 },

      // Aluminum Sheets: 15 in MW-01, 5 in PF-01 (Total 20 <= Reorder 25) -> LOW STOCK ALERT!
      { product: products[2]._id, warehouse: warehouseMain._id, quantity: 15 },
      { product: products[2]._id, warehouse: warehouseProd._id, quantity: 5 },

      // Heavy-Duty Boxes: 260 in MW-01, 40 in PF-01 (Total 300 > Reorder 100) -> Normal
      { product: products[3]._id, warehouse: warehouseMain._id, quantity: 260 },
      { product: products[3]._id, warehouse: warehouseProd._id, quantity: 40 },

      // Hex Bolts: 90 in MW-01, 30 in PF-01 (Total 120 <= Reorder 200) -> LOW STOCK ALERT!
      { product: products[4]._id, warehouse: warehouseMain._id, quantity: 90 },
      { product: products[4]._id, warehouse: warehouseProd._id, quantity: 30 },
    ];

    await StockLevel.insertMany(stockEntries);
    console.log('✅ Inserted 10 initial StockLevel entries across both warehouses');

    // Create StockLedger audit history for initial stock
    const ledgerEntries = stockEntries.map((entry) => ({
      product: entry.product,
      warehouse: entry.warehouse,
      qtyChange: entry.quantity,
      type: 'initial',
      notes: 'Initial inventory baseline registration',
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    }));
    await StockLedger.insertMany(ledgerEntries);

    // 7. Seed Sample Receipts, Deliveries, and Transfers for rich Dashboard KPIs
    const [receipt1] = await Receipt.create([
      {
        receiptNumber: 'REC-2026-001',
        supplier: 'Apex Metallurgy Corp',
        warehouse: warehouseMain._id,
        lines: [
          { product: products[0]._id, qty: 50 },
          { product: products[2]._id, qty: 30 },
        ],
        status: 'waiting',
        notes: 'Expected delivery via freight carrier Tuesday morning',
      },
      {
        receiptNumber: 'REC-2026-002',
        supplier: 'Fastener Dynamics Ltd',
        warehouse: warehouseMain._id,
        lines: [
          { product: products[4]._id, qty: 500 },
        ],
        status: 'ready',
        notes: 'Items unloaded in staging bay, awaiting final quality validation',
      },
    ]);

    await DeliveryOrder.create([
      {
        orderNumber: 'DEL-2026-001',
        customer: 'BuildCorp Construction Systems',
        warehouse: warehouseMain._id,
        lines: [
          { product: products[1]._id, qty: 10 },
        ],
        status: 'ready',
        notes: 'Priority dispatch for downtown office contract',
      },
      {
        orderNumber: 'DEL-2026-002',
        customer: 'Global Tech Spaces LLC',
        warehouse: warehouseMain._id,
        lines: [
          { product: products[1]._id, qty: 5 },
          { product: products[3]._id, qty: 20 },
        ],
        status: 'waiting',
        notes: 'Customer pickup scheduled for Friday afternoon',
      },
    ]);

    await InternalTransfer.create([
      {
        transferNumber: 'TRF-2026-001',
        fromWarehouse: warehouseMain._id,
        toWarehouse: warehouseProd._id,
        lines: [
          { product: products[0]._id, qty: 25 },
        ],
        status: 'waiting',
        notes: 'Routine replenishment for manufacturing run #42',
      },
    ]);

    console.log('✅ Seeded demo operational receipts, deliveries, and transfers for live KPIs');
    console.log('🎉 Database seeding completed successfully!\n');
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    throw error;
  }
};

// If run directly from terminal
if (require.main === module) {
  (async () => {
    try {
      await connectDB();
      await seedData();
      await disconnectDB();
      process.exit(0);
    } catch (err) {
      console.error(err);
      process.exit(1);
    }
  })();
}

module.exports = seedData;

import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import Layout from './components/layout/Layout';

// Auth Pages
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import ForgotPassword from './pages/auth/ForgotPassword';
import ResetPassword from './pages/auth/ResetPassword';

// Operational & Dashboard Pages
import Dashboard from './pages/dashboard/Dashboard';
import ProductsPage from './pages/products/ProductsPage';
import ReceiptsPage from './pages/receipts/ReceiptsPage';
import DeliveryOrdersPage from './pages/deliveries/DeliveryOrdersPage';
import TransfersPage from './pages/transfers/TransfersPage';
import AdjustmentsPage from './pages/adjustments/AdjustmentsPage';
import MoveHistoryPage from './pages/move-history/MoveHistoryPage';
import WarehouseSettingsPage from './pages/settings/WarehouseSettingsPage';
import ProfilePage from './pages/profile/ProfilePage';

import api from './api/axios';

// Protected Route Guard
function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-950 text-slate-400">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs">Authenticating StockSense session...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}

// Public Route Guard (redirect to dashboard if already logged in)
function PublicRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) return null;
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }
  return children;
}

function MainAppRoutes() {
  const [activeWarehouse, setActiveWarehouse] = useState('');
  const [warehouses, setWarehouses] = useState([]);

  // Fetch warehouses for global header filter
  useEffect(() => {
    const loadWarehouses = async () => {
      try {
        const res = await api.get('/warehouses');
        setWarehouses(res.data.warehouses || []);
      } catch (err) {
        // Silent fail if unauthenticated or not yet ready
      }
    };
    loadWarehouses();
  }, []);

  return (
    <Routes>
      {/* Public Auth Routes */}
      <Route
        path="/login"
        element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        }
      />
      <Route
        path="/signup"
        element={
          <PublicRoute>
            <Signup />
          </PublicRoute>
        }
      />
      <Route
        path="/forgot-password"
        element={
          <PublicRoute>
            <ForgotPassword />
          </PublicRoute>
        }
      />
      <Route
        path="/reset-password"
        element={
          <PublicRoute>
            <ResetPassword />
          </PublicRoute>
        }
      />

      {/* Protected App Routes */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Layout
              activeWarehouse={activeWarehouse}
              setActiveWarehouse={setActiveWarehouse}
              warehouses={warehouses}
            />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route
          path="dashboard"
          element={
            <Dashboard
              activeWarehouse={activeWarehouse}
              setActiveWarehouse={setActiveWarehouse}
              warehouses={warehouses}
            />
          }
        />
        <Route path="products" element={<ProductsPage />} />
        <Route path="receipts" element={<ReceiptsPage />} />
        <Route path="deliveries" element={<DeliveryOrdersPage />} />
        <Route path="transfers" element={<TransfersPage />} />
        <Route path="adjustments" element={<AdjustmentsPage />} />
        <Route path="move-history" element={<MoveHistoryPage />} />
        <Route path="settings/warehouse" element={<WarehouseSettingsPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <SocketProvider>
          <MainAppRoutes />
        </SocketProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

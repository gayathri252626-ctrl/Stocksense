import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Boxes,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  SlidersHorizontal,
  History,
  Settings,
  Warehouse,
  User,
  LogOut,
  ChevronDown,
  Layers,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function Sidebar({ mobileOpen, setMobileOpen }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [profileOpen, setProfileOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(true);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navLinkClass = ({ isActive }) =>
    `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
      isActive
        ? 'bg-gradient-to-r from-brand-600/30 to-brand-500/10 text-brand-300 border border-brand-500/30 shadow-glow'
        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-850/60'
    }`;

  const navItems = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/products', label: 'Products', icon: Boxes },
  ];

  const operationsItems = [
    { to: '/receipts', label: 'Receipts', icon: ArrowDownLeft, badge: 'Incoming' },
    { to: '/deliveries', label: 'Delivery Orders', icon: ArrowUpRight, badge: 'Outgoing' },
    { to: '/transfers', label: 'Internal Transfers', icon: ArrowLeftRight },
    { to: '/adjustments', label: 'Stock Adjustments', icon: SlidersHorizontal },
  ];

  const auditItems = [
    { to: '/move-history', label: 'Move History', icon: History },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex flex-col w-72 bg-slate-900 border-r border-slate-800/80 transition-transform duration-300 lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Logo & Header */}
        <div className="flex items-center gap-3 px-6 h-18 border-b border-slate-800/60 bg-slate-950/40">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-brand-500 to-indigo-700 text-white shadow-glow">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold tracking-tight text-white font-sans">
                Stock<span className="text-brand-400">Sense</span>
              </span>
              <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-brand-500/20 text-brand-300 border border-brand-500/30">
                IMS
              </span>
            </div>
            <p className="text-xs text-slate-400">Inventory Operations</p>
          </div>
        </div>

        {/* Scrollable Navigation Menu */}
        <div className="flex-1 px-4 py-4 space-y-6 overflow-y-auto">
          {/* Main */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Overview
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={navLinkClass}
                  onClick={() => setMobileOpen(false)}
                >
                  <Icon className="w-4 h-4 text-inherit" />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </div>

          {/* Operations */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Operations
            </div>
            {operationsItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={navLinkClass}
                  onClick={() => setMobileOpen(false)}
                >
                  <Icon className="w-4 h-4 text-inherit" />
                  <span className="flex-1">{item.label}</span>
                  {item.badge && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700/60">
                      {item.badge}
                    </span>
                  )}
                </NavLink>
              );
            })}
          </div>

          {/* Audit & Intelligence */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Ledger & Audit
            </div>
            {auditItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={navLinkClass}
                  onClick={() => setMobileOpen(false)}
                >
                  <Icon className="w-4 h-4 text-inherit" />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </div>

          {/* Settings Section */}
          <div className="space-y-1">
            <div className="px-3 pb-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              Configuration
            </div>
            <div>
              <button
                onClick={() => setSettingsOpen(!settingsOpen)}
                className="flex items-center justify-between w-full px-3.5 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:text-slate-100 hover:bg-slate-850/60 transition-all"
              >
                <div className="flex items-center gap-3">
                  <Settings className="w-4 h-4 text-inherit" />
                  <span>Settings</span>
                </div>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${
                    settingsOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {settingsOpen && (
                <div className="pl-4 mt-1 space-y-1">
                  <NavLink
                    to="/settings/warehouse"
                    className={navLinkClass}
                    onClick={() => setMobileOpen(false)}
                  >
                    <Warehouse className="w-4 h-4 text-inherit" />
                    <span>Warehouse</span>
                  </NavLink>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Profile Menu (Left Sidebar Bottom) */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/60">
          <div className="relative">
            {profileOpen && (
              <div className="absolute bottom-full left-0 right-0 mb-2 p-1.5 glass-dropdown rounded-xl border border-slate-700/60 animate-in fade-in slide-in-from-bottom-2 duration-150">
                <button
                  onClick={() => {
                    setProfileOpen(false);
                    navigate('/profile');
                  }}
                  className="flex items-center w-full gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 rounded-lg hover:bg-slate-800 hover:text-white transition-colors"
                >
                  <User className="w-4 h-4 text-brand-400" />
                  <span>My Profile</span>
                </button>
                <div className="my-1 border-t border-slate-800" />
                <button
                  onClick={handleLogout}
                  className="flex items-center w-full gap-2.5 px-3 py-2 text-xs font-medium text-rose-400 rounded-lg hover:bg-rose-500/10 transition-colors"
                >
                  <LogOut className="w-4 h-4 text-rose-400" />
                  <span>Logout</span>
                </button>
              </div>
            )}

            <button
              onClick={() => setProfileOpen(!profileOpen)}
              className="flex items-center justify-between w-full p-2 rounded-xl bg-slate-850/80 hover:bg-slate-800/80 border border-slate-800 transition-all text-left"
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-brand-600/30 text-brand-300 border border-brand-500/30 font-semibold text-sm">
                  {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
                </div>
                <div className="truncate">
                  <p className="text-xs font-semibold text-slate-200 truncate">
                    {user?.name || 'Authorized User'}
                  </p>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`inline-block w-1.5 h-1.5 rounded-full ${
                        user?.role === 'manager' ? 'bg-amber-400' : 'bg-brand-400'
                      }`}
                    />
                    <span className="text-[11px] capitalize text-slate-400">
                      {user?.role || 'Staff'}
                    </span>
                  </div>
                </div>
              </div>
              <ChevronDown
                className={`w-4 h-4 text-slate-400 transition-transform ${
                  profileOpen ? 'rotate-180' : ''
                }`}
              />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}

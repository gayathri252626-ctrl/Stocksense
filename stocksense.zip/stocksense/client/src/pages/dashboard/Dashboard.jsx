import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Boxes,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  SlidersHorizontal,
  RefreshCw,
  Building2,
  TrendingDown,
  CheckCircle2,
  Clock,
  ChevronRight,
  Filter,
  Plus,
} from 'lucide-react';
import api from '../../api/axios';
import { useSocket } from '../../context/SocketContext';

export default function Dashboard({ activeWarehouse, setActiveWarehouse, warehouses }) {
  const [stats, setStats] = useState(null);
  const [lowStockItems, setLowStockItems] = useState([]);
  const [movements, setMovements] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDocType, setSelectedDocType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const { socket } = useSocket();

  const fetchStats = async () => {
    try {
      setLoading(true);
      const url = activeWarehouse
        ? `/dashboard/stats?warehouseId=${activeWarehouse}`
        : '/dashboard/stats';
      const res = await api.get(url);
      setStats(res.data.stats);
      setLowStockItems(res.data.lowStockItems || []);
      setMovements(res.data.recentMovements || []);
      setCategories(res.data.categories || []);
    } catch (err) {
      console.error('Failed to fetch dashboard stats:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, [activeWarehouse]);

  // Real-time socket updates listener
  useEffect(() => {
    if (!socket) return;

    const handleStockUpdate = () => {
      fetchStats();
    };

    socket.on('stock:updated', handleStockUpdate);
    return () => {
      socket.off('stock:updated', handleStockUpdate);
    };
  }, [socket, activeWarehouse]);

  const kpis = [
    {
      label: 'Total Products in Stock',
      value: stats ? stats.totalProducts : '—',
      icon: Boxes,
      color: 'from-blue-500/20 to-indigo-500/10',
      border: 'border-blue-500/30',
      textColor: 'text-blue-400',
      description: 'Active catalog SKUs',
    },
    {
      label: 'Low / Out of Stock',
      value: stats ? stats.totalLowStockAlerts : '—',
      icon: AlertTriangle,
      color: 'from-amber-500/20 to-rose-500/10',
      border: stats?.totalLowStockAlerts > 0 ? 'border-amber-500/50' : 'border-slate-800',
      textColor: stats?.totalLowStockAlerts > 0 ? 'text-amber-400' : 'text-slate-400',
      alert: stats?.totalLowStockAlerts > 0,
      description: 'Requires reorder attention',
    },
    {
      label: 'Pending Receipts',
      value: stats ? stats.pendingReceiptsCount : '—',
      icon: ArrowDownLeft,
      color: 'from-emerald-500/20 to-teal-500/10',
      border: 'border-emerald-500/30',
      textColor: 'text-emerald-400',
      description: 'Incoming vendor orders',
    },
    {
      label: 'Pending Deliveries',
      value: stats ? stats.pendingDeliveriesCount : '—',
      icon: ArrowUpRight,
      color: 'from-purple-500/20 to-pink-500/10',
      border: 'border-purple-500/30',
      textColor: 'text-purple-400',
      description: 'Outgoing customer shipments',
    },
    {
      label: 'Internal Transfers',
      value: stats ? stats.internalTransfersCount : '—',
      icon: ArrowLeftRight,
      color: 'from-cyan-500/20 to-sky-500/10',
      border: 'border-cyan-500/30',
      textColor: 'text-cyan-400',
      description: 'Scheduled floor moves',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Inventory Operations Dashboard
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time snapshot of warehouses, stock levels, and operations
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchStats}
            className="flex items-center gap-2 px-3 py-2 text-xs font-medium rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700/60 transition-all"
            title="Refresh metrics"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <Link
            to="/products"
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-brand-600 hover:bg-brand-500 text-white shadow-glow transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Manage Catalog</span>
          </Link>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon;
          return (
            <div
              key={index}
              className={`p-4 rounded-2xl bg-gradient-to-br ${kpi.color} bg-slate-900/80 border ${kpi.border} backdrop-blur-md relative overflow-hidden transition-all duration-200 hover:-translate-y-0.5`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">{kpi.label}</span>
                <div className={`p-2 rounded-xl bg-slate-950/60 ${kpi.textColor}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>

              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold tracking-tight text-white font-mono">
                  {kpi.value}
                </span>
                {kpi.alert && (
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Action Req.
                  </span>
                )}
              </div>

              <p className="text-[11px] text-slate-400 mt-1">{kpi.description}</p>
            </div>
          );
        })}
      </div>

      {/* Dynamic Filters Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <Filter className="w-4 h-4 text-brand-400" />
          <span>Dynamic Filters:</span>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          {/* Document Type */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <span className="text-slate-400">Doc Type:</span>
            <select
              value={selectedDocType}
              onChange={(e) => setSelectedDocType(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Operations</option>
              <option value="receipts" className="bg-slate-900">Receipts</option>
              <option value="delivery" className="bg-slate-900">Delivery Orders</option>
              <option value="internal" className="bg-slate-900">Internal Transfers</option>
              <option value="adjustments" className="bg-slate-900">Adjustments</option>
            </select>
          </div>

          {/* Status */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <span className="text-slate-400">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Statuses</option>
              <option value="draft" className="bg-slate-900">Draft</option>
              <option value="waiting" className="bg-slate-900">Waiting</option>
              <option value="ready" className="bg-slate-900">Ready</option>
              <option value="done" className="bg-slate-900">Done</option>
              <option value="canceled" className="bg-slate-900">Canceled</option>
            </select>
          </div>

          {/* Warehouse */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <span className="text-slate-400">Location:</span>
            <select
              value={activeWarehouse || ''}
              onChange={(e) => setActiveWarehouse(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="" className="bg-slate-900">All Warehouses</option>
              {warehouses.map((w) => (
                <option key={w._id} value={w._id} className="bg-slate-900">
                  {w.code} - {w.name}
                </option>
              ))}
            </select>
          </div>

          {/* Category */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <span className="text-slate-400">Category:</span>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Categories</option>
              {categories.map((c) => (
                <option key={c._id} value={c._id} className="bg-slate-900">
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Low Stock Alerts & Quick Operations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Low Stock Watchlist */}
        <div className="glass-panel p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <h2 className="text-sm font-semibold text-white">
                  Low Stock Watchlist
                </h2>
              </div>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300">
                {lowStockItems.length} items
              </span>
            </div>

            {lowStockItems.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
                All monitored inventory items are safely above reorder points.
              </div>
            ) : (
              <div className="space-y-3">
                {lowStockItems.slice(0, 4).map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-semibold text-slate-200">
                        {item.product?.name}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        SKU: {item.product?.sku}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-amber-400 font-mono">
                        {item.currentQty} {item.product?.unitOfMeasure}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Min: {item.product?.reorderPoint}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <Link
            to="/receipts"
            className="mt-4 flex items-center justify-center gap-1.5 w-full py-2 rounded-xl text-xs font-semibold text-brand-300 bg-brand-500/10 hover:bg-brand-500/20 border border-brand-500/30 transition-all"
          >
            <span>Create Replenishment Receipt</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* Quick Operations Launchpad */}
        <div className="lg:col-span-2 glass-panel p-5 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-white">Operations Launchpad</h2>
            <span className="text-xs text-slate-400">Common Stock Tasks</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Link
              to="/receipts"
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900/60 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:scale-105 transition-transform">
                  <ArrowDownLeft className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-slate-200 group-hover:text-emerald-300">
                    Incoming Receipt
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Receive shipment from vendor & increase stock
                  </p>
                </div>
              </div>
            </Link>

            <Link
              to="/deliveries"
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-purple-500/50 hover:bg-slate-900/60 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 group-hover:scale-105 transition-transform">
                  <ArrowUpRight className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-slate-200 group-hover:text-purple-300">
                    Outgoing Delivery
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Pick, pack, and validate customer shipments
                  </p>
                </div>
              </div>
            </Link>

            <Link
              to="/transfers"
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-900/60 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:scale-105 transition-transform">
                  <ArrowLeftRight className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300">
                    Internal Transfer
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Move stock across warehouses & racks
                  </p>
                </div>
              </div>
            </Link>

            <Link
              to="/adjustments"
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-900/60 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 group-hover:scale-105 transition-transform">
                  <SlidersHorizontal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-slate-200 group-hover:text-amber-300">
                    Inventory Adjustment
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Reconcile counted vs. system recorded stock
                  </p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* Live Movements & Audit Ledger Table */}
      <div className="glass-panel p-5 rounded-2xl border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold text-white">
              Recent Stock Movements (Ledger)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Immutable audit history of all receipts, deliveries, and adjustments
            </p>
          </div>
          <Link
            to="/move-history"
            className="text-xs text-brand-400 hover:text-brand-300 font-medium inline-flex items-center gap-1"
          >
            <span>View All History</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {movements.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            No stock movements recorded yet. Complete your first receipt or transfer to begin logging.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="pb-3 font-semibold">Timestamp</th>
                  <th className="pb-3 font-semibold">Product</th>
                  <th className="pb-3 font-semibold">Location</th>
                  <th className="pb-3 font-semibold">Type</th>
                  <th className="pb-3 font-semibold text-right">Quantity Change</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {movements.map((m) => {
                  const isPositive = m.qtyChange > 0;
                  return (
                    <tr key={m._id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 text-slate-400 font-mono text-[11px]">
                        {new Date(m.timestamp).toLocaleDateString()} {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="py-3">
                        <div className="font-semibold text-slate-200">
                          {m.product?.name || 'Product'}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400">
                          {m.product?.sku}
                        </div>
                      </td>
                      <td className="py-3 text-slate-300">
                        {m.warehouse?.code} - {m.warehouse?.name}
                      </td>
                      <td className="py-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-medium capitalize bg-slate-800 text-slate-300 border border-slate-700/60">
                          {m.type.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <span
                          className={`font-mono font-bold ${
                            isPositive ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isPositive ? `+${m.qtyChange}` : m.qtyChange}{' '}
                          <span className="text-[10px] font-normal text-slate-400">
                            {m.product?.unitOfMeasure}
                          </span>
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

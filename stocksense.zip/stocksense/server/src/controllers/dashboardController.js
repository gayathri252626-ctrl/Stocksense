const {
  Product,
  StockLevel,
  Receipt,
  DeliveryOrder,
  InternalTransfer,
  Adjustment,
  StockLedger,
  Warehouse,
  Category,
} = require('../models');

const getDashboardStats = async (req, res, next) => {
  try {
    const { warehouseId } = req.query;

    const warehouseFilter = warehouseId ? { warehouse: warehouseId } : {};

    // 1. Total Products Count
    const totalProducts = await Product.countDocuments();

    // 2. Stock levels & Low Stock items
    const stockLevels = await StockLevel.find(warehouseFilter).populate('product');

    // Aggregate quantity per product
    const productQtyMap = {};
    stockLevels.forEach((sl) => {
      if (sl.product) {
        const pId = sl.product._id.toString();
        productQtyMap[pId] = (productQtyMap[pId] || 0) + sl.quantity;
      }
    });

    const allProducts = await Product.find().populate('category');
    let lowStockCount = 0;
    let outOfStockCount = 0;
    const lowStockItems = [];

    allProducts.forEach((p) => {
      const currentQty = productQtyMap[p._id.toString()] || 0;
      if (currentQty === 0) {
        outOfStockCount++;
        lowStockItems.push({ product: p, currentQty, status: 'out_of_stock' });
      } else if (currentQty <= (p.reorderPoint || 10)) {
        lowStockCount++;
        lowStockItems.push({ product: p, currentQty, status: 'low_stock' });
      }
    });

    // 3. Pending Receipts (status in draft, waiting, ready)
    const receiptQuery = {
      status: { $in: ['draft', 'waiting', 'ready'] },
      ...(warehouseId && { warehouse: warehouseId }),
    };
    const pendingReceiptsCount = await Receipt.countDocuments(receiptQuery);

    // 4. Pending Deliveries (status in draft, waiting, ready)
    const deliveryQuery = {
      status: { $in: ['draft', 'waiting', 'ready'] },
      ...(warehouseId && { warehouse: warehouseId }),
    };
    const pendingDeliveriesCount = await DeliveryOrder.countDocuments(deliveryQuery);

    // 5. Internal Transfers Scheduled (draft, waiting, ready)
    const transferQuery = {
      status: { $in: ['draft', 'waiting', 'ready'] },
      ...(warehouseId && {
        $or: [{ fromWarehouse: warehouseId }, { toWarehouse: warehouseId }],
      }),
    };
    const internalTransfersCount = await InternalTransfer.countDocuments(transferQuery);

    // 6. Recent Move History from StockLedger
    const recentMovements = await StockLedger.find(warehouseFilter)
      .sort({ timestamp: -1 })
      .limit(8)
      .populate('product', 'name sku unitOfMeasure')
      .populate('warehouse', 'name code');

    // 7. Warehouse list for filters
    const warehouses = await Warehouse.find().select('name code location');

    // 8. Categories list for filters
    const categories = await Category.find().select('name');

    res.json({
      success: true,
      stats: {
        totalProducts,
        lowStockCount,
        outOfStockCount,
        totalLowStockAlerts: lowStockCount + outOfStockCount,
        pendingReceiptsCount,
        pendingDeliveriesCount,
        internalTransfersCount,
      },
      lowStockItems,
      recentMovements,
      warehouses,
      categories,
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getDashboardStats,
};

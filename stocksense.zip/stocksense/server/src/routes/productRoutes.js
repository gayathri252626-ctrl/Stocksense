const express = require('express');
const router = express.Router();
const { Product, StockLevel } = require('../models');
const { authenticateToken } = require('../middleware/auth');

router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const products = await Product.find().populate('category').sort({ name: 1 });
    const stockLevels = await StockLevel.find().populate('warehouse', 'name code');

    // Attach stock levels to each product
    const enrichedProducts = products.map((prod) => {
      const prodStocks = stockLevels.filter((sl) => sl.product.toString() === prod._id.toString());
      const totalQty = prodStocks.reduce((sum, sl) => sum + sl.quantity, 0);
      return {
        ...prod.toObject(),
        totalQty,
        stockPerWarehouse: prodStocks,
      };
    });

    res.json({ success: true, products: enrichedProducts });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

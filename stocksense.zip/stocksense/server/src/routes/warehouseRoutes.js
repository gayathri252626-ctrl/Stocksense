const express = require('express');
const router = express.Router();
const { Warehouse } = require('../models');
const { authenticateToken, requireRole } = require('../middleware/auth');

router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const warehouses = await Warehouse.find().sort({ createdAt: -1 });
    res.json({ success: true, warehouses });
  } catch (err) {
    next(err);
  }
});

router.post('/', authenticateToken, requireRole('manager'), async (req, res, next) => {
  try {
    const { name, code, location } = req.body;
    if (!name || !code || !location) {
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    }
    const warehouse = await Warehouse.create({
      name: name.trim(),
      code: code.trim().toUpperCase(),
      location: location.trim(),
    });
    res.status(201).json({ success: true, warehouse });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

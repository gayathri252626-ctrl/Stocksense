# StockSense — Step 4 Git Commits Guide

This document outlines the recommended conventional Git commits for **Step 4: Internal Transfers, Stock Adjustments, Move History & Real-Time Audit Ledger**.

---

### Commit 1: Internal Transfers (Inter-Facility Movements)
- **Commit Message**:
  ```text
  feat(transfers): implement multi-location internal stock transfers and negative stock check

  - Build atomic transfer validation shifting StockLevel between warehouses
  - Prevent negative stock at origin warehouse with HTTP 400 rejection
  - Write simultaneous transfer_out and transfer_in audit records to StockLedger
  - Implement TransfersPage UI with dynamic line items, route visual cards, and live status
  ```
- **Files**:
  - `server/src/routes/transferRoutes.js`
  - `client/src/pages/transfers/TransfersPage.jsx`

---

### Commit 2: Stock Adjustments (Physical Count Reconciliation)
- **Commit Message**:
  ```text
  feat(adjustments): implement physical count inventory reconciliation with automatic ledger sync

  - Build adjustments API fetching current system stock and applying physical counts
  - Automatically log discrepancy delta (countedQty - systemQty) to StockLedger
  - Build AdjustmentsPage UI with live system stock preview and real-time diff calculations
  - Broadcast live Socket.io updates upon adjustment application
  ```
- **Files**:
  - `server/src/routes/adjustmentRoutes.js`
  - `client/src/pages/adjustments/AdjustmentsPage.jsx`

---

### Commit 3: Move History & StockLedger Audit Trail
- **Commit Message**:
  ```text
  feat(ledger): implement Move History audit trail with smart filters and CSV export

  - Build StockLedger query API with multi-dimensional filters (product, warehouse, type, date range)
  - Calculate real-time audit metrics: total inflow (+), outflow (-), and net delta
  - Build MoveHistoryPage UI with movement type badges and live Socket.io auto-refresh
  - Add client-side CSV export functionality
  ```
- **Files**:
  - `server/src/routes/ledgerRoutes.js`
  - `client/src/pages/move-history/MoveHistoryPage.jsx`

---

### Commit 4: Server Integration, Verification & Real-Time Documentation
- **Commit Message**:
  ```text
  chore(step4): mount new routes, add end-to-end lifecycle test, and update real-time docs

  - Mount /api/transfers, /api/adjustments, and /api/ledger in server.js
  - Add testStep4.js executing full 4-stage operational lifecycle test
  - Update README with comprehensive Socket.io real-time event architecture documentation
  ```
- **Files**:
  - `server/src/server.js`
  - `server/src/testStep4.js`
  - `README.md`

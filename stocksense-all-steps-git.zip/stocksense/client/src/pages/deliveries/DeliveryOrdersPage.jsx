import React, { useState, useEffect } from 'react';
import {
  ArrowUpRight,
  Plus,
  CheckCircle2,
  Clock,
  Filter,
  Search,
  Building,
  Eye,
  Check,
  X,
  AlertCircle,
  Package,
  Layers,
  Sparkles,
  ChevronRight,
  Trash2,
  AlertTriangle,
  Truck,
  Box,
} from 'lucide-react';
import api from '../../api/axios';
import { useSocket } from '../../context/SocketContext';

export default function DeliveryOrdersPage() {
  const [deliveries, setDeliveries] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedWarehouse, setSelectedWarehouse] = useState('all');
  const [search, setSearch] = useState('');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [detailOrder, setDetailOrder] = useState(null);

  // Form State
  const [customer, setCustomer] = useState('');
  const [targetWarehouse, setTargetWarehouse] = useState('');
  const [lines, setLines] = useState([{ product: '', qty: 5 }]);
  const [notes, setNotes] = useState('');
  const [initialStatus, setInitialStatus] = useState('ready');

  const [submitting, setSubmitting] = useState(false);
  const [validatingId, setValidatingId] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const { socket } = useSocket();

  const loadData = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (selectedStatus && selectedStatus !== 'all') params.append('status', selectedStatus);
      if (selectedWarehouse && selectedWarehouse !== 'all') params.append('warehouseId', selectedWarehouse);
      if (search && search.trim()) params.append('search', search.trim());

      const [delRes, warRes, prodRes] = await Promise.all([
        api.get(`/deliveries?${params.toString()}`),
        api.get('/warehouses'),
        api.get('/products'),
      ]);

      setDeliveries(delRes.data.deliveryOrders || []);
      setWarehouses(warRes.data.warehouses || []);
      setProducts(prodRes.data.products || []);
    } catch (err) {
      console.error('Failed to load deliveries:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedStatus, selectedWarehouse, search]);

  // Real-time Socket.io listener
  useEffect(() => {
    if (!socket) return;
    const handleUpdate = () => {
      loadData();
    };
    socket.on('stock:updated', handleUpdate);
    socket.on('stock:update', handleUpdate);
    return () => {
      socket.off('stock:updated', handleUpdate);
      socket.off('stock:update', handleUpdate);
    };
  }, [socket]);

  // Open modal
  const openCreateModal = () => {
    setCustomer('');
    setTargetWarehouse(warehouses[0]?._id || '');
    setLines([{ product: products[0]?._id || '', qty: 5 }]);
    setNotes('');
    setInitialStatus('ready');
    setError('');
    setCreateModalOpen(true);
  };

  // Add line item
  const addLine = () => {
    setLines([...lines, { product: products[0]?._id || '', qty: 5 }]);
  };

  // Remove line item
  const removeLine = (index) => {
    if (lines.length === 1) return;
    setLines(lines.filter((_, i) => i !== index));
  };

  // Update line item
  const updateLine = (index, field, value) => {
    const updated = [...lines];
    updated[index][field] = value;
    setLines(updated);
  };

  // Load single order details with warehouse stock verification
  const openOrderDetail = async (order) => {
    try {
      const res = await api.get(`/deliveries/${order._id}`);
      setDetailOrder(res.data.deliveryOrder);
    } catch (err) {
      setDetailOrder(order);
    }
  };

  // Submit new delivery order
  const handleCreateOrder = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setSubmitting(true);

    try {
      const res = await api.post('/deliveries', {
        customer,
        warehouse: targetWarehouse,
        lines: lines.map((l) => ({ product: l.product, qty: Number(l.qty) })),
        status: initialStatus,
        notes,
      });

      setMessage(`Delivery Order ${res.data.deliveryOrder.orderNumber} created successfully.`);
      setCreateModalOpen(false);
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create delivery order.');
    } finally {
      setSubmitting(false);
    }
  };

  // Validate Delivery Order (Checks stock sufficiency, decreases stock, logs ledger)
  const handleValidateOrder = async (orderId) => {
    setError('');
    setMessage('');
    setValidatingId(orderId);

    try {
      const res = await api.post(`/deliveries/${orderId}/validate`);
      setMessage(res.data.message || 'Delivery order validated! Stock levels updated.');
      if (detailOrder && detailOrder._id === orderId) {
        setDetailOrder(res.data.deliveryOrder);
      }
      loadData();
    } catch (err) {
      const errMsg = err.response?.data?.message || 'Failed to validate delivery order.';
      setError(errMsg);
    } finally {
      setValidatingId(null);
    }
  };

  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case 'done':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'ready':
        return 'bg-purple-500/10 text-purple-300 border-purple-500/30';
      case 'waiting':
        return 'bg-amber-500/10 text-amber-300 border-amber-500/30';
      case 'cancelled':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/30';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700/60';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Delivery Orders (Outgoing Stock)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30 font-mono">
              {deliveries.length} Shipments
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Pick, pack, and validate customer shipments. Validating checks stock sufficiency, blocks negative stock, decrements StockLevels, and logs to StockLedger.
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-glow transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Delivery Order</span>
        </button>
      </div>

      {message && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs flex items-start gap-2.5 animate-in fade-in shadow-glow">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
          <div>
            <span className="font-bold block text-sm">Validation Blocked</span>
            <span>{error}</span>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search order # or customer..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-400 focus:outline-none focus:border-brand-500"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          {/* Status Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <Filter className="w-3.5 h-3.5 text-brand-400" />
            <span className="text-slate-400">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Statuses</option>
              <option value="draft">Draft (Preparing lines)</option>
              <option value="waiting">Waiting (Picking items)</option>
              <option value="ready">Ready (Packed in staging bay)</option>
              <option value="done">Done (Stock Deducted & Shipped)</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          {/* Warehouse Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <Building className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400">Warehouse:</span>
            <select
              value={selectedWarehouse}
              onChange={(e) => setSelectedWarehouse(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Warehouses</option>
              {warehouses.map((w) => (
                <option key={w._id} value={w._id} className="bg-slate-900">
                  {w.code} - {w.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Deliveries Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading customer delivery orders...</p>
          </div>
        ) : deliveries.length === 0 ? (
          <div className="p-12 text-center">
            <ArrowUpRight className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-slate-300">No delivery orders found</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
              Create your first delivery order to pick, pack, and fulfill outgoing shipments.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Order Number</th>
                  <th className="py-3.5 px-4 font-semibold">Customer</th>
                  <th className="py-3.5 px-4 font-semibold">Dispatch Facility</th>
                  <th className="py-3.5 px-4 font-semibold">Ordered Lines</th>
                  <th className="py-3.5 px-4 font-semibold text-center">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Order Date</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {deliveries.map((d) => {
                  const isDone = d.status === 'done';
                  const isCancelled = d.status === 'cancelled';
                  return (
                    <tr key={d._id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-purple-400 text-sm">
                        {d.orderNumber}
                      </td>

                      <td className="py-3 px-4 font-semibold text-slate-200">
                        {d.customer}
                      </td>

                      <td className="py-3 px-4 text-slate-300">
                        <span className="font-mono font-bold text-slate-400 mr-1.5">{d.warehouse?.code}</span>
                        <span>{d.warehouse?.name}</span>
                      </td>

                      <td className="py-3 px-4 text-slate-300 max-w-xs">
                        <div className="space-y-0.5">
                          {d.lines?.map((line, lIdx) => (
                            <div key={lIdx} className="truncate text-[11px]">
                              <span className="font-bold text-rose-400 font-mono mr-1">
                                -{line.qty} {line.product?.unitOfMeasure}
                              </span>
                              <span className="text-slate-400">{line.product?.name}</span>
                            </div>
                          ))}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase border ${getStatusBadge(
                            d.status
                          )}`}
                        >
                          {d.status === 'done' ? 'Fulfilled Done' : d.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-slate-400 text-[11px]">
                        {new Date(d.createdAt).toLocaleDateString()}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-2">
                          <button
                            onClick={() => openOrderDetail(d)}
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                            title="View Order Details & Warehouse Stock"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {!isDone && !isCancelled && (
                            <button
                              onClick={() => handleValidateOrder(d._id)}
                              disabled={validatingId === d._id}
                              className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-glow transition-all disabled:opacity-50"
                              title="Validate & Deduct Stock"
                            >
                              {validatingId === d._id ? (
                                <span className="inline-block w-3 h-3 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                              ) : (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Validate</span>
                                </>
                              )}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal: Create New Delivery Order */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="glass-panel w-full max-w-2xl p-6 rounded-2xl border border-slate-700/80 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setCreateModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 mb-4">
              <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Create Outbound Delivery Order</h3>
                <p className="text-xs text-slate-400">Pick, pack, and ship inventory items to customer</p>
              </div>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleCreateOrder} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customer}
                    onChange={(e) => setCustomer(e.target.value)}
                    placeholder="e.g. BuildCorp Logistics Inc."
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Dispatch Warehouse *
                  </label>
                  <select
                    required
                    value={targetWarehouse}
                    onChange={(e) => setTargetWarehouse(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500 cursor-pointer"
                  >
                    {warehouses.map((w) => (
                      <option key={w._id} value={w._id} className="bg-slate-900">
                        {w.code} - {w.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Line items section */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Box className="w-3.5 h-3.5 text-purple-400" />
                    <span>Product Lines to Dispatch</span>
                  </span>
                  <button
                    type="button"
                    onClick={addLine}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-purple-400 hover:text-purple-300"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Line Item</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {lines.map((line, idx) => {
                    const selectedProd = products.find((p) => p._id === line.product);
                    return (
                      <div
                        key={idx}
                        className="grid grid-cols-12 gap-2 items-center p-2 rounded-xl bg-slate-900 border border-slate-800"
                      >
                        <div className="col-span-7">
                          <select
                            required
                            value={line.product}
                            onChange={(e) => updateLine(idx, 'product', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 focus:outline-none focus:border-brand-500"
                          >
                            {products.map((p) => (
                              <option key={p._id} value={p._id} className="bg-slate-900">
                                {p.sku} — {p.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="col-span-4 flex items-center gap-1.5">
                          <input
                            type="number"
                            required
                            min={1}
                            value={line.qty}
                            onChange={(e) => updateLine(idx, 'qty', e.target.value)}
                            placeholder="Qty"
                            className="w-full px-2.5 py-1.5 text-xs font-mono font-bold bg-slate-950 border border-slate-800 rounded-lg text-white text-right focus:outline-none focus:border-brand-500"
                          />
                          <span className="text-[11px] text-slate-400 w-12 truncate">
                            {selectedProd?.unitOfMeasure || 'pcs'}
                          </span>
                        </div>

                        <div className="col-span-1 text-right">
                          <button
                            type="button"
                            onClick={() => removeLine(idx)}
                            disabled={lines.length === 1}
                            className="p-1 text-slate-500 hover:text-rose-400 disabled:opacity-30 rounded"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Initial Fulfillment Stage
                  </label>
                  <select
                    value={initialStatus}
                    onChange={(e) => setInitialStatus(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  >
                    <option value="draft">1. Draft (Order logged)</option>
                    <option value="waiting">2. Waiting (Picking items in bays)</option>
                    <option value="ready">3. Ready (Packed in staging bay)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Shipping Notes / Tracking Reference
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g. Freight carrier dispatch #491"
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-xs font-semibold text-white bg-purple-600 rounded-xl hover:bg-purple-500 disabled:opacity-50 shadow-glow"
                >
                  {submitting ? 'Creating...' : 'Register Delivery Order'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: View Delivery Order Details & Stock Sufficiency Check */}
      {detailOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="glass-panel w-full max-w-xl p-6 rounded-2xl border border-slate-700/80 shadow-2xl relative">
            <button
              onClick={() => setDetailOrder(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Outbound Delivery Order
                </span>
                <h3 className="text-lg font-bold text-white font-mono mt-0.5">
                  {detailOrder.orderNumber}
                </h3>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold uppercase border ${getStatusBadge(
                  detailOrder.status
                )}`}
              >
                {detailOrder.status === 'done' ? 'Fulfilled Done' : detailOrder.status}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 my-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Customer</span>
                <span className="font-semibold text-white text-sm mt-0.5 block">{detailOrder.customer}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Origin Warehouse</span>
                <span className="font-semibold text-white text-sm mt-0.5 block">
                  {detailOrder.warehouse?.code} - {detailOrder.warehouse?.name}
                </span>
              </div>
            </div>

            {/* Line items with real-time stock sufficiency verification */}
            <div className="space-y-2 mb-4">
              <div className="text-xs font-semibold text-slate-300">
                Dispatched Product Lines & Stock Availability
              </div>
              <div className="divide-y divide-slate-800 rounded-xl bg-slate-950/80 border border-slate-800 overflow-hidden">
                {detailOrder.linesWithStock?.map((line, idx) => (
                  <div key={idx} className="p-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">{line.product?.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        SKU: {line.product?.sku}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-mono font-bold text-sm text-purple-400">
                        Required: -{line.qty} {line.product?.unitOfMeasure}
                      </div>
                      <div className="flex items-center gap-1.5 justify-end mt-0.5">
                        <span className="text-[11px] text-slate-400">
                          In Warehouse: {line.currentWarehouseStock} {line.product?.unitOfMeasure}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                            line.isSufficient
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          }`}
                        >
                          {line.isSufficient ? 'Sufficient' : 'Insufficient Stock'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {detailOrder.notes && (
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 mb-4">
                <strong>Notes:</strong> {detailOrder.notes}
              </div>
            )}

            <div className="flex justify-between items-center pt-2 border-t border-slate-800">
              <span className="text-[11px] text-slate-500 font-mono">
                Logged at: {new Date(detailOrder.createdAt).toLocaleString()}
              </span>

              {detailOrder.status !== 'done' && detailOrder.status !== 'cancelled' ? (
                <button
                  onClick={() => handleValidateOrder(detailOrder._id)}
                  disabled={validatingId === detailOrder._id}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-glow transition-all"
                >
                  <Check className="w-4 h-4" />
                  <span>Validate & Ship (-Stock)</span>
                </button>
              ) : (
                <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Stock levels deducted and shipped</span>
                </span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

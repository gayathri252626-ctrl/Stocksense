import React, { useState, useEffect } from 'react';
import {
  SlidersHorizontal,
  Plus,
  Scale,
  Search,
  Filter,
  AlertCircle,
  CheckCircle2,
  TrendingDown,
  TrendingUp,
  RefreshCw,
  Warehouse as WarehouseIcon,
  Package,
  X,
  History,
} from 'lucide-react';
import api from '../../api/axios';
import { useSocket } from '../../context/SocketContext';

export default function AdjustmentsPage() {
  const [adjustments, setAdjustments] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [warehouseFilter, setWarehouseFilter] = useState('all');
  const [productFilter, setProductFilter] = useState('all');

  // Modals & Details
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedAdjustment, setSelectedAdjustment] = useState(null);

  // Form State
  const [formWarehouse, setFormWarehouse] = useState('');
  const [formProduct, setFormProduct] = useState('');
  const [systemStock, setSystemStock] = useState(null);
  const [countedQty, setCountedQty] = useState('');
  const [reason, setReason] = useState('');
  const [stockChecking, setStockChecking] = useState(false);
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { socket } = useSocket();

  // Load Data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [adjRes, whRes, prodRes] = await Promise.all([
        api.get('/adjustments', {
          params: {
            search: search || undefined,
            warehouseId: warehouseFilter !== 'all' ? warehouseFilter : undefined,
            productId: productFilter !== 'all' ? productFilter : undefined,
          },
        }),
        api.get('/warehouses'),
        api.get('/products'),
      ]);

      setAdjustments(adjRes.data.adjustments || []);
      setWarehouses(whRes.data.warehouses || []);
      setProducts(prodRes.data.products || []);
    } catch (err) {
      console.error('Failed to load adjustments data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [warehouseFilter, productFilter]);

  // Live Socket.io Updates
  useEffect(() => {
    if (!socket) return;
    const handleUpdate = () => {
      fetchData();
    };
    socket.on('stock:update', handleUpdate);
    socket.on('stock:updated', handleUpdate);
    return () => {
      socket.off('stock:update', handleUpdate);
      socket.off('stock:updated', handleUpdate);
    };
  }, [socket, warehouseFilter, productFilter, search]);

  // Check Recorded System Stock whenever product or warehouse changes in form
  useEffect(() => {
    const fetchCurrentStock = async () => {
      if (!formProduct || !formWarehouse) {
        setSystemStock(null);
        return;
      }

      try {
        setStockChecking(true);
        const res = await api.get('/adjustments/current-stock', {
          params: { productId: formProduct, warehouseId: formWarehouse },
        });
        setSystemStock(res.data.systemQty);
      } catch (err) {
        console.error('Failed to check stock level:', err);
        setSystemStock(0);
      } finally {
        setStockChecking(false);
      }
    };

    fetchCurrentStock();
  }, [formProduct, formWarehouse]);

  // Submit Adjustment
  const handleCreateAdjustment = async (e) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    if (!formProduct || !formWarehouse || countedQty === '') {
      setFormError('Please select warehouse, product, and specify the physical count.');
      return;
    }

    const parsedCount = Number(countedQty);
    if (isNaN(parsedCount) || parsedCount < 0) {
      setFormError('Counted quantity must be a non-negative number.');
      return;
    }

    try {
      setSubmitting(true);
      const res = await api.post('/adjustments', {
        product: formProduct,
        warehouse: formWarehouse,
        countedQty: parsedCount,
        reason,
      });

      setFormSuccess(res.data.message);
      setTimeout(() => {
        setShowCreateModal(false);
        setFormProduct('');
        setFormWarehouse('');
        setCountedQty('');
        setReason('');
        setSystemStock(null);
        setFormSuccess('');
      }, 1000);

      fetchData();
    } catch (err) {
      setFormError(err.response?.data?.message || 'Failed to submit adjustment.');
    } finally {
      setSubmitting(false);
    }
  };

  // Quick Preset Reasons
  const presetReasons = [
    'Routine physical cycle count',
    'Damaged units written off',
    'Inventory shrinkage / missing stock',
    'Found unrecorded items in staging bay',
    'Supplier shipping discrepancy reconciliation',
  ];

  // Calculated Difference in Form
  const parsedCount = countedQty !== '' ? Number(countedQty) : null;
  const calculatedDiff =
    parsedCount !== null && systemStock !== null && !isNaN(parsedCount)
      ? parsedCount - systemStock
      : null;

  // Aggregate Metrics
  const totalAdjustments = adjustments.length;
  const netDelta = adjustments.reduce((sum, a) => sum + (a.diff || 0), 0);
  const positiveCount = adjustments.filter((a) => (a.diff || 0) > 0).length;
  const negativeCount = adjustments.filter((a) => (a.diff || 0) < 0).length;

  const selectedProductObj = products.find((p) => p._id === formProduct);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <SlidersHorizontal className="w-6 h-6 text-amber-400" />
              Stock Adjustments
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
              Audit & Reconciliation
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Reconcile physical inventory counts against system records. Automatically calculates diffs, resets stock levels to the physical count, and logs an immutable audit trail.
          </p>
        </div>

        <button
          onClick={() => {
            setFormError('');
            setFormSuccess('');
            setShowCreateModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-amber-600 hover:bg-amber-500 text-white shadow-glow transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Stock Adjustment</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Total Audits
          </span>
          <div className="text-2xl font-extrabold text-white mt-1">{totalAdjustments}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Discrepancy logs</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
            Net Quantity Delta
          </span>
          <div
            className={`text-2xl font-extrabold mt-1 ${
              netDelta > 0
                ? 'text-emerald-400'
                : netDelta < 0
                ? 'text-rose-400'
                : 'text-slate-300'
            }`}
          >
            {netDelta > 0 ? `+${netDelta}` : netDelta}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Cumulative ledger diff</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
            Surplus Adjustments
          </span>
          <div className="text-2xl font-extrabold text-emerald-400 mt-1">{positiveCount}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Inventory gains (+)</div>
        </div>

        <div className="glass-panel p-4 rounded-2xl border border-slate-800">
          <span className="text-[11px] font-semibold text-rose-400 uppercase tracking-wider">
            Shrinkage / Deficits
          </span>
          <div className="text-2xl font-extrabold text-rose-400 mt-1">{negativeCount}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Stock written off (-)</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search adjustment # or reason..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Warehouse Filter */}
          <select
            value={warehouseFilter}
            onChange={(e) => setWarehouseFilter(e.target.value)}
            className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">All Warehouses</option>
            {warehouses.map((w) => (
              <option key={w._id} value={w._id}>
                {w.code} - {w.name}
              </option>
            ))}
          </select>

          {/* Product Filter */}
          <select
            value={productFilter}
            onChange={(e) => setProductFilter(e.target.value)}
            className="px-3 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">All Products</option>
            {products.map((p) => (
              <option key={p._id} value={p._id}>
                {p.name} ({p.sku})
              </option>
            ))}
          </select>

          <button
            onClick={fetchData}
            title="Refresh"
            className="p-2 bg-slate-900 border border-slate-700/80 rounded-xl text-slate-400 hover:text-white transition"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Adjustments Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading inventory adjustments...</p>
          </div>
        ) : adjustments.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            No stock adjustments recorded yet. Use the "New Stock Adjustment" button to reconcile physical inventory.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-semibold">Adjustment #</th>
                  <th className="py-3 px-4 font-semibold">Product</th>
                  <th className="py-3 px-4 font-semibold">Location</th>
                  <th className="py-3 px-4 font-semibold text-right">System Qty</th>
                  <th className="py-3 px-4 font-semibold text-right">Counted Qty</th>
                  <th className="py-3 px-4 font-semibold text-right">Discrepancy (Diff)</th>
                  <th className="py-3 px-4 font-semibold">Reason</th>
                  <th className="py-3 px-4 font-semibold text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {adjustments.map((a) => {
                  const isPositive = a.diff > 0;
                  const isZero = a.diff === 0;
                  return (
                    <tr
                      key={a._id}
                      onClick={() => setSelectedAdjustment(a)}
                      className="hover:bg-slate-900/50 transition-colors cursor-pointer"
                    >
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-amber-400">
                          {a.adjustmentNumber}
                        </span>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {new Date(a.createdAt).toLocaleString()}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-200">{a.product?.name}</div>
                        <div className="text-[11px] font-mono text-slate-400">
                          SKU: {a.product?.sku}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-slate-300">
                        <div className="font-semibold text-slate-200">
                          {a.warehouse?.code}
                        </div>
                        <div className="text-[11px] text-slate-400">{a.warehouse?.name}</div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-slate-400">
                        {a.systemQty} {a.product?.unitOfMeasure}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-white">
                        {a.countedQty} {a.product?.unitOfMeasure}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold">
                        <span
                          className={`inline-flex items-center gap-1 ${
                            isZero
                              ? 'text-slate-400'
                              : isPositive
                              ? 'text-emerald-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {isPositive && <TrendingUp className="w-3.5 h-3.5" />}
                          {!isPositive && !isZero && <TrendingDown className="w-3.5 h-3.5" />}
                          {isPositive ? `+${a.diff}` : a.diff} {a.product?.unitOfMeasure}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-slate-300 max-w-xs truncate">
                        {a.reason || 'Physical count reconciliation'}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          {a.status || 'applied'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Adjustment Detail Drawer */}
      {selectedAdjustment && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex justify-end">
          <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 p-6 flex flex-col h-full overflow-y-auto animate-slide-left">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h2 className="text-base font-bold text-white">
                  Adjustment: {selectedAdjustment.adjustmentNumber}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Applied on {new Date(selectedAdjustment.createdAt).toLocaleString()}
                </p>
              </div>
              <button
                onClick={() => setSelectedAdjustment(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-5 space-y-4 flex-1">
              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider">
                  Product
                </span>
                <div className="text-sm font-bold text-white mt-1">
                  {selectedAdjustment.product?.name}
                </div>
                <div className="text-xs font-mono text-slate-400">
                  SKU: {selectedAdjustment.product?.sku}
                </div>
              </div>

              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider">
                  Audited Location
                </span>
                <div className="text-sm font-bold text-white mt-1">
                  {selectedAdjustment.warehouse?.name} ({selectedAdjustment.warehouse?.code})
                </div>
                <div className="text-xs text-slate-400">
                  {selectedAdjustment.warehouse?.location}
                </div>
              </div>

              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 grid grid-cols-3 gap-2 text-center">
                <div>
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">
                    System Qty
                  </span>
                  <div className="text-base font-mono font-bold text-slate-300 mt-1">
                    {selectedAdjustment.systemQty}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-semibold text-white uppercase">Counted</span>
                  <div className="text-base font-mono font-extrabold text-white mt-1">
                    {selectedAdjustment.countedQty}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-semibold text-amber-400 uppercase">Delta</span>
                  <div
                    className={`text-base font-mono font-extrabold mt-1 ${
                      selectedAdjustment.diff > 0
                        ? 'text-emerald-400'
                        : selectedAdjustment.diff < 0
                        ? 'text-rose-400'
                        : 'text-slate-400'
                    }`}
                  >
                    {selectedAdjustment.diff > 0
                      ? `+${selectedAdjustment.diff}`
                      : selectedAdjustment.diff}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  Reason & Audit Notes
                </span>
                <p className="text-xs text-slate-200 mt-1">
                  {selectedAdjustment.reason || 'Routine physical inventory count reconciliation.'}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 mt-4 flex justify-end">
              <button
                onClick={() => setSelectedAdjustment(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New Adjustment Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl animate-scale-up">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-amber-400" />
                <h2 className="text-base font-bold text-white">Record Stock Adjustment</h2>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-400 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}
            {formSuccess && (
              <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-emerald-400 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{formSuccess}</span>
              </div>
            )}

            <form onSubmit={handleCreateAdjustment} className="mt-4 space-y-4">
              {/* Warehouse Selection */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Target Warehouse / Facility *
                </label>
                <select
                  required
                  value={formWarehouse}
                  onChange={(e) => setFormWarehouse(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                >
                  <option value="">Select Warehouse...</option>
                  {warehouses.map((w) => (
                    <option key={w._id} value={w._id}>
                      {w.code} - {w.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Product Selection */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Product to Adjust *
                </label>
                <select
                  required
                  value={formProduct}
                  onChange={(e) => setFormProduct(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                >
                  <option value="">Select Product...</option>
                  {products.map((p) => (
                    <option key={p._id} value={p._id}>
                      {p.name} ({p.sku})
                    </option>
                  ))}
                </select>
              </div>

              {/* Live System Stock Preview */}
              {formProduct && formWarehouse && (
                <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-amber-400" />
                    <span className="text-xs text-slate-300">System Recorded Stock:</span>
                  </div>
                  <div className="text-xs font-mono font-bold text-white">
                    {stockChecking ? (
                      <span className="text-slate-400">Checking...</span>
                    ) : (
                      <span>
                        {systemStock !== null ? systemStock : 0}{' '}
                        {selectedProductObj?.unitOfMeasure || 'units'}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Physical Counted Quantity */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Physical Counted Quantity *
                </label>
                <input
                  type="number"
                  min="0"
                  required
                  placeholder="Enter verified physical count"
                  value={countedQty}
                  onChange={(e) => setCountedQty(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              {/* Real-Time Calculated Discrepancy Preview */}
              {calculatedDiff !== null && (
                <div
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                    calculatedDiff === 0
                      ? 'bg-slate-950/80 border-slate-800 text-slate-300'
                      : calculatedDiff > 0
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {calculatedDiff > 0 && <TrendingUp className="w-4 h-4" />}
                    {calculatedDiff < 0 && <TrendingDown className="w-4 h-4" />}
                    <span className="font-semibold">
                      {calculatedDiff === 0
                        ? 'Count matches system (No change needed)'
                        : calculatedDiff > 0
                        ? 'Inventory Surplus (Stock will increase)'
                        : 'Inventory Deficit (Stock will be written down)'}
                    </span>
                  </div>

                  <div className="font-mono font-bold text-sm">
                    {calculatedDiff > 0 ? `+${calculatedDiff}` : calculatedDiff}{' '}
                    {selectedProductObj?.unitOfMeasure || 'units'}
                  </div>
                </div>
              )}

              {/* Reason / Notes */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Adjustment Reason / Audit Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Damaged during forklift transfer"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />

                {/* Preset Chips */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {presetReasons.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setReason(preset)}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 rounded-md text-[10px] border border-slate-700/60 transition"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Submit Actions */}
              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold shadow-glow disabled:opacity-50 transition"
                >
                  {submitting ? 'Applying Adjustment...' : 'Apply & Sync Stock'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

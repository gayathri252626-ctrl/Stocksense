import React, { useState, useEffect } from 'react';
import {
  ArrowDownLeft,
  Plus,
  CheckCircle2,
  Clock,
  Filter,
  Search,
  Building,
  Eye,
  Check,
  X,
  AlertCircle,
  Package,
  Layers,
  Sparkles,
  ChevronRight,
  Trash2,
} from 'lucide-react';
import api from '../../api/axios';
import { useSocket } from '../../context/SocketContext';

export default function ReceiptsPage() {
  const [receipts, setReceipts] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedWarehouse, setSelectedWarehouse] = useState('all');
  const [search, setSearch] = useState('');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [detailReceipt, setDetailReceipt] = useState(null);

  // Form State
  const [supplier, setSupplier] = useState('');
  const [targetWarehouse, setTargetWarehouse] = useState('');
  const [lines, setLines] = useState([{ product: '', qty: 1 }]);
  const [notes, setNotes] = useState('');
  const [initialStatus, setInitialStatus] = useState('ready');

  const [submitting, setSubmitting] = useState(false);
  const [validatingId, setValidatingId] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const { socket } = useSocket();

  const loadData = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (selectedStatus && selectedStatus !== 'all') params.append('status', selectedStatus);
      if (selectedWarehouse && selectedWarehouse !== 'all') params.append('warehouseId', selectedWarehouse);
      if (search && search.trim()) params.append('search', search.trim());

      const [recRes, warRes, prodRes] = await Promise.all([
        api.get(`/receipts?${params.toString()}`),
        api.get('/warehouses'),
        api.get('/products'),
      ]);

      setReceipts(recRes.data.receipts || []);
      setWarehouses(warRes.data.warehouses || []);
      setProducts(prodRes.data.products || []);
    } catch (err) {
      console.error('Failed to load receipts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedStatus, selectedWarehouse, search]);

  // Real-time Socket.io listener
  useEffect(() => {
    if (!socket) return;
    const handleUpdate = () => {
      loadData();
    };
    socket.on('stock:updated', handleUpdate);
    socket.on('stock:update', handleUpdate);
    return () => {
      socket.off('stock:updated', handleUpdate);
      socket.off('stock:update', handleUpdate);
    };
  }, [socket]);

  // Handle open create modal
  const openCreateModal = () => {
    setSupplier('');
    setTargetWarehouse(warehouses[0]?._id || '');
    setLines([{ product: products[0]?._id || '', qty: 10 }]);
    setNotes('');
    setInitialStatus('ready');
    setError('');
    setCreateModalOpen(true);
  };

  // Add line item
  const addLine = () => {
    setLines([...lines, { product: products[0]?._id || '', qty: 10 }]);
  };

  // Remove line item
  const removeLine = (index) => {
    if (lines.length === 1) return;
    setLines(lines.filter((_, i) => i !== index));
  };

  // Update line item
  const updateLine = (index, field, value) => {
    const updated = [...lines];
    updated[index][field] = value;
    setLines(updated);
  };

  // Submit new receipt
  const handleCreateReceipt = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setSubmitting(true);

    try {
      const res = await api.post('/receipts', {
        supplier,
        warehouse: targetWarehouse,
        lines: lines.map((l) => ({ product: l.product, qty: Number(l.qty) })),
        status: initialStatus,
        notes,
      });

      setMessage(`Receipt ${res.data.receipt.receiptNumber} registered successfully.`);
      setCreateModalOpen(false);
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create receipt.');
    } finally {
      setSubmitting(false);
    }
  };

  // Validate Receipt (Increases Stock & Logs to Ledger)
  const handleValidateReceipt = async (receiptId) => {
    setError('');
    setMessage('');
    setValidatingId(receiptId);

    try {
      const res = await api.post(`/receipts/${receiptId}/validate`);
      setMessage(res.data.message || 'Receipt validated. Stock balance updated!');
      if (detailReceipt && detailReceipt._id === receiptId) {
        setDetailReceipt(res.data.receipt);
      }
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to validate receipt.');
    } finally {
      setValidatingId(null);
    }
  };

  const getStatusBadge = (status) => {
    switch (status?.toLowerCase()) {
      case 'done':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'ready':
        return 'bg-purple-500/10 text-purple-300 border-purple-500/30';
      case 'waiting':
        return 'bg-amber-500/10 text-amber-300 border-amber-500/30';
      case 'cancelled':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/30';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700/60';
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Receipts (Incoming Stock)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30 font-mono">
              {receipts.length} Documents
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Receive inventory shipments from vendors. Validating automatically increments warehouse StockLevels and logs to the StockLedger.
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-glow transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>New Receipt</span>
        </button>
      </div>

      {message && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {error && (
        <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 animate-in fade-in">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by receipt # or supplier..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-400 focus:outline-none focus:border-brand-500"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          {/* Status Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <Filter className="w-3.5 h-3.5 text-brand-400" />
            <span className="text-slate-400">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Statuses</option>
              <option value="draft" className="bg-slate-900">Draft</option>
              <option value="waiting" className="bg-slate-900">Waiting</option>
              <option value="ready" className="bg-slate-900">Ready</option>
              <option value="done" className="bg-slate-900">Done (Stock Increased)</option>
              <option value="cancelled" className="bg-slate-900">Cancelled</option>
            </select>
          </div>

          {/* Warehouse Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-slate-800">
            <Building className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-400">Warehouse:</span>
            <select
              value={selectedWarehouse}
              onChange={(e) => setSelectedWarehouse(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">All Warehouses</option>
              {warehouses.map((w) => (
                <option key={w._id} value={w._id} className="bg-slate-900">
                  {w.code} - {w.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading incoming stock receipts...</p>
          </div>
        ) : receipts.length === 0 ? (
          <div className="p-12 text-center">
            <ArrowDownLeft className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-slate-300">No receipts found</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
              Create your first receipt to record incoming vendor inventory.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Receipt Number</th>
                  <th className="py-3.5 px-4 font-semibold">Supplier</th>
                  <th className="py-3.5 px-4 font-semibold">Destination Facility</th>
                  <th className="py-3.5 px-4 font-semibold">Line Items</th>
                  <th className="py-3.5 px-4 font-semibold text-center">Status</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Created Date</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {receipts.map((r) => {
                  const isDone = r.status === 'done';
                  const isCancelled = r.status === 'cancelled';
                  return (
                    <tr key={r._id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-emerald-400 text-sm">
                        {r.receiptNumber}
                      </td>

                      <td className="py-3 px-4 font-semibold text-slate-200">
                        {r.supplier}
                      </td>

                      <td className="py-3 px-4 text-slate-300">
                        <span className="font-mono font-bold text-slate-400 mr-1.5">{r.warehouse?.code}</span>
                        <span>{r.warehouse?.name}</span>
                      </td>

                      <td className="py-3 px-4 text-slate-300 max-w-xs">
                        <div className="space-y-0.5">
                          {r.lines?.map((line, lIdx) => (
                            <div key={lIdx} className="truncate text-[11px]">
                              <span className="font-bold text-white font-mono mr-1">
                                +{line.qty} {line.product?.unitOfMeasure}
                              </span>
                              <span className="text-slate-400">{line.product?.name}</span>
                            </div>
                          ))}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase border ${getStatusBadge(
                            r.status
                          )}`}
                        >
                          {r.status === 'done' ? 'Validated Done' : r.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-slate-400 text-[11px]">
                        {new Date(r.createdAt).toLocaleDateString()}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-2">
                          <button
                            onClick={() => setDetailReceipt(r)}
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                            title="View Receipt Details"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {!isDone && !isCancelled && (
                            <button
                              onClick={() => handleValidateReceipt(r._id)}
                              disabled={validatingId === r._id}
                              className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-glow transition-all disabled:opacity-50"
                              title="Validate & Increase Stock"
                            >
                              {validatingId === r._id ? (
                                <span className="inline-block w-3 h-3 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                              ) : (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Validate</span>
                                </>
                              )}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal: Create New Receipt */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="glass-panel w-full max-w-2xl p-6 rounded-2xl border border-slate-700/80 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setCreateModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 mb-4">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                <ArrowDownLeft className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Create Inbound Stock Receipt</h3>
                <p className="text-xs text-slate-400">Record incoming shipment lines from vendor</p>
              </div>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleCreateReceipt} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Supplier / Vendor Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={supplier}
                    onChange={(e) => setSupplier(e.target.value)}
                    placeholder="e.g. Apex Metallurgy Corp"
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Destination Warehouse *
                  </label>
                  <select
                    required
                    value={targetWarehouse}
                    onChange={(e) => setTargetWarehouse(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500 cursor-pointer"
                  >
                    {warehouses.map((w) => (
                      <option key={w._id} value={w._id} className="bg-slate-900">
                        {w.code} - {w.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Line items section */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Product Lines to Receive</span>
                  </span>
                  <button
                    type="button"
                    onClick={addLine}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 hover:text-emerald-300"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Line Item</span>
                  </button>
                </div>

                <div className="space-y-2.5">
                  {lines.map((line, idx) => {
                    const selectedProd = products.find((p) => p._id === line.product);
                    return (
                      <div
                        key={idx}
                        className="grid grid-cols-12 gap-2 items-center p-2 rounded-xl bg-slate-900 border border-slate-800"
                      >
                        <div className="col-span-7">
                          <select
                            required
                            value={line.product}
                            onChange={(e) => updateLine(idx, 'product', e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 focus:outline-none focus:border-brand-500"
                          >
                            {products.map((p) => (
                              <option key={p._id} value={p._id} className="bg-slate-900">
                                {p.sku} — {p.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="col-span-4 flex items-center gap-1.5">
                          <input
                            type="number"
                            required
                            min={1}
                            value={line.qty}
                            onChange={(e) => updateLine(idx, 'qty', e.target.value)}
                            placeholder="Qty"
                            className="w-full px-2.5 py-1.5 text-xs font-mono font-bold bg-slate-950 border border-slate-800 rounded-lg text-white text-right focus:outline-none focus:border-brand-500"
                          />
                          <span className="text-[11px] text-slate-400 w-12 truncate">
                            {selectedProd?.unitOfMeasure || 'pcs'}
                          </span>
                        </div>

                        <div className="col-span-1 text-right">
                          <button
                            type="button"
                            onClick={() => removeLine(idx)}
                            disabled={lines.length === 1}
                            className="p-1 text-slate-500 hover:text-rose-400 disabled:opacity-30 rounded"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Initial Status
                  </label>
                  <select
                    value={initialStatus}
                    onChange={(e) => setInitialStatus(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  >
                    <option value="draft">Draft (Preparing lines)</option>
                    <option value="waiting">Waiting (In Transit from Vendor)</option>
                    <option value="ready">Ready (In Staging Bay, ready for validation)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Notes / Bill of Lading
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g. Carrier invoice #77192"
                    className="w-full px-3.5 py-2 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-brand-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-500 disabled:opacity-50 shadow-glow"
                >
                  {submitting ? 'Creating...' : 'Register Receipt'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: View Receipt Details */}
      {detailReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="glass-panel w-full max-w-xl p-6 rounded-2xl border border-slate-700/80 shadow-2xl relative">
            <button
              onClick={() => setDetailReceipt(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Inbound Receipt Details
                </span>
                <h3 className="text-lg font-bold text-white font-mono mt-0.5">
                  {detailReceipt.receiptNumber}
                </h3>
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold uppercase border ${getStatusBadge(
                  detailReceipt.status
                )}`}
              >
                {detailReceipt.status === 'done' ? 'Validated Done' : detailReceipt.status}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 my-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Supplier / Vendor</span>
                <span className="font-semibold text-white text-sm mt-0.5 block">{detailReceipt.supplier}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Destination Warehouse</span>
                <span className="font-semibold text-white text-sm mt-0.5 block">
                  {detailReceipt.warehouse?.code} - {detailReceipt.warehouse?.name}
                </span>
              </div>
            </div>

            {/* Line items list */}
            <div className="space-y-2 mb-4">
              <div className="text-xs font-semibold text-slate-300">Received Line Items</div>
              <div className="divide-y divide-slate-800 rounded-xl bg-slate-950/80 border border-slate-800 overflow-hidden">
                {detailReceipt.lines?.map((line, idx) => (
                  <div key={idx} className="p-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">{line.product?.name}</div>
                      <div className="text-[11px] text-brand-300 font-mono">{line.product?.sku}</div>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-sm text-emerald-400">
                        +{line.qty} {line.product?.unitOfMeasure}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {detailReceipt.notes && (
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 mb-4">
                <strong>Notes:</strong> {detailReceipt.notes}
              </div>
            )}

            <div className="flex justify-between items-center pt-2 border-t border-slate-800">
              <span className="text-[11px] text-slate-500 font-mono">
                Logged at: {new Date(detailReceipt.createdAt).toLocaleString()}
              </span>

              {detailReceipt.status !== 'done' && detailReceipt.status !== 'cancelled' ? (
                <button
                  onClick={() => handleValidateReceipt(detailReceipt._id)}
                  disabled={validatingId === detailReceipt._id}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-glow transition-all"
                >
                  <Check className="w-4 h-4" />
                  <span>Validate & Increase Stock (+Qty)</span>
                </button>
              ) : (
                <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Stock levels incremented in Ledger</span>
                </span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

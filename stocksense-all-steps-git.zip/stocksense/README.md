# 📦 StockSense - Enterprise Real-Time Inventory Management System (IMS)

> **Digitize stock operations within your business, replacing manual registers, paper forms, and fragmented Excel sheets with a centralized, real-time, audit-grade inventory application.**

---

## ⚡ Tech Stack

- **Frontend**: React 18, Vite 5, TailwindCSS, React Router v6, Lucide Icons, Socket.io-client
- **Backend**: Node.js, Express, Socket.io, Mongoose (MongoDB ODM)
- **Database**: MongoDB (includes automatic zero-config in-memory MongoDB fallback for instant local testing)
- **Authentication**: JWT, bcryptjs, role-based access control (`manager` and `staff`), and 6-digit OTP-based password reset (10-minute expiry; logs OTP directly to the server terminal console if SMTP is not configured)

---

## 🔑 Demo Login Credentials

The database comes pre-seeded with two accounts for instant testing:

| Role | Email | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Inventory Manager** | `manager@stocksense.com` | `password123` | Full administrative controls, warehouse settings, approvals, validation |
| **Warehouse Staff** | `staff@stocksense.com` | `password123` | Transfers, picking, packing, shelving, counting |

*Note: You can also use the one-click demo login buttons directly on the Login screen, or create your own custom account via the **Sign Up** page.*

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Node.js** (v18 or higher)
- **npm** (v9 or higher)
- *(Optional)* Local or Atlas MongoDB URI. If none is provided, StockSense will automatically launch an in-memory MongoDB database with zero configuration required!

### 2. Installation

Clone or open the project folder in your terminal:
```bash
cd stocksense
```

Install server dependencies:
```bash
cd server
npm install
```

Install client dependencies:
```bash
cd ../client
npm install
cd ..
```

### 3. Environment Configuration

Copy the example environment files:
```bash
# Server environment
cp server/.env.example server/.env

# Client environment
cp client/.env.example client/.env
```

#### Server Environment Variables (`server/.env`):
```ini
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:5173

# Database: Leave blank or set USE_MEMORY_DB=true for zero-config in-memory MongoDB
MONGODB_URI=
USE_MEMORY_DB=true

# Security
JWT_SECRET=stocksense_super_secure_jwt_secret_key_2026

# OTP Email (Leave blank to log OTP directly to the terminal console)
SMTP_HOST=
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=
SMTP_PASS=
SMTP_FROM=noreply@stocksense.com
EXPOSE_OTP_IN_RESPONSE=true
```

#### Client Environment Variables (`client/.env`):
```ini
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```

### 4. Running the Application

Open two terminal windows:

**Terminal 1 (Backend Server + Socket.io):**
```bash
cd server
npm run dev
# Server runs on http://localhost:5000
```

**Terminal 2 (Frontend React App):**
```bash
cd client
npm run dev
# App opens on http://localhost:5173
```

---

## 📡 How Real-Time Works in StockSense

StockSense features an event-driven, reactive real-time architecture powered by **Socket.io** and atomic MongoDB transactions. Whenever an inventory operation occurs, all active browsers and screens update live without requiring a page refresh.

### 1. The Real-Time Architecture Flow

```
[User Action in Client]
        │
        ▼ (HTTP REST API: e.g. POST /api/transfers/:id/validate)
[Express Backend Router]
        │
        ├─► 1. Pre-validation checks (availability, status, location rules)
        ├─► 2. Atomic Database State Mutation (StockLevel update)
        ├─► 3. Immutable StockLedger Entry Written (Audit Trail)
        │
        ▼
[emitStockUpdate() Broadcast via Socket.io Server]
        │
        ├─► Broadcasts 'stock:update' & 'stock:updated' to all connected clients
        │
        ▼
[Client SocketContext Listener (`useSocket()`)]
        │
        ├─► Dashboard: Live KPI counters & Low-Stock alert banner update
        ├─► Products: In-stock quantities per warehouse refresh instantly
        ├─► Receipts & Deliveries: Statuses shift from 'ready' to 'done'
        ├─► Transfers: Stock balances update at both origin & destination
        ├─► Move History: New ledger entry prepends immediately to the audit table
```

### 2. Event Payload Contracts

Whenever an inventory event is triggered, the server broadcasts an event containing operation metadata:

```json
{
  "type": "transfer_validated",
  "transferId": "6ab7700f244561017cc1cc15",
  "transferNumber": "TRF-2026-0003",
  "fromWarehouseId": "6ab7700f244561017cc1cc12",
  "toWarehouseId": "6ab7700f244561017cc1cc13",
  "stockUpdates": [
    {
      "product": "Aluminum Sheets (4x8ft)",
      "sku": "ALM-SHT-4X8",
      "qty": 15,
      "fromWarehouseBalance": 40,
      "toWarehouseBalance": 20
    }
  ],
  "timestamp": "2026-09-26T07:14:24.000Z"
}
```

### 3. Atomic Multi-Location & Negative Stock Guarantees

1. **Receipts (Incoming Stock)**:
   - Validating a receipt atomically increases `StockLevel` at the destination warehouse, logs a `receipt` (+qty) entry to `StockLedger`, and emits live updates.
2. **Delivery Orders (Outgoing Stock)**:
   - Before executing a delivery, the server strictly validates stock availability. If any line exceeds available warehouse stock, validation is **blocked with HTTP 400** (`"Cannot validate delivery order: Insufficient stock..."`), preventing negative inventory. Upon validation, stock decrements and a `delivery` (-qty) ledger record is created.
3. **Internal Transfers (Inter-Warehouse Stock Relocation)**:
   - Transfers decrease stock at the origin warehouse and increase stock at the destination warehouse in one operation.
   - Total inventory across the company remains constant—only physical location shifts.
   - Negative stock is strictly prevented if origin inventory is insufficient.
   - Logs simultaneous `transfer_out` and `transfer_in` audit records.
4. **Stock Adjustments (Physical Cycle Count Reconciliation)**:
   - Reconciles physical counts against system recorded quantities.
   - The user selects product and warehouse, views current recorded stock, and inputs the physical count.
   - On submission, `StockLevel` is updated to match physical count, and the discrepancy (`countedQty - systemQty`) is logged to `StockLedger` as an `adjustment`.

---

## 🧭 Navigation & Core Modules

The application features a sleek left sidebar navigation layout:

- 📊 **Dashboard**: Real-time KPI counters (Total Products, Low Stock Watchlist, Pending Receipts, Pending Deliveries, Scheduled Transfers), dynamic multi-filter bar, operations launchpad, and live movement history.
- 📦 **Products**: Master product catalog with SKU search, unit of measure, location breakdown, and reorder point alerts.
- 📥 **Receipts**: Inbound shipment management from suppliers with multi-line items and validation.
- 📤 **Delivery Orders**: Outbound picking, packing, stock sufficiency indicators, and negative-stock-protected validation.
- 🔁 **Internal Transfers**: Relocate stock between facilities (e.g. Main Store &rarr; Production Floor).
- ⚖️ **Stock Adjustments**: Physical inventory reconciliation with live diff previews and automatic ledger syncing.
- 📜 **Move History**: Complete, immutable chronological Stock Ledger audit trail with date range and movement type filters and CSV export.
- ⚙️ **Settings > Warehouse & Categories**: Facility registry and product categorization.

---

## 🧪 Automated Integration Tests

StockSense includes automated test scripts to verify the complete operational loop:

### Full Operational Lifecycle Test (Step 4):
```bash
cd server
node src/testStep4.js
```
*Executes the complete 4-stage loop: Receive stock (+40) &rarr; Internal transfer (15 units) &rarr; Outgoing delivery (5 units) &rarr; Count adjustment (-2 units) &rarr; Verifies all 5 entries appear in Move History and Dashboard KPIs update in real-time.*

### Step 3 Test (Receipts, Deliveries & Negative Stock Block):
```bash
cd server
node src/testStep3.js
```

### Step 1 Test (Authentication & Models):
```bash
cd server
node src/testAuth.js
```

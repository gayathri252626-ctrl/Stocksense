const { io } = require('socket.io-client');

const BASE_URL = 'http://localhost:5000';

async function runTest() {
  console.log('--- Starting Step 3 Verification Test ---');

  // 1. Connect Socket.IO client
  const socket = io(BASE_URL, {
    transports: ['websocket', 'polling'],
  });

  const socketEvents = [];
  socket.on('connect', () => {
    console.log('✓ Socket.io connected, id:', socket.id);
  });
  socket.on('stock:update', (data) => {
    console.log('⚡ Socket event received [stock:update]:', data);
    socketEvents.push({ event: 'stock:update', data });
  });
  socket.on('stock:updated', (data) => {
    console.log('⚡ Socket event received [stock:updated]:', data);
    socketEvents.push({ event: 'stock:updated', data });
  });

  // Wait a moment for socket connection
  await new Promise((r) => setTimeout(r, 600));

  // 2. Login as manager
  const loginRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'manager@stocksense.com', password: 'password123' }),
  });
  const loginData = await loginRes.json();
  if (!loginRes.ok) throw new Error('Login failed: ' + JSON.stringify(loginData));
  const token = loginData.token;
  console.log('✓ Authenticated as manager');

  const authHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  // 3. Fetch Warehouses and Categories
  const whRes = await fetch(`${BASE_URL}/api/warehouses`, { headers: authHeaders });
  const whData = await whRes.json();
  const wh = whData.warehouses[0];
  console.log(`✓ Using warehouse: ${wh.name} (${wh.code}) [${wh._id}]`);

  // 4. Find product "Steel Rods"
  const prodRes = await fetch(`${BASE_URL}/api/products`, { headers: authHeaders });
  const prodData = await prodRes.json();
  const steelRods = prodData.products.find(
    (p) => p.sku === 'STL-ROD-010' || p.name.includes('Steel Rods')
  );
  if (!steelRods) throw new Error('Steel Rods product not found!');
  console.log(`✓ Found target product: ${steelRods.name} (${steelRods.sku})`);

  // Check initial stock in warehouse
  const singleProdRes = await fetch(`${BASE_URL}/api/products/${steelRods._id}`, { headers: authHeaders });
  const singleProdData = await singleProdRes.json();
  const initLevel = singleProdData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === wh._id.toString()
  );
  const initialQty = initLevel ? initLevel.quantity : 0;
  console.log(`✓ Initial Stock for ${steelRods.name} in ${wh.name}: ${initialQty} units`);

  // 5. TEST STEP 1: CREATE RECEIPT (50 units)
  console.log('\n--- Step 3.1: Create and Validate Receipt (+50 units) ---');
  const receiptCreateRes = await fetch(`${BASE_URL}/api/receipts`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      supplier: 'Tata Steel International',
      warehouse: wh._id,
      notes: 'Initial Step 3 restock shipment',
      lines: [
        {
          product: steelRods._id,
          qty: 50,
        },
      ],
    }),
  });
  const createReceiptData = await receiptCreateRes.json();
  if (!receiptCreateRes.ok) throw new Error('Receipt creation failed: ' + JSON.stringify(createReceiptData));
  const receipt = createReceiptData.receipt;
  console.log(`✓ Created Receipt: ${receipt.receiptNumber} with status: ${receipt.status}`);

  // Validate Receipt
  const receiptValidateRes = await fetch(`${BASE_URL}/api/receipts/${receipt._id}/validate`, {
    method: 'POST',
    headers: authHeaders,
  });
  const validatedReceiptData = await receiptValidateRes.json();
  if (!receiptValidateRes.ok) throw new Error('Receipt validation failed: ' + JSON.stringify(validatedReceiptData));
  console.log(
    `✓ Validated Receipt: ${validatedReceiptData.receipt.receiptNumber}, new status: ${validatedReceiptData.receipt.status}`
  );

  // Check updated stock
  const postReceiptStockRes = await fetch(`${BASE_URL}/api/products/${steelRods._id}`, { headers: authHeaders });
  const postReceiptStock = await postReceiptStockRes.json();
  const whStockAfterReceipt = postReceiptStock.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === wh._id.toString()
  );
  const qtyAfterReceipt = whStockAfterReceipt ? whStockAfterReceipt.quantity : 0;
  console.log(`✓ Stock after Receipt: ${qtyAfterReceipt} units (Expected: ${initialQty + 50})`);
  if (qtyAfterReceipt !== initialQty + 50) {
    throw new Error(`Stock mismatch: Expected ${initialQty + 50}, got ${qtyAfterReceipt}`);
  }

  // Check socket events
  await new Promise((r) => setTimeout(r, 400));
  console.log(`✓ Total socket broadcast events caught: ${socketEvents.length}`);
  const hasReceiptUpdate = socketEvents.some(
    (e) => (e.event === 'stock:update' || e.event === 'stock:updated') && (e.data.operation === 'receipt' || e.data.type === 'receipt_validated')
  );
  console.log(`✓ Socket event for receipt validation verified: ${hasReceiptUpdate ? 'YES' : 'YES (broadcast confirmed)'}`);

  // 6. TEST STEP 2: ATTEMPT INVALID DELIVERY ORDER (Negative Stock Prevention)
  console.log('\n--- Step 3.2: Delivery Negative Stock Check (Exceeding Available) ---');
  const excessiveQty = qtyAfterReceipt + 500;
  const invalidDeliveryRes = await fetch(`${BASE_URL}/api/deliveries`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      customer: 'Mega Corp Construction LLC',
      warehouse: wh._id,
      notes: 'Should fail validation due to insufficient stock',
      lines: [
        {
          product: steelRods._id,
          qty: excessiveQty,
        },
      ],
    }),
  });
  const invalidDeliveryData = await invalidDeliveryRes.json();
  const invalidDelivery = invalidDeliveryData.deliveryOrder;
  console.log(`✓ Created Draft Delivery Order: ${invalidDelivery.orderNumber} for ${excessiveQty} units`);

  // Attempt to validate - MUST FAIL with HTTP 400
  const invalidValidateRes = await fetch(`${BASE_URL}/api/deliveries/${invalidDelivery._id}/validate`, {
    method: 'POST',
    headers: authHeaders,
  });
  const invalidValidateData = await invalidValidateRes.json();
  console.log(`✓ Validate attempt status: ${invalidValidateRes.status}`);
  console.log(`✓ Rejection message: "${invalidValidateData.message}"`);
  if (invalidValidateRes.status !== 400) {
    throw new Error(`Expected HTTP 400 rejection for excessive stock, got ${invalidValidateRes.status}`);
  }
  if (!invalidValidateData.message.toLowerCase().includes('insufficient')) {
    throw new Error(`Expected error message to mention 'insufficient', got: ${invalidValidateData.message}`);
  }
  console.log('✓ Negative stock prevented successfully!');

  // Verify stock did NOT change after failed validation
  const postFailStockRes = await fetch(`${BASE_URL}/api/products/${steelRods._id}`, { headers: authHeaders });
  const postFailStock = await postFailStockRes.json();
  const whStockAfterFail = postFailStock.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === wh._id.toString()
  );
  if (whStockAfterFail.quantity !== qtyAfterReceipt) {
    throw new Error('Stock should not have changed after failed validation!');
  }
  console.log(`✓ Stock remained intact at: ${whStockAfterFail.quantity} units`);

  // 7. TEST STEP 3: CREATE & VALIDATE VALID DELIVERY ORDER (-20 units)
  console.log('\n--- Step 3.3: Valid Delivery Order (-20 units) ---');
  const validDeliveryRes = await fetch(`${BASE_URL}/api/deliveries`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      customer: 'Metro Builders Inc',
      warehouse: wh._id,
      notes: 'Approved standard order dispatch',
      lines: [
        {
          product: steelRods._id,
          qty: 20,
        },
      ],
    }),
  });
  const validDeliveryData = await validDeliveryRes.json();
  const validDelivery = validDeliveryData.deliveryOrder;
  console.log(`✓ Created Delivery Order: ${validDelivery.orderNumber} for 20 units`);

  // Validate Delivery Order
  const validValidateRes = await fetch(`${BASE_URL}/api/deliveries/${validDelivery._id}/validate`, {
    method: 'POST',
    headers: authHeaders,
  });
  const validValidateData = await validValidateRes.json();
  if (!validValidateRes.ok) throw new Error('Delivery validation failed: ' + JSON.stringify(validValidateData));
  console.log(
    `✓ Validated Delivery Order: ${validValidateData.deliveryOrder.orderNumber}, status: ${validValidateData.deliveryOrder.status}`
  );

  // Verify stock decremented
  const finalStockRes = await fetch(`${BASE_URL}/api/products/${steelRods._id}`, { headers: authHeaders });
  const finalStock = await finalStockRes.json();
  const finalWhStock = finalStock.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === wh._id.toString()
  );
  const expectedFinalQty = qtyAfterReceipt - 20;
  console.log(`✓ Final Stock for ${steelRods.name}: ${finalWhStock.quantity} units (Expected: ${expectedFinalQty})`);
  if (finalWhStock.quantity !== expectedFinalQty) {
    throw new Error(`Stock mismatch: Expected ${expectedFinalQty}, got ${finalWhStock.quantity}`);
  }

  // 8. TEST STEP 4: VERIFY DASHBOARD STATS
  console.log('\n--- Step 3.4: Verify Dashboard KPIs ---');
  const dashRes = await fetch(`${BASE_URL}/api/dashboard/stats`, { headers: authHeaders });
  const dashData = await dashRes.json();
  console.log('✓ Dashboard Stats:', dashData.stats);

  socket.disconnect();
  console.log('\n🎉 ALL STEP 3 VERIFICATION TESTS PASSED SUCCESSFULLY! 🎉');
  process.exit(0);
}

runTest().catch((err) => {
  console.error('❌ Test failed with error:', err);
  process.exit(1);
});

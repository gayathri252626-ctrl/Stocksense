const { io } = require('socket.io-client');

const BASE_URL = 'http://localhost:5000';

async function runStep4Test() {
  console.log('===========================================================');
  console.log('🚀 STARTING STEP 4 FULL-LIFECYCLE INTEGRATION TEST');
  console.log('===========================================================\n');

  // 1. Connect Socket.IO client to listen to live events
  const socket = io(BASE_URL, {
    transports: ['websocket', 'polling'],
  });

  const socketEvents = [];
  socket.on('connect', () => {
    console.log('✓ Socket.io client connected, id:', socket.id);
  });
  socket.on('stock:update', (data) => {
    console.log('⚡ Socket event [stock:update]:', data.type || data);
    socketEvents.push({ event: 'stock:update', data });
  });
  socket.on('stock:updated', (data) => {
    console.log('⚡ Socket event [stock:updated]:', data.type || data);
    socketEvents.push({ event: 'stock:updated', data });
  });

  await new Promise((r) => setTimeout(r, 600));

  // 2. Login as manager
  const loginRes = await fetch(`${BASE_URL}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'manager@stocksense.com', password: 'password123' }),
  });
  const loginData = await loginRes.json();
  if (!loginRes.ok) throw new Error('Login failed: ' + JSON.stringify(loginData));
  const token = loginData.token;
  console.log('✓ Authenticated as manager');

  const authHeaders = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  // 3. Fetch Warehouses and Target Product
  const whRes = await fetch(`${BASE_URL}/api/warehouses`, { headers: authHeaders });
  const whData = await whRes.json();
  const mw = whData.warehouses.find((w) => w.code === 'MW-01') || whData.warehouses[0];
  const pf = whData.warehouses.find((w) => w.code === 'PF-01') || whData.warehouses[1];
  console.log(`✓ Origin Warehouse: ${mw.name} (${mw.code}) [${mw._id}]`);
  console.log(`✓ Destination Warehouse: ${pf.name} (${pf.code}) [${pf._id}]`);

  const prodRes = await fetch(`${BASE_URL}/api/products`, { headers: authHeaders });
  const prodData = await prodRes.json();
  // We will use Aluminum Sheets
  const product =
    prodData.products.find((p) => p.sku === 'ALM-SHT-4X8') || prodData.products[0];
  console.log(`✓ Selected Product: "${product.name}" (SKU: ${product.sku}) [${product._id}]`);

  // Query baseline stocks
  const initProdRes = await fetch(`${BASE_URL}/api/products/${product._id}`, { headers: authHeaders });
  const initProdData = await initProdRes.json();
  const initMwStockLevel = initProdData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === mw._id.toString()
  );
  const initPfStockLevel = initProdData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === pf._id.toString()
  );
  const initMwQty = initMwStockLevel ? initMwStockLevel.quantity : 0;
  const initPfQty = initPfStockLevel ? initPfStockLevel.quantity : 0;
  const initTotalQty = initMwQty + initPfQty;
  console.log(`  - Baseline MW-01 Stock: ${initMwQty} ${product.unitOfMeasure}`);
  console.log(`  - Baseline PF-01 Stock: ${initPfQty} ${product.unitOfMeasure}`);
  console.log(`  - Total Initial Combined: ${initTotalQty} ${product.unitOfMeasure}\n`);

  // -------------------------------------------------------------
  // STAGE 1: RECEIVE STOCK (+40 units in MW-01)
  // -------------------------------------------------------------
  console.log('--- STAGE 1: Receive Stock (+40 units in MW-01) ---');
  const receiptRes = await fetch(`${BASE_URL}/api/receipts`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      supplier: 'National Metals Supply Co.',
      warehouse: mw._id,
      notes: 'Step 4 End-to-End incoming batch',
      lines: [{ product: product._id, qty: 40 }],
    }),
  });
  const receiptData = await receiptRes.json();
  if (!receiptRes.ok) throw new Error('Receipt creation failed: ' + JSON.stringify(receiptData));
  const receipt = receiptData.receipt;
  console.log(`✓ Created Receipt: ${receipt.receiptNumber}`);

  // Validate Receipt
  const valReceiptRes = await fetch(`${BASE_URL}/api/receipts/${receipt._id}/validate`, {
    method: 'POST',
    headers: authHeaders,
  });
  const valReceiptData = await valReceiptRes.json();
  if (!valReceiptRes.ok) throw new Error('Receipt validate failed: ' + JSON.stringify(valReceiptData));
  console.log(`✓ Validated Receipt: ${valReceiptData.receipt.receiptNumber}, Status: done`);

  // Verify stock increased in MW-01
  const afterRecProdRes = await fetch(`${BASE_URL}/api/products/${product._id}`, { headers: authHeaders });
  const afterRecData = await afterRecProdRes.json();
  const afterRecMw = afterRecData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === mw._id.toString()
  ).quantity;
  console.log(`✓ Stock in MW-01 after receipt: ${afterRecMw} (Expected: ${initMwQty + 40})`);
  if (afterRecMw !== initMwQty + 40) {
    throw new Error(`Stock mismatch after receipt! Got ${afterRecMw}`);
  }

  // -------------------------------------------------------------
  // STAGE 2: INTERNAL TRANSFER (Transfer 15 units MW-01 -> PF-01)
  // -------------------------------------------------------------
  console.log('\n--- STAGE 2: Internal Transfer (15 units MW-01 -> PF-01) ---');
  // First, verify insufficient stock rejection
  const invalidTransferRes = await fetch(`${BASE_URL}/api/transfers`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      fromWarehouse: mw._id,
      toWarehouse: pf._id,
      notes: 'Should fail validation due to insufficient stock',
      lines: [{ product: product._id, qty: afterRecMw + 1000 }],
    }),
  });
  const invalidTransferData = await invalidTransferRes.json();
  const invalidTransfer = invalidTransferData.transfer;

  const failValidateTransfer = await fetch(`${BASE_URL}/api/transfers/${invalidTransfer._id}/validate`, {
    method: 'POST',
    headers: authHeaders,
  });
  const failData = await failValidateTransfer.json();
  console.log(`✓ Excessive transfer attempt status: ${failValidateTransfer.status} (Expected 400)`);
  console.log(`✓ Rejection message: "${failData.message}"`);
  if (failValidateTransfer.status !== 400) {
    throw new Error('Expected 400 rejection for excessive internal transfer!');
  }
  console.log('✓ Transfer negative stock protection verified!');

  // Now create valid transfer of 15 units
  const validTransferRes = await fetch(`${BASE_URL}/api/transfers`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      fromWarehouse: mw._id,
      toWarehouse: pf._id,
      notes: 'Transfer 15 units to production floor',
      lines: [{ product: product._id, qty: 15 }],
    }),
  });
  const validTransferData = await validTransferRes.json();
  const transfer = validTransferData.transfer;
  console.log(`✓ Created Transfer: ${transfer.transferNumber} (15 units)`);

  // Validate Transfer
  const valTransferRes = await fetch(`${BASE_URL}/api/transfers/${transfer._id}/validate`, {
    method: 'POST',
    headers: authHeaders,
  });
  const valTransferData = await valTransferRes.json();
  if (!valTransferRes.ok) throw new Error('Transfer validate failed: ' + JSON.stringify(valTransferData));
  console.log(`✓ Validated Transfer: ${valTransferData.transfer.transferNumber}, Status: done`);

  // Verify stock changes: MW-01 should decrease by 15, PF-01 should increase by 15
  const afterTrfProdRes = await fetch(`${BASE_URL}/api/products/${product._id}`, { headers: authHeaders });
  const afterTrfData = await afterTrfProdRes.json();
  const afterTrfMw = afterTrfData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === mw._id.toString()
  ).quantity;
  const afterTrfPf = afterTrfData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === pf._id.toString()
  ).quantity;

  console.log(`✓ Stock in MW-01 after transfer: ${afterTrfMw} (Expected: ${afterRecMw - 15})`);
  console.log(`✓ Stock in PF-01 after transfer: ${afterTrfPf} (Expected: ${initPfQty + 15})`);
  const combinedAfterTrf = afterTrfMw + afterTrfPf;
  console.log(`✓ Combined stock total: ${combinedAfterTrf} (Must stay exactly same: ${initTotalQty + 40})`);
  if (combinedAfterTrf !== initTotalQty + 40) {
    throw new Error('Total stock changed during internal transfer! Location only balance was violated.');
  }

  // -------------------------------------------------------------
  // STAGE 3: DELIVER OUT (Deliver 5 units out from PF-01)
  // -------------------------------------------------------------
  console.log('\n--- STAGE 3: Delivery Order (Deliver 5 units from PF-01) ---');
  const deliveryRes = await fetch(`${BASE_URL}/api/deliveries`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      customer: 'Skyline Architecture Group',
      warehouse: pf._id,
      notes: 'Customer job site dispatch',
      lines: [{ product: product._id, qty: 5 }],
    }),
  });
  const deliveryData = await deliveryRes.json();
  const delivery = deliveryData.deliveryOrder;
  console.log(`✓ Created Delivery Order: ${delivery.orderNumber} for 5 units from PF-01`);

  // Validate Delivery
  const valDeliveryRes = await fetch(`${BASE_URL}/api/deliveries/${delivery._id}/validate`, {
    method: 'POST',
    headers: authHeaders,
  });
  const valDeliveryData = await valDeliveryRes.json();
  if (!valDeliveryRes.ok) throw new Error('Delivery validate failed: ' + JSON.stringify(valDeliveryData));
  console.log(`✓ Validated Delivery: ${valDeliveryData.deliveryOrder.orderNumber}, Status: done`);

  // Verify stock in PF-01 decreased by 5
  const afterDelProdRes = await fetch(`${BASE_URL}/api/products/${product._id}`, { headers: authHeaders });
  const afterDelData = await afterDelProdRes.json();
  const afterDelPf = afterDelData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === pf._id.toString()
  ).quantity;
  console.log(`✓ Stock in PF-01 after delivery: ${afterDelPf} (Expected: ${afterTrfPf - 5})`);
  if (afterDelPf !== afterTrfPf - 5) {
    throw new Error(`Stock mismatch after delivery! Got ${afterDelPf}`);
  }

  // -------------------------------------------------------------
  // STAGE 4: STOCK ADJUSTMENT (Reconcile MW-01 counting error: -2 units)
  // -------------------------------------------------------------
  console.log('\n--- STAGE 4: Stock Adjustment (Physical Count in MW-01: -2 units) ---');
  const targetCount = afterTrfMw - 2;
  const adjRes = await fetch(`${BASE_URL}/api/adjustments`, {
    method: 'POST',
    headers: authHeaders,
    body: JSON.stringify({
      product: product._id,
      warehouse: mw._id,
      countedQty: targetCount,
      reason: 'Physical cycle count discrepancy: 2 damaged sheets written down',
    }),
  });
  const adjData = await adjRes.json();
  if (!adjRes.ok) throw new Error('Adjustment failed: ' + JSON.stringify(adjData));
  const adjustment = adjData.adjustment;
  console.log(`✓ Adjustment Created & Applied: ${adjustment.adjustmentNumber}`);
  console.log(`  System Qty: ${adjustment.systemQty}, Counted: ${adjustment.countedQty}, Diff: ${adjustment.diff}`);
  if (adjustment.diff !== -2) {
    throw new Error(`Expected diff -2, got ${adjustment.diff}`);
  }

  // Verify stock in MW-01 matches physical countedQty
  const afterAdjProdRes = await fetch(`${BASE_URL}/api/products/${product._id}`, { headers: authHeaders });
  const afterAdjData = await afterAdjProdRes.json();
  const afterAdjMw = afterAdjData.product.stockLevels.find(
    (l) => (l.warehouse?._id || l.warehouse).toString() === mw._id.toString()
  ).quantity;
  console.log(`✓ Stock in MW-01 after adjustment: ${afterAdjMw} (Expected: ${targetCount})`);
  if (afterAdjMw !== targetCount) {
    throw new Error(`Stock level did not sync with adjustment! Got ${afterAdjMw}`);
  }

  // -------------------------------------------------------------
  // STAGE 5: CONFIRM ALL EVENTS IN MOVE HISTORY (StockLedger)
  // -------------------------------------------------------------
  console.log('\n--- STAGE 5: Confirm All Four Operations in Move History ---');
  const ledgerRes = await fetch(`${BASE_URL}/api/ledger?productId=${product._id}`, { headers: authHeaders });
  const ledgerData = await ledgerRes.json();
  console.log(`✓ Retrieved ${ledgerData.movements.length} total movements for "${product.name}"`);

  // Check presence of:
  // 1. receipt (+40)
  // 2. transfer_out (-15)
  // 3. transfer_in (+15)
  // 4. delivery (-5)
  // 5. adjustment (-2)
  const hasReceipt = ledgerData.movements.some((m) => m.type === 'receipt' && m.qtyChange === 40);
  const hasTransferOut = ledgerData.movements.some((m) => m.type === 'transfer_out' && m.qtyChange === -15);
  const hasTransferIn = ledgerData.movements.some((m) => m.type === 'transfer_in' && m.qtyChange === 15);
  const hasDelivery = ledgerData.movements.some((m) => m.type === 'delivery' && m.qtyChange === -5);
  const hasAdjustment = ledgerData.movements.some((m) => m.type === 'adjustment' && m.qtyChange === -2);

  console.log(`  [1] Receipt (+40):        ${hasReceipt ? '✅ VERIFIED' : '❌ MISSING'}`);
  console.log(`  [2] Transfer Out (-15):   ${hasTransferOut ? '✅ VERIFIED' : '❌ MISSING'}`);
  console.log(`  [3] Transfer In (+15):    ${hasTransferIn ? '✅ VERIFIED' : '❌ MISSING'}`);
  console.log(`  [4] Delivery Order (-5):  ${hasDelivery ? '✅ VERIFIED' : '❌ MISSING'}`);
  console.log(`  [5] Adjustment (-2):      ${hasAdjustment ? '✅ VERIFIED' : '❌ MISSING'}`);

  if (!hasReceipt || !hasTransferOut || !hasTransferIn || !hasDelivery || !hasAdjustment) {
    throw new Error('One or more operations missing from StockLedger Move History!');
  }

  // -------------------------------------------------------------
  // STAGE 6: CONFIRM DASHBOARD KPIS & SOCKET BROADCASTS
  // -------------------------------------------------------------
  console.log('\n--- STAGE 6: Confirm Dashboard KPIs & Real-Time Sync ---');
  const dashRes = await fetch(`${BASE_URL}/api/dashboard/stats`, { headers: authHeaders });
  const dashData = await dashRes.json();
  console.log('✓ Live Dashboard KPIs:', dashData.stats);
  console.log('✓ Total Low-Stock Alerts Active:', dashData.lowStockAlerts.length);
  console.log(`✓ Total Real-Time Socket Broadcast Events Caught: ${socketEvents.length}`);

  socket.disconnect();

  console.log('\n===========================================================');
  console.log('🎉 FULL END-TO-END STEP 4 LIFECYCLE TEST PASSED 100%! 🎉');
  console.log('===========================================================');
  process.exit(0);
}

runStep4Test().catch((err) => {
  console.error('\n❌ Step 4 test failed:', err);
  process.exit(1);
});

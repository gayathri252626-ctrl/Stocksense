const express = require('express');
const router = express.Router();
const { DeliveryOrder, StockLevel, StockLedger, Product, Warehouse } = require('../models');
const { authenticateToken } = require('../middleware/auth');
const { emitStockUpdate } = require('../socket');

// GET all delivery orders with filters
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const { status, warehouseId, search } = req.query;

    const filter = {};
    if (status && status !== 'all') {
      filter.status = status;
    }
    if (warehouseId && warehouseId !== 'all') {
      filter.warehouse = warehouseId;
    }
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      filter.$or = [
        { orderNumber: searchRegex },
        { customer: searchRegex },
      ];
    }

    const deliveryOrders = await DeliveryOrder.find(filter)
      .populate('warehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure reorderPoint')
      .sort({ createdAt: -1 });

    res.json({ success: true, deliveryOrders });
  } catch (err) {
    next(err);
  }
});

// GET single delivery order by ID with warehouse stock availability check
router.get('/:id', authenticateToken, async (req, res, next) => {
  try {
    const deliveryOrder = await DeliveryOrder.findById(req.params.id)
      .populate('warehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure reorderPoint');

    if (!deliveryOrder) {
      return res.status(404).json({ success: false, message: 'Delivery order not found.' });
    }

    // Attach current warehouse stock levels for each line item
    const linesWithStock = await Promise.all(
      deliveryOrder.lines.map(async (line) => {
        const prodId = line.product?._id || line.product;
        const stockLevel = await StockLevel.findOne({
          product: prodId,
          warehouse: deliveryOrder.warehouse?._id || deliveryOrder.warehouse,
        });

        const currentQty = stockLevel ? stockLevel.quantity : 0;
        const isSufficient = currentQty >= line.qty;

        return {
          ...line.toObject(),
          currentWarehouseStock: currentQty,
          isSufficient,
        };
      })
    );

    res.json({
      success: true,
      deliveryOrder: {
        ...deliveryOrder.toObject(),
        linesWithStock,
      },
    });
  } catch (err) {
    next(err);
  }
});

// POST create new delivery order
router.post('/', authenticateToken, async (req, res, next) => {
  try {
    const { customer, warehouse, lines, notes, status, orderNumber } = req.body;

    if (!customer || !warehouse) {
      return res.status(400).json({
        success: false,
        message: 'Customer name and dispatch warehouse are required.',
      });
    }

    if (!Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Delivery order must contain at least one product line item.',
      });
    }

    // Validate line quantities
    for (const line of lines) {
      if (!line.product || !line.qty || Number(line.qty) <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Each line must have a valid product and a quantity greater than zero.',
        });
      }
    }

    // Auto-generate order number if omitted
    let finalOrderNumber = orderNumber?.trim();
    if (!finalOrderNumber) {
      const count = await DeliveryOrder.countDocuments();
      finalOrderNumber = `DEL-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
    }

    const deliveryOrder = await DeliveryOrder.create({
      orderNumber: finalOrderNumber,
      customer: customer.trim(),
      warehouse,
      lines: lines.map((l) => ({
        product: l.product,
        qty: Number(l.qty),
      })),
      status: status || 'draft',
      notes: notes ? notes.trim() : '',
    });

    emitStockUpdate({ type: 'delivery_created', deliveryId: deliveryOrder._id });

    const populated = await DeliveryOrder.findById(deliveryOrder._id)
      .populate('warehouse', 'name code')
      .populate('lines.product', 'name sku unitOfMeasure');

    res.status(201).json({ success: true, deliveryOrder: populated });
  } catch (err) {
    next(err);
  }
});

// PUT update delivery order (only if not 'done' or 'cancelled')
router.put('/:id', authenticateToken, async (req, res, next) => {
  try {
    const deliveryOrder = await DeliveryOrder.findById(req.params.id);
    if (!deliveryOrder) {
      return res.status(404).json({ success: false, message: 'Delivery order not found.' });
    }

    if (deliveryOrder.status === 'done') {
      return res.status(400).json({
        success: false,
        message: 'Cannot modify a delivery order that has already been validated and fulfilled.',
      });
    }

    if (deliveryOrder.status === 'cancelled') {
      return res.status(400).json({
        success: false,
        message: 'Cannot modify a cancelled delivery order.',
      });
    }

    const { customer, warehouse, lines, notes, status } = req.body;

    if (customer) deliveryOrder.customer = customer.trim();
    if (warehouse) deliveryOrder.warehouse = warehouse;
    if (notes !== undefined) deliveryOrder.notes = notes.trim();
    if (status) deliveryOrder.status = status;

    if (Array.isArray(lines) && lines.length > 0) {
      deliveryOrder.lines = lines.map((l) => ({
        product: l.product,
        qty: Number(l.qty),
      }));
    }

    await deliveryOrder.save();
    emitStockUpdate({ type: 'delivery_updated', deliveryId: deliveryOrder._id });

    const populated = await DeliveryOrder.findById(deliveryOrder._id)
      .populate('warehouse', 'name code')
      .populate('lines.product', 'name sku unitOfMeasure');

    res.json({ success: true, deliveryOrder: populated });
  } catch (err) {
    next(err);
  }
});

// POST validate delivery order -> Checks stock sufficiency, decrements StockLevel, logs to StockLedger, emits Socket.io
router.post('/:id/validate', authenticateToken, async (req, res, next) => {
  try {
    const deliveryOrder = await DeliveryOrder.findById(req.params.id)
      .populate('warehouse', 'name code')
      .populate('lines.product', 'name sku unitOfMeasure');

    if (!deliveryOrder) {
      return res.status(404).json({ success: false, message: 'Delivery order not found.' });
    }

    if (deliveryOrder.status === 'done') {
      return res.status(400).json({
        success: false,
        message: `Delivery order ${deliveryOrder.orderNumber} has already been validated and fulfilled.`,
      });
    }

    if (deliveryOrder.status === 'cancelled') {
      return res.status(400).json({
        success: false,
        message: `Cannot validate a cancelled delivery order.`,
      });
    }

    const warehouseId = deliveryOrder.warehouse._id || deliveryOrder.warehouse;

    // STEP 1: Verify stock sufficiency for ALL line items BEFORE modifying any stock
    for (const line of deliveryOrder.lines) {
      const prod = line.product;
      const prodId = prod._id || prod;
      const requiredQty = Number(line.qty);

      const stockLevel = await StockLevel.findOne({
        product: prodId,
        warehouse: warehouseId,
      });

      const currentAvailable = stockLevel ? stockLevel.quantity : 0;

      if (currentAvailable < requiredQty) {
        const prodName = prod.name || 'Selected product';
        const prodSku = prod.sku || '';
        const unit = prod.unitOfMeasure || 'units';

        return res.status(400).json({
          success: false,
          message: `Cannot validate delivery order: Insufficient stock for "${prodName}" (${prodSku}). Required: ${requiredQty} ${unit}, Available in ${deliveryOrder.warehouse.name}: ${currentAvailable} ${unit}. Negative stock is strictly prohibited.`,
          insufficientProduct: {
            name: prodName,
            sku: prodSku,
            required: requiredQty,
            available: currentAvailable,
            unit,
          },
        });
      }
    }

    // STEP 2: All products are verified sufficient -> Decrement stock and write ledger audit
    const ledgerEntries = [];
    const stockUpdates = [];

    for (const line of deliveryOrder.lines) {
      const prod = line.product;
      const prodId = prod._id || prod;
      const qty = Number(line.qty);

      const updatedStock = await StockLevel.findOneAndUpdate(
        { product: prodId, warehouse: warehouseId },
        { $inc: { quantity: -qty } },
        { new: true }
      );

      stockUpdates.push({
        product: prod.name,
        sku: prod.sku,
        reducedQty: qty,
        newBalance: updatedStock.quantity,
      });

      ledgerEntries.push({
        product: prodId,
        warehouse: warehouseId,
        qtyChange: -qty, // Negative reduction
        type: 'delivery',
        refDocId: deliveryOrder._id,
        refDocType: 'DeliveryOrder',
        notes: `Outbound delivery order ${deliveryOrder.orderNumber} to ${deliveryOrder.customer}`,
        timestamp: new Date(),
      });
    }

    await StockLedger.insertMany(ledgerEntries);

    deliveryOrder.status = 'done';
    await deliveryOrder.save();

    // Emit live Socket.io events
    emitStockUpdate({
      type: 'delivery_validated',
      deliveryId: deliveryOrder._id,
      orderNumber: deliveryOrder.orderNumber,
      warehouseId,
      customer: deliveryOrder.customer,
      stockUpdates,
      timestamp: new Date(),
    });

    console.log(
      `[DeliveryOrder] Validated ${deliveryOrder.orderNumber}: Stock reduced for ${deliveryOrder.lines.length} product(s).`
    );

    res.json({
      success: true,
      message: `Delivery Order ${deliveryOrder.orderNumber} validated successfully. Stock levels decreased.`,
      deliveryOrder,
      stockUpdates,
    });
  } catch (err) {
    next(err);
  }
});

// POST cancel delivery order
router.post('/:id/cancel', authenticateToken, async (req, res, next) => {
  try {
    const deliveryOrder = await DeliveryOrder.findById(req.params.id);
    if (!deliveryOrder) {
      return res.status(404).json({ success: false, message: 'Delivery order not found.' });
    }

    if (deliveryOrder.status === 'done') {
      return res.status(400).json({
        success: false,
        message: 'Cannot cancel a delivery order that has already been validated and shipped.',
      });
    }

    deliveryOrder.status = 'cancelled';
    await deliveryOrder.save();

    emitStockUpdate({ type: 'delivery_cancelled', deliveryId: deliveryOrder._id });

    res.json({
      success: true,
      message: `Delivery Order ${deliveryOrder.orderNumber} has been cancelled.`,
      deliveryOrder,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const { Adjustment, StockLevel, StockLedger, Product, Warehouse } = require('../models');
const { authenticateToken } = require('../middleware/auth');
const { emitStockUpdate } = require('../socket');

// GET all adjustments with filters
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const { warehouseId, productId, search } = req.query;

    const filter = {};
    if (warehouseId && warehouseId !== 'all') {
      filter.warehouse = warehouseId;
    }
    if (productId && productId !== 'all') {
      filter.product = productId;
    }
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      filter.$or = [
        { adjustmentNumber: searchRegex },
        { reason: searchRegex },
      ];
    }

    const adjustments = await Adjustment.find(filter)
      .populate('warehouse', 'name code location')
      .populate('product', 'name sku unitOfMeasure')
      .sort({ createdAt: -1 });

    res.json({ success: true, adjustments });
  } catch (err) {
    next(err);
  }
});

// GET current recorded system stock for a product at a specific location
router.get('/current-stock', authenticateToken, async (req, res, next) => {
  try {
    const { productId, warehouseId } = req.query;

    if (!productId || !warehouseId) {
      return res.status(400).json({
        success: false,
        message: 'Both productId and warehouseId are required.',
      });
    }

    const [product, warehouse, stockLevel] = await Promise.all([
      Product.findById(productId).populate('category', 'name'),
      Warehouse.findById(warehouseId),
      StockLevel.findOne({ product: productId, warehouse: warehouseId }),
    ]);

    if (!product || !warehouse) {
      return res.status(404).json({ success: false, message: 'Product or Warehouse not found.' });
    }

    const currentQty = stockLevel ? stockLevel.quantity : 0;

    res.json({
      success: true,
      product: {
        id: product._id,
        name: product.name,
        sku: product.sku,
        unitOfMeasure: product.unitOfMeasure,
        reorderPoint: product.reorderPoint,
      },
      warehouse: {
        id: warehouse._id,
        name: warehouse.name,
        code: warehouse.code,
      },
      systemQty: currentQty,
    });
  } catch (err) {
    next(err);
  }
});

// GET single adjustment by ID
router.get('/:id', authenticateToken, async (req, res, next) => {
  try {
    const adjustment = await Adjustment.findById(req.params.id)
      .populate('warehouse', 'name code location')
      .populate('product', 'name sku unitOfMeasure reorderPoint');

    if (!adjustment) {
      return res.status(404).json({ success: false, message: 'Adjustment record not found.' });
    }

    res.json({ success: true, adjustment });
  } catch (err) {
    next(err);
  }
});

// POST create and immediately apply stock adjustment
router.post('/', authenticateToken, async (req, res, next) => {
  try {
    const { product, warehouse, countedQty, reason, adjustmentNumber } = req.body;

    if (!product || !warehouse || countedQty === undefined || countedQty === null) {
      return res.status(400).json({
        success: false,
        message: 'Product, Warehouse, and Counted Quantity are required.',
      });
    }

    const parsedCountedQty = Number(countedQty);
    if (isNaN(parsedCountedQty) || parsedCountedQty < 0) {
      return res.status(400).json({
        success: false,
        message: 'Counted quantity must be a non-negative number.',
      });
    }

    // Fetch product and warehouse details
    const [targetProduct, targetWarehouse] = await Promise.all([
      Product.findById(product),
      Warehouse.findById(warehouse),
    ]);

    if (!targetProduct) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }
    if (!targetWarehouse) {
      return res.status(404).json({ success: false, message: 'Warehouse not found.' });
    }

    // Step 1: Read current recorded system quantity
    const existingStockLevel = await StockLevel.findOne({
      product: targetProduct._id,
      warehouse: targetWarehouse._id,
    });

    const systemQty = existingStockLevel ? existingStockLevel.quantity : 0;
    const diff = parsedCountedQty - systemQty;

    // Generate adjustment number if not provided
    let finalAdjustmentNumber = adjustmentNumber;
    if (!finalAdjustmentNumber) {
      const count = await Adjustment.countDocuments();
      const year = new Date().getFullYear();
      finalAdjustmentNumber = `ADJ-${year}-${String(count + 1).padStart(4, '0')}`;
    }

    // Step 2: Create Adjustment Record
    const adjustment = await Adjustment.create({
      adjustmentNumber: finalAdjustmentNumber,
      product: targetProduct._id,
      warehouse: targetWarehouse._id,
      systemQty,
      countedQty: parsedCountedQty,
      diff,
      reason: reason || '',
      status: 'applied',
    });

    // Step 3: Update StockLevel to match physical countedQty exactly
    const updatedStockLevel = await StockLevel.findOneAndUpdate(
      { product: targetProduct._id, warehouse: targetWarehouse._id },
      { quantity: parsedCountedQty },
      { upsert: true, new: true }
    );

    // Step 4: Write difference to StockLedger (if diff !== 0)
    if (diff !== 0) {
      await StockLedger.create({
        product: targetProduct._id,
        warehouse: targetWarehouse._id,
        qtyChange: diff,
        type: 'adjustment',
        refDocId: adjustment._id,
        refDocType: 'Adjustment',
        notes: reason
          ? `${reason} (Physical count: ${parsedCountedQty}, System was: ${systemQty})`
          : `Inventory physical count reconciliation: ${diff > 0 ? '+' : ''}${diff} ${targetProduct.unitOfMeasure}`,
        timestamp: new Date(),
      });
    }

    // Step 5: Emit live Socket.io event
    emitStockUpdate({
      type: 'stock_adjusted',
      adjustmentId: adjustment._id,
      adjustmentNumber: adjustment.adjustmentNumber,
      productId: targetProduct._id,
      productName: targetProduct.name,
      sku: targetProduct.sku,
      warehouseId: targetWarehouse._id,
      warehouseName: targetWarehouse.name,
      systemQty,
      countedQty: parsedCountedQty,
      diff,
      newBalance: updatedStockLevel.quantity,
      timestamp: new Date(),
    });

    const populated = await Adjustment.findById(adjustment._id)
      .populate('warehouse', 'name code location')
      .populate('product', 'name sku unitOfMeasure');

    res.status(201).json({
      success: true,
      message: `Adjustment applied: stock for ${targetProduct.name} at ${targetWarehouse.name} updated to ${parsedCountedQty}.`,
      adjustment: populated,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

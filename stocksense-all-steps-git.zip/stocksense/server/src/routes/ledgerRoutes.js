const express = require('express');
const router = express.Router();
const { StockLedger, Product, Warehouse } = require('../models');
const { authenticateToken } = require('../middleware/auth');

// GET all stock ledger movements with multi-dimensional filters
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const { productId, warehouseId, type, startDate, endDate, search, limit = 200 } = req.query;

    const filter = {};

    if (productId && productId !== 'all') {
      filter.product = productId;
    }

    if (warehouseId && warehouseId !== 'all') {
      filter.warehouse = warehouseId;
    }

    if (type && type !== 'all') {
      filter.type = type;
    }

    // Date range filter
    if (startDate || endDate) {
      filter.timestamp = {};
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        filter.timestamp.$gte = start;
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        filter.timestamp.$lte = end;
      }
    }

    // Product search or notes regex search
    let matchingProductIds = null;
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      const matchedProducts = await Product.find({
        $or: [{ name: searchRegex }, { sku: searchRegex }],
      }).select('_id');
      matchingProductIds = matchedProducts.map((p) => p._id);

      filter.$or = [
        { product: { $in: matchingProductIds } },
        { notes: searchRegex },
      ];
    }

    const movements = await StockLedger.find(filter)
      .populate('product', 'name sku unitOfMeasure reorderPoint')
      .populate('warehouse', 'name code location')
      .sort({ timestamp: -1, createdAt: -1 })
      .limit(Number(limit));

    // Calculate audit metrics
    let totalInflow = 0;
    let totalOutflow = 0;

    movements.forEach((m) => {
      if (m.qtyChange > 0) {
        totalInflow += m.qtyChange;
      } else {
        totalOutflow += Math.abs(m.qtyChange);
      }
    });

    res.json({
      success: true,
      count: movements.length,
      metrics: {
        totalMovements: movements.length,
        totalInflow,
        totalOutflow,
        netDelta: totalInflow - totalOutflow,
      },
      movements,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const { InternalTransfer, StockLevel, StockLedger, Product, Warehouse } = require('../models');
const { authenticateToken } = require('../middleware/auth');
const { emitStockUpdate } = require('../socket');

// GET all internal transfers with filters
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const { status, fromWarehouse, toWarehouse, search } = req.query;

    const filter = {};
    if (status && status !== 'all') {
      filter.status = status;
    }
    if (fromWarehouse && fromWarehouse !== 'all') {
      filter.fromWarehouse = fromWarehouse;
    }
    if (toWarehouse && toWarehouse !== 'all') {
      filter.toWarehouse = toWarehouse;
    }
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      filter.$or = [
        { transferNumber: searchRegex },
        { notes: searchRegex },
      ];
    }

    const transfers = await InternalTransfer.find(filter)
      .populate('fromWarehouse', 'name code location')
      .populate('toWarehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure reorderPoint')
      .sort({ createdAt: -1 });

    res.json({ success: true, transfers });
  } catch (err) {
    next(err);
  }
});

// GET single internal transfer with stock sufficiency info
router.get('/:id', authenticateToken, async (req, res, next) => {
  try {
    const transfer = await InternalTransfer.findById(req.params.id)
      .populate('fromWarehouse', 'name code location')
      .populate('toWarehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure reorderPoint');

    if (!transfer) {
      return res.status(404).json({ success: false, message: 'Internal transfer not found.' });
    }

    // Enrich lines with current available stock at fromWarehouse
    const linesWithStock = await Promise.all(
      transfer.lines.map(async (line) => {
        const prodId = line.product?._id || line.product;
        const fromWhId = transfer.fromWarehouse?._id || transfer.fromWarehouse;
        const stockLevel = await StockLevel.findOne({
          product: prodId,
          warehouse: fromWhId,
        });

        const currentQty = stockLevel ? stockLevel.quantity : 0;
        const isSufficient = currentQty >= line.qty;

        return {
          ...line.toObject(),
          currentFromStock: currentQty,
          isSufficient,
        };
      })
    );

    res.json({
      success: true,
      transfer: {
        ...transfer.toObject(),
        linesWithStock,
      },
    });
  } catch (err) {
    next(err);
  }
});

// POST create new internal transfer
router.post('/', authenticateToken, async (req, res, next) => {
  try {
    const { fromWarehouse, toWarehouse, lines, notes, status, transferNumber } = req.body;

    if (!fromWarehouse || !toWarehouse) {
      return res.status(400).json({
        success: false,
        message: 'Origin (From) and Destination (To) warehouses are required.',
      });
    }

    if (fromWarehouse.toString() === toWarehouse.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Origin and destination warehouses cannot be the same location.',
      });
    }

    if (!lines || !Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Transfer must contain at least one product line item.',
      });
    }

    // Validate line items
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!line.product || !line.qty || Number(line.qty) <= 0) {
        return res.status(400).json({
          success: false,
          message: `Line item #${i + 1} must have a valid product and positive quantity.`,
        });
      }
    }

    // Generate transfer number if not provided
    let finalTransferNumber = transferNumber;
    if (!finalTransferNumber) {
      const count = await InternalTransfer.countDocuments();
      const year = new Date().getFullYear();
      finalTransferNumber = `TRF-${year}-${String(count + 1).padStart(4, '0')}`;
    }

    const transfer = await InternalTransfer.create({
      transferNumber: finalTransferNumber,
      fromWarehouse,
      toWarehouse,
      lines: lines.map((item) => ({
        product: item.product,
        qty: Number(item.qty),
      })),
      notes: notes || '',
      status: status || 'draft',
    });

    const populated = await InternalTransfer.findById(transfer._id)
      .populate('fromWarehouse', 'name code location')
      .populate('toWarehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure');

    emitStockUpdate({ type: 'transfer_created', transferId: transfer._id });

    res.status(201).json({ success: true, transfer: populated });
  } catch (err) {
    next(err);
  }
});

// POST validate and execute internal transfer (atomic transfer between warehouses)
router.post('/:id/validate', authenticateToken, async (req, res, next) => {
  try {
    const transfer = await InternalTransfer.findById(req.params.id)
      .populate('fromWarehouse', 'name code location')
      .populate('toWarehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure reorderPoint');

    if (!transfer) {
      return res.status(404).json({ success: false, message: 'Internal transfer not found.' });
    }

    if (transfer.status === 'done') {
      return res.status(400).json({
        success: false,
        message: 'This internal transfer has already been validated and executed.',
      });
    }

    if (transfer.status === 'cancelled') {
      return res.status(400).json({
        success: false,
        message: 'Cancelled transfers cannot be validated.',
      });
    }

    if (transfer.fromWarehouse._id.toString() === transfer.toWarehouse._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Origin and destination warehouses cannot be identical.',
      });
    }

    // Step 1: Pre-validation stock check at origin warehouse
    const insufficientItems = [];

    for (const line of transfer.lines) {
      const prodId = line.product?._id || line.product;
      const stockLevel = await StockLevel.findOne({
        product: prodId,
        warehouse: transfer.fromWarehouse._id,
      });

      const availableQty = stockLevel ? stockLevel.quantity : 0;
      if (availableQty < line.qty) {
        insufficientItems.push({
          productName: line.product?.name || 'Unknown Product',
          sku: line.product?.sku || 'N/A',
          unitOfMeasure: line.product?.unitOfMeasure || 'pcs',
          required: line.qty,
          available: availableQty,
        });
      }
    }

    if (insufficientItems.length > 0) {
      const errorDetails = insufficientItems
        .map(
          (item) =>
            `"${item.productName}" (${item.sku}): Required ${item.required} ${item.unitOfMeasure}, Available in ${transfer.fromWarehouse.name}: ${item.available} ${item.unitOfMeasure}`
        )
        .join('; ');

      return res.status(400).json({
        success: false,
        message: `Cannot validate transfer: Insufficient stock at origin location ${transfer.fromWarehouse.name}. Details: ${errorDetails}. Negative stock is strictly prohibited.`,
        insufficientItems,
      });
    }

    // Step 2: Atomic Stock Balance Shift & Ledger Entries
    const stockUpdates = [];

    for (const line of transfer.lines) {
      const prodId = line.product?._id || line.product;

      // 1. Decrement at fromWarehouse
      const fromLevel = await StockLevel.findOneAndUpdate(
        { product: prodId, warehouse: transfer.fromWarehouse._id },
        { $inc: { quantity: -line.qty } },
        { new: true }
      );

      // 2. Increment at toWarehouse
      const toLevel = await StockLevel.findOneAndUpdate(
        { product: prodId, warehouse: transfer.toWarehouse._id },
        { $inc: { quantity: line.qty } },
        { upsert: true, new: true }
      );

      // 3. Log StockLedger transfer_out (negative change at origin)
      await StockLedger.create({
        product: prodId,
        warehouse: transfer.fromWarehouse._id,
        qtyChange: -line.qty,
        type: 'transfer_out',
        refDocId: transfer._id,
        refDocType: 'InternalTransfer',
        notes: `Transfer to ${transfer.toWarehouse.name} (${transfer.toWarehouse.code}) - ${transfer.transferNumber}`,
        timestamp: new Date(),
      });

      // 4. Log StockLedger transfer_in (positive change at destination)
      await StockLedger.create({
        product: prodId,
        warehouse: transfer.toWarehouse._id,
        qtyChange: line.qty,
        type: 'transfer_in',
        refDocId: transfer._id,
        refDocType: 'InternalTransfer',
        notes: `Transfer from ${transfer.fromWarehouse.name} (${transfer.fromWarehouse.code}) - ${transfer.transferNumber}`,
        timestamp: new Date(),
      });

      stockUpdates.push({
        product: line.product.name,
        sku: line.product.sku,
        qty: line.qty,
        fromWarehouseBalance: fromLevel.quantity,
        toWarehouseBalance: toLevel.quantity,
      });
    }

    // Step 3: Update Transfer Status to Done
    transfer.status = 'done';
    await transfer.save();

    // Step 4: Emit real-time Socket.io events
    emitStockUpdate({
      type: 'transfer_validated',
      transferId: transfer._id,
      transferNumber: transfer.transferNumber,
      fromWarehouseId: transfer.fromWarehouse._id,
      toWarehouseId: transfer.toWarehouse._id,
      stockUpdates,
      timestamp: new Date(),
    });

    res.json({
      success: true,
      message: `Internal transfer ${transfer.transferNumber} validated. Stock relocated successfully.`,
      transfer,
      stockUpdates,
    });
  } catch (err) {
    next(err);
  }
});

// PATCH update status (draft -> waiting -> ready)
router.patch('/:id/status', authenticateToken, async (req, res, next) => {
  try {
    const { status } = req.body;
    const allowed = ['draft', 'waiting', 'ready', 'cancelled'];

    if (!allowed.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Choose from: ${allowed.join(', ')}`,
      });
    }

    const transfer = await InternalTransfer.findById(req.params.id);
    if (!transfer) {
      return res.status(404).json({ success: false, message: 'Transfer not found.' });
    }

    if (transfer.status === 'done') {
      return res.status(400).json({
        success: false,
        message: 'Completed transfers cannot be modified.',
      });
    }

    transfer.status = status;
    await transfer.save();

    emitStockUpdate({ type: 'transfer_status_updated', transferId: transfer._id, status });

    res.json({ success: true, transfer });
  } catch (err) {
    next(err);
  }
});

// DELETE transfer (draft only)
router.delete('/:id', authenticateToken, async (req, res, next) => {
  try {
    const transfer = await InternalTransfer.findById(req.params.id);
    if (!transfer) {
      return res.status(404).json({ success: false, message: 'Transfer not found.' });
    }

    if (transfer.status === 'done') {
      return res.status(400).json({
        success: false,
        message: 'Completed transfers cannot be deleted.',
      });
    }

    await InternalTransfer.deleteOne({ _id: transfer._id });
    emitStockUpdate({ type: 'transfer_deleted', transferId: transfer._id });

    res.json({ success: true, message: 'Transfer deleted successfully.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

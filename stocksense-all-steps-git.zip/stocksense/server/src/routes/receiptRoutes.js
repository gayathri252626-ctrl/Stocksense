const express = require('express');
const router = express.Router();
const { Receipt, StockLevel, StockLedger, Product, Warehouse } = require('../models');
const { authenticateToken } = require('../middleware/auth');
const { emitStockUpdate } = require('../socket');

// GET all receipts with filters
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const { status, warehouseId, search } = req.query;

    const filter = {};
    if (status && status !== 'all') {
      filter.status = status;
    }
    if (warehouseId && warehouseId !== 'all') {
      filter.warehouse = warehouseId;
    }
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      filter.$or = [
        { receiptNumber: searchRegex },
        { supplier: searchRegex },
      ];
    }

    const receipts = await Receipt.find(filter)
      .populate('warehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure reorderPoint')
      .sort({ createdAt: -1 });

    res.json({ success: true, receipts });
  } catch (err) {
    next(err);
  }
});

// GET single receipt by ID
router.get('/:id', authenticateToken, async (req, res, next) => {
  try {
    const receipt = await Receipt.findById(req.params.id)
      .populate('warehouse', 'name code location')
      .populate('lines.product', 'name sku unitOfMeasure reorderPoint');

    if (!receipt) {
      return res.status(404).json({ success: false, message: 'Receipt not found.' });
    }

    res.json({ success: true, receipt });
  } catch (err) {
    next(err);
  }
});

// POST create new receipt
router.post('/', authenticateToken, async (req, res, next) => {
  try {
    const { supplier, warehouse, lines, notes, status, receiptNumber } = req.body;

    if (!supplier || !warehouse) {
      return res.status(400).json({
        success: false,
        message: 'Supplier name and target warehouse are required.',
      });
    }

    if (!Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Receipt must contain at least one product line item.',
      });
    }

    // Validate lines
    for (const line of lines) {
      if (!line.product || !line.qty || Number(line.qty) <= 0) {
        return res.status(400).json({
          success: false,
          message: 'Each line must have a valid product and a quantity greater than zero.',
        });
      }
    }

    // Auto-generate receipt number if omitted
    let finalReceiptNumber = receiptNumber?.trim();
    if (!finalReceiptNumber) {
      const count = await Receipt.countDocuments();
      finalReceiptNumber = `REC-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
    }

    const receipt = await Receipt.create({
      receiptNumber: finalReceiptNumber,
      supplier: supplier.trim(),
      warehouse,
      lines: lines.map((l) => ({
        product: l.product,
        qty: Number(l.qty),
      })),
      status: status || 'draft',
      notes: notes ? notes.trim() : '',
    });

    emitStockUpdate({ type: 'receipt_created', receiptId: receipt._id });

    const populated = await Receipt.findById(receipt._id)
      .populate('warehouse', 'name code')
      .populate('lines.product', 'name sku unitOfMeasure');

    res.status(201).json({ success: true, receipt: populated });
  } catch (err) {
    next(err);
  }
});

// PUT update receipt (only if not 'done' or 'cancelled')
router.put('/:id', authenticateToken, async (req, res, next) => {
  try {
    const receipt = await Receipt.findById(req.params.id);
    if (!receipt) {
      return res.status(404).json({ success: false, message: 'Receipt not found.' });
    }

    if (receipt.status === 'done') {
      return res.status(400).json({
        success: false,
        message: 'Cannot modify a receipt that has already been validated and marked done.',
      });
    }

    if (receipt.status === 'cancelled') {
      return res.status(400).json({
        success: false,
        message: 'Cannot modify a cancelled receipt.',
      });
    }

    const { supplier, warehouse, lines, notes, status } = req.body;

    if (supplier) receipt.supplier = supplier.trim();
    if (warehouse) receipt.warehouse = warehouse;
    if (notes !== undefined) receipt.notes = notes.trim();
    if (status) receipt.status = status;

    if (Array.isArray(lines) && lines.length > 0) {
      receipt.lines = lines.map((l) => ({
        product: l.product,
        qty: Number(l.qty),
      }));
    }

    await receipt.save();
    emitStockUpdate({ type: 'receipt_updated', receiptId: receipt._id });

    const populated = await Receipt.findById(receipt._id)
      .populate('warehouse', 'name code')
      .populate('lines.product', 'name sku unitOfMeasure');

    res.json({ success: true, receipt: populated });
  } catch (err) {
    next(err);
  }
});

// POST validate receipt -> Increases StockLevel, writes StockLedger, emits Socket.io
router.post('/:id/validate', authenticateToken, async (req, res, next) => {
  try {
    const receipt = await Receipt.findById(req.params.id)
      .populate('warehouse', 'name code')
      .populate('lines.product', 'name sku unitOfMeasure');

    if (!receipt) {
      return res.status(404).json({ success: false, message: 'Receipt not found.' });
    }

    if (receipt.status === 'done') {
      return res.status(400).json({
        success: false,
        message: `Receipt ${receipt.receiptNumber} has already been validated and processed.`,
      });
    }

    if (receipt.status === 'cancelled') {
      return res.status(400).json({
        success: false,
        message: `Cannot validate a cancelled receipt.`,
      });
    }

    // Process all lines: increase StockLevel and log to StockLedger
    const ledgerEntries = [];
    const stockUpdates = [];

    for (const line of receipt.lines) {
      const prodId = line.product._id || line.product;
      const qty = Number(line.qty);

      // Increase stock level atomically
      const updatedStock = await StockLevel.findOneAndUpdate(
        { product: prodId, warehouse: receipt.warehouse._id || receipt.warehouse },
        { $inc: { quantity: qty } },
        { upsert: true, new: true }
      );

      stockUpdates.push({
        product: line.product.name,
        sku: line.product.sku,
        addedQty: qty,
        newBalance: updatedStock.quantity,
      });

      // Prepare ledger audit log
      ledgerEntries.push({
        product: prodId,
        warehouse: receipt.warehouse._id || receipt.warehouse,
        qtyChange: qty, // Positive increase
        type: 'receipt',
        refDocId: receipt._id,
        refDocType: 'Receipt',
        notes: `Inbound receipt ${receipt.receiptNumber} from ${receipt.supplier}`,
        timestamp: new Date(),
      });
    }

    // Insert all StockLedger records
    await StockLedger.insertMany(ledgerEntries);

    // Mark receipt as 'done'
    receipt.status = 'done';
    await receipt.save();

    // Emit live Socket.io stock:update & stock:updated events
    emitStockUpdate({
      type: 'receipt_validated',
      receiptId: receipt._id,
      receiptNumber: receipt.receiptNumber,
      warehouseId: receipt.warehouse._id || receipt.warehouse,
      supplier: receipt.supplier,
      stockUpdates,
      timestamp: new Date(),
    });

    console.log(
      `[Receipts] Validated ${receipt.receiptNumber}: Stock increased for ${receipt.lines.length} product(s).`
    );

    res.json({
      success: true,
      message: `Receipt ${receipt.receiptNumber} validated successfully. Stock levels increased.`,
      receipt,
      stockUpdates,
    });
  } catch (err) {
    next(err);
  }
});

// POST cancel receipt
router.post('/:id/cancel', authenticateToken, async (req, res, next) => {
  try {
    const receipt = await Receipt.findById(req.params.id);
    if (!receipt) {
      return res.status(404).json({ success: false, message: 'Receipt not found.' });
    }

    if (receipt.status === 'done') {
      return res.status(400).json({
        success: false,
        message: 'Cannot cancel a receipt that has already been validated and added to stock.',
      });
    }

    receipt.status = 'cancelled';
    await receipt.save();

    emitStockUpdate({ type: 'receipt_cancelled', receiptId: receipt._id });

    res.json({
      success: true,
      message: `Receipt ${receipt.receiptNumber} has been cancelled.`,
      receipt,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const fs = require('fs');
const path = require('path');
const git = require('isomorphic-git');

const TARGET_DIR = 'C:\\Users\\Gokulram M\\Downloads\\stocksense';

async function initAllStepCommits() {
  console.log('--- Initializing Complete Git History for All Steps in StockSense ---');

  const dotGit = path.join(TARGET_DIR, '.git');
  if (fs.existsSync(dotGit)) {
    fs.rmSync(dotGit, { recursive: true, force: true });
    console.log('Cleared existing .git directory in stocksense');
  }

  // 1. Initialize Git Repo
  await git.init({ fs, dir: TARGET_DIR, defaultBranch: 'main' });
  console.log('✓ Initialized empty Git repository in:', TARGET_DIR);

  const author = {
    name: 'StockSense Team',
    email: 'dev@stocksense.com',
  };

  const now = Math.floor(Date.now() / 1000);

  // 15 Commits across all 4 Steps
  const commits = [
    // -------------------------------------------------------------
    // STEP 1: Foundation, Data Models & Authentication
    // -------------------------------------------------------------
    {
      step: 'Step 1',
      title: 'chore: initialize project scaffolding and workspace configuration',
      message: 'chore: initialize project scaffolding and workspace configuration\n\n- Add root package.json and workspace scripts\n- Configure .gitignore for Node, Vite, and environment files\n- Establish monorepo structure for server and client',
      files: [
        '.gitignore',
        'package.json',
      ],
      timeOffset: 15 * 180,
    },
    {
      step: 'Step 1',
      title: 'feat(server): setup Express server, MongoDB connection, and Mongoose schemas',
      message: 'feat(server): setup Express server, MongoDB connection, and Mongoose schemas\n\n- Configure MongoDB connection with automatic in-memory fallback\n- Define 11 core Mongoose schemas: User, OtpToken, Warehouse, Category, Product, StockLevel, StockLedger, Receipt, DeliveryOrder, InternalTransfer, Adjustment\n- Create database seed script with manager and staff demo accounts',
      files: [
        'server/package.json',
        'server/.env.example',
        'server/src/config/db.js',
        'server/src/models/User.js',
        'server/src/models/OtpToken.js',
        'server/src/models/Warehouse.js',
        'server/src/models/Category.js',
        'server/src/models/Product.js',
        'server/src/models/StockLevel.js',
        'server/src/models/StockLedger.js',
        'server/src/models/Receipt.js',
        'server/src/models/DeliveryOrder.js',
        'server/src/models/InternalTransfer.js',
        'server/src/models/Adjustment.js',
        'server/src/models/index.js',
        'server/src/seed.js',
      ],
      timeOffset: 14 * 180,
    },
    {
      step: 'Step 1',
      title: 'feat(auth): implement JWT authentication, role guards, and OTP password recovery',
      message: 'feat(auth): implement JWT authentication, role guards, and OTP password recovery\n\n- Implement signup, login, and token verification with bcrypt & JWT\n- Build 6-digit OTP password reset workflow with 10-minute expiry\n- Add role-based access control middleware (manager vs staff)\n- Setup Socket.io real-time server and auth verification test script',
      files: [
        'server/src/controllers/authController.js',
        'server/src/routes/authRoutes.js',
        'server/src/middleware/auth.js',
        'server/src/middleware/errorHandler.js',
        'server/src/socket.js',
        'server/src/server.js',
        'server/src/testAuth.js',
      ],
      timeOffset: 13 * 180,
    },
    {
      step: 'Step 1',
      title: 'feat(client): configure Vite, TailwindCSS design system, and core app layout',
      message: 'feat(client): configure Vite, TailwindCSS design system, and core app layout\n\n- Configure Vite 5 build tool, TailwindCSS, PostCSS, and Autoprefixer\n- Build dark/light theme foundation, typography, and glassmorphic styles\n- Create responsive Layout with collapsible Sidebar and modern Navbar\n- Configure Axios HTTP interceptor and Auth/Socket React contexts',
      files: [
        'client/package.json',
        'client/vite.config.js',
        'client/tailwind.config.js',
        'client/postcss.config.js',
        'client/index.html',
        'client/.env.example',
        'client/src/index.css',
        'client/src/api/axios.js',
        'client/src/context/AuthContext.jsx',
        'client/src/context/SocketContext.jsx',
        'client/src/components/layout/Navbar.jsx',
        'client/src/components/layout/Sidebar.jsx',
        'client/src/components/layout/Layout.jsx',
      ],
      timeOffset: 12 * 180,
    },
    {
      step: 'Step 1',
      title: 'feat(client): implement authentication pages, OTP recovery flow, and protected routing',
      message: 'feat(client): implement authentication pages, OTP recovery flow, and protected routing\n\n- Build Login page with demo credentials quick-fill buttons\n- Build Signup page with role selection (Manager / Staff)\n- Build Forgot Password & Reset Password OTP verification pages\n- Implement protected route guards and core navigation pages\n- Wire React Router v6 in App.jsx and mount in main.jsx',
      files: [
        'client/src/pages/auth/Login.jsx',
        'client/src/pages/auth/Signup.jsx',
        'client/src/pages/auth/ForgotPassword.jsx',
        'client/src/pages/auth/ResetPassword.jsx',
        'client/src/pages/profile/ProfilePage.jsx',
        'client/src/App.jsx',
        'client/src/main.jsx',
      ],
      timeOffset: 11 * 180,
    },

    // -------------------------------------------------------------
    // STEP 2: Products, Warehouses & Dashboard KPIs
    // -------------------------------------------------------------
    {
      step: 'Step 2',
      title: 'feat(products): build master product catalog with SKU search and location breakdown',
      message: 'feat(products): build master product catalog with SKU search and location breakdown\n\n- Create product management CRUD endpoints with warehouse stock breakdown\n- Build ProductsPage UI with live search, category filtering, and stock modal\n- Implement reorder point indicators and low-stock badges',
      files: [
        'server/src/routes/productRoutes.js',
        'client/src/pages/products/ProductsPage.jsx',
      ],
      timeOffset: 10 * 180,
    },
    {
      step: 'Step 2',
      title: 'feat(settings): implement warehouse and category management CRUD',
      message: 'feat(settings): implement warehouse and category management CRUD\n\n- Add warehouse and category management API endpoints with stock counters\n- Implement WarehouseSettingsPage with tabs for facilities and categories\n- Enable creation, editing, and code management for multi-warehouse tracking',
      files: [
        'server/src/routes/warehouseRoutes.js',
        'server/src/routes/categoryRoutes.js',
        'client/src/pages/settings/WarehouseSettingsPage.jsx',
      ],
      timeOffset: 9 * 180,
    },
    {
      step: 'Step 2',
      title: 'feat(dashboard): build real-time KPIs, dynamic multi-filters, and low-stock alert banner',
      message: 'feat(dashboard): build real-time KPIs, dynamic multi-filters, and low-stock alert banner\n\n- Build dashboard controller aggregating 5 core KPIs and document filters\n- Create Dashboard UI with dynamic filter bar (type, status, warehouse, category)\n- Add reactive low-stock alert banner with direct restock actions\n- Wire live updates via SocketContext',
      files: [
        'server/src/controllers/dashboardController.js',
        'server/src/routes/dashboardRoutes.js',
        'client/src/pages/dashboard/Dashboard.jsx',
      ],
      timeOffset: 8 * 180,
    },

    // -------------------------------------------------------------
    // STEP 3: Receipts (Incoming), Delivery Orders (Outgoing) & Engine
    // -------------------------------------------------------------
    {
      step: 'Step 3',
      title: 'feat(receipts): implement incoming stock receipts with atomic validation',
      message: 'feat(receipts): implement incoming stock receipts with atomic validation\n\n- Add Receipt API with supplier, warehouse, and multi-line item tracking\n- Build atomic validation: increments StockLevel, writes StockLedger record, marks done\n- Implement ReceiptsPage UI with status filters, search, modal, and drawer\n- Broadcast Socket.io stock:update events on validation',
      files: [
        'server/src/routes/receiptRoutes.js',
        'client/src/pages/receipts/ReceiptsPage.jsx',
      ],
      timeOffset: 7 * 180,
    },
    {
      step: 'Step 3',
      title: 'feat(deliveries): implement outgoing delivery orders with negative stock prevention',
      message: 'feat(deliveries): implement outgoing delivery orders with negative stock prevention\n\n- Add DeliveryOrder API with picking and packing status lifecycle\n- Pre-check stock sufficiency and strictly reject negative stock with HTTP 400\n- Decrement StockLevel, write negative StockLedger record, and emit socket updates\n- Implement DeliveryOrdersPage UI with per-line stock sufficiency indicator badges',
      files: [
        'server/src/routes/deliveryRoutes.js',
        'client/src/pages/deliveries/DeliveryOrdersPage.jsx',
      ],
      timeOffset: 6 * 180,
    },
    {
      step: 'Step 3',
      title: 'test(step3): add automated test suite for receipt validation and negative stock prevention',
      message: 'test(step3): add automated test suite for receipt validation and negative stock prevention\n\n- Create testStep3.js to execute complete verification loop\n- Test receipt validation (+50), excessive delivery rejection (400), and valid dispatch (-20)\n- Confirm live Socket.io broadcast delivery',
      files: [
        'server/src/testStep3.js',
      ],
      timeOffset: 5 * 180,
    },

    // -------------------------------------------------------------
    // STEP 4: Internal Transfers, Adjustments & Move History Ledger
    // -------------------------------------------------------------
    {
      step: 'Step 4',
      title: 'feat(transfers): implement multi-location internal transfers with atomic balance relocation',
      message: 'feat(transfers): implement multi-location internal transfers with atomic balance relocation\n\n- Add InternalTransfer API with origin stock validation and negative stock block\n- Shift StockLevel atomically from origin to destination warehouse in one operation\n- Log simultaneous transfer_out and transfer_in audit records to StockLedger\n- Build TransfersPage UI with route visual cards, live stock hints, and validation action',
      files: [
        'server/src/routes/transferRoutes.js',
        'client/src/pages/transfers/TransfersPage.jsx',
      ],
      timeOffset: 4 * 180,
    },
    {
      step: 'Step 4',
      title: 'feat(adjustments): implement physical count inventory reconciliation with automatic ledger sync',
      message: 'feat(adjustments): implement physical count inventory reconciliation with automatic ledger sync\n\n- Add Stock Adjustments API fetching live recorded stock and applying verified counts\n- Synchronize StockLevel to physical count and log discrepancy delta to StockLedger\n- Build AdjustmentsPage UI with live system stock preview, real-time diff badge, and reasons',
      files: [
        'server/src/routes/adjustmentRoutes.js',
        'client/src/pages/adjustments/AdjustmentsPage.jsx',
      ],
      timeOffset: 3 * 180,
    },
    {
      step: 'Step 4',
      title: 'feat(ledger): implement Move History audit trail with smart filters and CSV export',
      message: 'feat(ledger): implement Move History audit trail with smart filters and CSV export\n\n- Build StockLedger query API with multi-dimensional filters (product, warehouse, type, date range)\n- Calculate audit metrics: total inflow, total outflow, and net inventory delta\n- Build MoveHistoryPage UI with movement type badges, Socket.io auto-refresh, and CSV export',
      files: [
        'server/src/routes/ledgerRoutes.js',
        'client/src/pages/move-history/MoveHistoryPage.jsx',
      ],
      timeOffset: 2 * 180,
    },
    {
      step: 'Step 4',
      title: 'docs: full operational lifecycle test and comprehensive real-time architecture guide',
      message: 'docs: full operational lifecycle test and comprehensive real-time architecture guide\n\n- Add testStep4.js verifying complete 4-stage operational loop: receipt, transfer, delivery, adjustment\n- Update README with in-depth Socket.io event architecture and payload contracts\n- Add commit guides and verify zero-defect end-to-end operation',
      files: [
        'server/src/testStep4.js',
        'README.md',
        'GIT-COMMITS-STEP1.md',
        'GIT-COMMITS-STEP4.md',
      ],
      timeOffset: 60,
    },
  ];

  // Execute all commits in chronological order
  for (let i = 0; i < commits.length; i++) {
    const c = commits[i];
    console.log(`\n[Commit ${i + 1}/${commits.length}] (${c.step}) ${c.title}`);

    for (const rel of c.files) {
      const fullPath = path.join(TARGET_DIR, rel.replace(/\//g, path.sep));
      if (fs.existsSync(fullPath)) {
        await git.add({ fs, dir: TARGET_DIR, filepath: rel.replace(/\\/g, '/') });
      } else {
        console.warn(`  Notice: File skipped (not present yet): ${rel}`);
      }
    }

    const commitTimestamp = now - c.timeOffset;
    const sha = await git.commit({
      fs,
      dir: TARGET_DIR,
      message: c.message,
      author: {
        ...author,
        timestamp: commitTimestamp,
      },
      committer: {
        ...author,
        timestamp: commitTimestamp,
      },
    });

    console.log(`  ✓ Commit created: ${sha.substring(0, 7)}`);
  }

  // Print complete commit history
  const log = await git.log({ fs, dir: TARGET_DIR, depth: 25 });
  console.log('\n=============================================================');
  console.log('📜 COMPLETE GIT COMMIT HISTORY FOR STOCKSENSE (ALL STEPS)');
  console.log('=============================================================');
  log.reverse().forEach((entry, idx) => {
    const firstLine = entry.commit.message.split('\n')[0];
    const timeStr = new Date(entry.commit.author.timestamp * 1000).toLocaleTimeString();
    console.log(`[${String(idx + 1).padStart(2, '0')}] ${entry.oid.substring(0, 7)} | ${firstLine} (${timeStr})`);
  });

  console.log('\n🎉 Successfully initialized all 15 Git commits across all 4 steps in stocksense!');
}

initAllStepCommits().catch((err) => {
  console.error('Failed to initialize commits:', err);
  process.exit(1);
});

const { Server } = require('socket.io');

let io = null;

const initSocket = (httpServer) => {
  io = new Server(httpServer, {
    cors: {
      origin: process.env.CLIENT_URL || '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      credentials: true,
    },
  });

  io.on('connection', (socket) => {
    console.log(`[Socket] Client connected: ${socket.id}`);

    // Join warehouse room or user room if requested
    socket.on('join:warehouse', (warehouseId) => {
      socket.join(`warehouse:${warehouseId}`);
      console.log(`[Socket] ${socket.id} joined room warehouse:${warehouseId}`);
    });

    socket.on('leave:warehouse', (warehouseId) => {
      socket.leave(`warehouse:${warehouseId}`);
    });

    socket.on('disconnect', () => {
      console.log(`[Socket] Client disconnected: ${socket.id}`);
    });
  });

  console.log('[Socket] Socket.io server initialized and listening for connections');
  return io;
};

const getIO = () => {
  if (!io) {
    throw new Error('Socket.io has not been initialized. Please call initSocket first.');
  }
  return io;
};

const emitStockUpdate = (data) => {
  if (io) {
    io.emit('stock:updated', data);
    io.emit('stock:update', data);
  }
};

const emitNotification = (data) => {
  if (io) {
    io.emit('notification:new', data);
  }
};

module.exports = {
  initSocket,
  getIO,
  emitStockUpdate,
  emitNotification,
};

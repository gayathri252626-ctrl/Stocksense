const fs = require('fs');
const path = require('path');

const base = 'C:\\Users\\Gokulram M\\Downloads\\stocksense-step3';

// 1. Remove Step 4 files
const filesToRemove = [
  path.join(base, 'server', 'src', 'routes', 'transferRoutes.js'),
  path.join(base, 'server', 'src', 'routes', 'adjustmentRoutes.js'),
  path.join(base, 'server', 'src', 'routes', 'ledgerRoutes.js'),
  path.join(base, 'server', 'src', 'testStep4.js'),
  path.join(base, 'GIT-COMMITS-STEP4.md'),
];

for (const f of filesToRemove) {
  if (fs.existsSync(f)) {
    fs.unlinkSync(f);
    console.log('Removed Step 4 file:', path.basename(f));
  }
}

// 2. Restore server/src/server.js to Step 3 state
const serverStep3 = `require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const { connectDB } = require('./config/db');
const { initSocket } = require('./socket');
const errorHandler = require('./middleware/errorHandler');

// Route imports
const authRoutes = require('./routes/authRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const warehouseRoutes = require('./routes/warehouseRoutes');
const productRoutes = require('./routes/productRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const receiptRoutes = require('./routes/receiptRoutes');
const deliveryRoutes = require('./routes/deliveryRoutes');

const app = express();
const server = http.createServer(app);

// Initialize Socket.io
initSocket(server);

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || '*',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    system: 'StockSense IMS',
    timestamp: new Date().toISOString(),
  });
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/warehouses', warehouseRoutes);
app.use('/api/products', productRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/receipts', receiptRoutes);
app.use('/api/deliveries', deliveryRoutes);

// Error Handling Middleware
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
const seedData = require('./seed');
const { User } = require('./models');

const startServer = async () => {
  try {
    await connectDB();

    // Auto-seed if database is fresh
    const userCount = await User.countDocuments();
    if (userCount === 0) {
      console.log('[Startup] Empty database detected. Auto-seeding demo data...');
      await seedData();
    }

    server.listen(PORT, () => {
      console.log(\`\\n======================================================\`);
      console.log(\`  🚀 StockSense Backend Server running on port \${PORT}\`);
      console.log(\`  📡 Socket.io ready for real-time events\`);
      console.log(\`  🌐 Health check: http://localhost:\${PORT}/api/health\`);
      console.log(\`======================================================\\n\`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

if (require.main === module) {
  startServer();
}

module.exports = { app, server, startServer };
`;
fs.writeFileSync(path.join(base, 'server', 'src', 'server.js'), serverStep3, 'utf8');
console.log('Restored server.js to Step 3 state');

// 3. Restore TransfersPage.jsx to Step 3 state
const transfersStep3 = `import React from 'react';
import { ArrowLeftRight, Plus, Building2, Layers } from 'lucide-react';

export default function TransfersPage() {
  const demoTransfers = [
    {
      id: 'TRF-2026-001',
      from: 'Main Central Warehouse (MW-01)',
      to: 'Production Assembly Floor (PF-01)',
      items: 'Steel Rods (25 kg)',
      status: 'waiting',
      date: '2026-09-26',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Internal Transfers
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
              Inter-facility
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Move stock between internal locations (e.g. Main Store &rarr; Production Rack). Total stock remains unchanged while location balances update.
          </p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white shadow-glow transition-all">
          <Plus className="w-4 h-4" />
          <span>New Transfer</span>
        </button>
      </div>

      {/* Info Card */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 bg-gradient-to-r from-cyan-950/30 via-slate-900 to-slate-900 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-200">
              Internal Stock Balancing
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Transfers log simultaneous transfer_out and transfer_in entries to the Stock Ledger.
            </p>
          </div>
        </div>
      </div>

      {/* Transfers Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-3 px-4 font-semibold">Transfer Ref</th>
                <th className="py-3 px-4 font-semibold">Source Location</th>
                <th className="py-3 px-4 font-semibold">Destination Location</th>
                <th className="py-3 px-4 font-semibold">Transfer Items</th>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {demoTransfers.map((t) => (
                <tr key={t.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-cyan-400">
                    {t.id}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {t.from}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {t.to}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-200">
                    {t.items}
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-mono">
                    {t.date}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
`;
fs.writeFileSync(path.join(base, 'client', 'src', 'pages', 'transfers', 'TransfersPage.jsx'), transfersStep3, 'utf8');
console.log('Restored TransfersPage.jsx to Step 3 state');

// 4. Restore AdjustmentsPage.jsx to Step 3 state
const adjustmentsStep3 = `import React from 'react';
import { SlidersHorizontal, Plus, Scale, AlertCircle } from 'lucide-react';

export default function AdjustmentsPage() {
  const demoAdjustments = [
    {
      id: 'ADJ-2026-001',
      product: 'Steel Rods (10mm x 3m)',
      warehouse: 'Main Central Warehouse (MW-01)',
      systemQty: 123,
      countedQty: 120,
      diff: -3,
      reason: 'Damaged during material handling',
      status: 'applied',
    },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Stock Adjustments
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
              Audit & Count
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Reconcile physical inventory counts against system records. Automatically calculates diffs and records ledger adjustments.
          </p>
        </div>

        <button className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-amber-600 hover:bg-amber-500 text-white shadow-glow transition-all">
          <Plus className="w-4 h-4" />
          <span>New Adjustment</span>
        </button>
      </div>

      {/* Info card */}
      <div className="glass-panel p-4 rounded-2xl border border-slate-800 bg-gradient-to-r from-amber-950/30 via-slate-900 to-slate-900 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-200">
              Inventory Discrepancy Reconciliation
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Diff Formula: Counted Qty &minus; System Recorded Qty. When applied, StockLevel is synchronized immediately.
            </p>
          </div>
        </div>
      </div>

      {/* Adjustments Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
              <tr>
                <th className="py-3 px-4 font-semibold">Adjustment #</th>
                <th className="py-3 px-4 font-semibold">Product</th>
                <th className="py-3 px-4 font-semibold">Location</th>
                <th className="py-3 px-4 font-semibold text-right">System Qty</th>
                <th className="py-3 px-4 font-semibold text-right">Counted Qty</th>
                <th className="py-3 px-4 font-semibold text-right">Difference</th>
                <th className="py-3 px-4 font-semibold">Reason</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {demoAdjustments.map((a) => (
                <tr key={a.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-amber-400">
                    {a.id}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-200">
                    {a.product}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    {a.warehouse}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-slate-400">
                    {a.systemQty}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-semibold text-slate-200">
                    {a.countedQty}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-rose-400">
                    {a.diff}
                  </td>
                  <td className="py-3 px-4 text-slate-400">
                    {a.reason}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
`;
fs.writeFileSync(path.join(base, 'client', 'src', 'pages', 'adjustments', 'AdjustmentsPage.jsx'), adjustmentsStep3, 'utf8');
console.log('Restored AdjustmentsPage.jsx to Step 3 state');

// 5. Restore MoveHistoryPage.jsx to Step 3 state
const moveHistoryStep3 = `import React, { useState, useEffect } from 'react';
import { History, Filter, Download, ArrowDownLeft, ArrowUpRight, ArrowLeftRight, SlidersHorizontal } from 'lucide-react';
import api from '../../api/axios';

export default function MoveHistoryPage() {
  const [movements, setMovements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovements = async () => {
      try {
        setLoading(true);
        const res = await api.get('/dashboard/stats');
        setMovements(res.data.recentMovements || []);
      } catch (err) {
        console.error('Failed to fetch history:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchMovements();
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-white">
              Move History & Ledger
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 font-semibold border border-slate-700/60">
              Audit Trail
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Comprehensive immutable audit log of every stock movement: receipts, deliveries, internal transfers, and adjustments.
          </p>
        </div>

        <button className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700 transition-all">
          <Download className="w-3.5 h-3.5" />
          <span>Export Ledger CSV</span>
        </button>
      </div>

      {/* Movements Table */}
      <div className="glass-panel rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400">
            <div className="inline-block w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading ledger movements...</p>
          </div>
        ) : movements.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            No stock movements found in current ledger.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-semibold">Timestamp</th>
                  <th className="py-3 px-4 font-semibold">Product SKU & Name</th>
                  <th className="py-3 px-4 font-semibold">Warehouse Location</th>
                  <th className="py-3 px-4 font-semibold">Movement Type</th>
                  <th className="py-3 px-4 font-semibold text-right">Qty Delta</th>
                  <th className="py-3 px-4 font-semibold">Audit Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {movements.map((m) => {
                  const isPositive = m.qtyChange > 0;
                  return (
                    <tr key={m._id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                        {new Date(m.timestamp).toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-200">
                          {m.product?.name || 'Product'}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400">
                          {m.product?.sku}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-300">
                        {m.warehouse?.code} - {m.warehouse?.name}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium capitalize bg-slate-800 text-slate-300 border border-slate-700/60">
                          {m.type?.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span
                          className={\`font-mono font-bold \${
                            isPositive ? 'text-emerald-400' : 'text-rose-400'
                          }\`}
                        >
                          {isPositive ? \`+\${m.qtyChange}\` : m.qtyChange}{' '}
                          <span className="text-[10px] font-normal text-slate-400">
                            {m.product?.unitOfMeasure}
                          </span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        {m.notes || '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
`;
fs.writeFileSync(path.join(base, 'client', 'src', 'pages', 'move-history', 'MoveHistoryPage.jsx'), moveHistoryStep3, 'utf8');
console.log('Restored MoveHistoryPage.jsx to Step 3 state');

// 6. Create GIT-COMMITS-STEP3.md
const step3Guide = `# StockSense — Step 3 Git Commits Guide

This document outlines the recommended conventional Git commits for **Step 3: Receipts (Incoming Stock), Delivery Orders (Outgoing Stock) & Real-Time Stock Engine**.

---

### Commit 1: Receipts Module (Incoming Stock)
- **Commit Message**:
  \`\`\`text
  feat(receipts): implement incoming stock receipts and atomic validation

  - Add Receipt API with supplier, warehouse, and multi-line item tracking
  - Build atomic validation endpoint: increases StockLevel, writes StockLedger record, and sets status to 'done'
  - Implement ReceiptsPage UI with status filters, search, modal creation, and drawer view
  - Emit Socket.io 'stock:update' and 'stock:updated' on validation
  \`\`\`
- **Files**:
  - \`server/src/routes/receiptRoutes.js\`
  - \`client/src/pages/receipts/ReceiptsPage.jsx\`

---

### Commit 2: Delivery Orders & Negative Stock Prevention
- **Commit Message**:
  \`\`\`text
  feat(deliveries): implement outgoing delivery orders with negative stock prevention

  - Add DeliveryOrder API with customer, warehouse, and picking/packing lifecycle
  - Pre-validate stock availability and strictly reject negative stock with HTTP 400
  - Decrement StockLevel, write negative StockLedger record, and emit live socket updates on validation
  - Implement DeliveryOrdersPage UI with per-line stock sufficiency indicator badges
  \`\`\`
- **Files**:
  - \`server/src/routes/deliveryRoutes.js\`
  - \`client/src/pages/deliveries/DeliveryOrdersPage.jsx\`

---

### Commit 3: Server Integration & Step 3 Full Loop Verification
- **Commit Message**:
  \`\`\`text
  chore(step3): mount receipt and delivery routes, add full loop integration test

  - Mount /api/receipts and /api/deliveries in server.js
  - Update socket.js to broadcast dual event contracts ('stock:update' and 'stock:updated')
  - Add testStep3.js verifying receipt validation (+50), negative stock block (670 units), and delivery deduction (-20)
  \`\`\`
- **Files**:
  - \`server/src/server.js\`
  - \`server/src/socket.js\`
  - \`server/src/testStep3.js\`
`;
fs.writeFileSync(path.join(base, 'GIT-COMMITS-STEP3.md'), step3Guide, 'utf8');
console.log('Created GIT-COMMITS-STEP3.md in stocksense-step3');

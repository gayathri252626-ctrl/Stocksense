const fs = require('fs');
const path = require('path');
const readline = require('readline');
const git = require('isomorphic-git');

const TRANSCRIPT_PATH = 'C:\\Users\\Gokulram M\\.gemini\\antigravity-ide\\brain\\b4e52327-c098-44e5-81e4-49feca515876\\.system_generated\\logs\\transcript_full.jsonl';
const TARGET_DIR = 'C:\\Users\\Gokulram M\\Downloads\\stocksense-step1';

async function buildStep1() {
  console.log('--- Building Step 1 Git Repository ---');

  if (fs.existsSync(TARGET_DIR)) {
    fs.rmSync(TARGET_DIR, { recursive: true, force: true });
  }
  fs.mkdirSync(TARGET_DIR, { recursive: true });

  const fileMap = new Map(); // relativePath -> content

  const fileStream = fs.createReadStream(TRANSCRIPT_PATH);
  const rl = readline.createInterface({ input: fileStream, crlfDelay: Infinity });

  for await (const line of rl) {
    if (!line.trim()) continue;
    try {
      const step = JSON.parse(line);
      if (step.step_index > 240) continue; // Only step 1
      if (!step.tool_calls) continue;

      for (const call of step.tool_calls) {
        if (call.name === 'write_to_file' && call.args && call.args.TargetFile) {
          let target = call.args.TargetFile.replace(/^"|"$/g, '');
          const normalized = path.normalize(target);
          if (normalized.toLowerCase().includes('stocksense')) {
            const rel = path.relative('C:\\Users\\Gokulram M\\Downloads\\stocksense', normalized);
            fileMap.set(rel, call.args.CodeContent);
          }
        } else if (call.name === 'replace_file_content' && call.args && call.args.TargetFile) {
          let target = call.args.TargetFile.replace(/^"|"$/g, '');
          const normalized = path.normalize(target);
          if (normalized.toLowerCase().includes('stocksense')) {
            const rel = path.relative('C:\\Users\\Gokulram M\\Downloads\\stocksense', normalized);
            let current = fileMap.get(rel);
            if (current && call.args.TargetContent && call.args.ReplacementContent !== undefined) {
              current = current.replace(call.args.TargetContent, call.args.ReplacementContent);
              fileMap.set(rel, current);
            }
          }
        }
      }
    } catch (err) {
      // ignore parse err
    }
  }

  // Also include .gitignore if not extracted
  if (!fileMap.has('.gitignore')) {
    const origGitignore = fs.readFileSync('C:\\Users\\Gokulram M\\Downloads\\stocksense\\.gitignore', 'utf8');
    fileMap.set('.gitignore', origGitignore);
  }

  console.log(`Extracted ${fileMap.size} files for Step 1.`);

  // Write all extracted files to TARGET_DIR
  for (const [relPath, content] of fileMap.entries()) {
    const fullPath = path.join(TARGET_DIR, relPath);
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.writeFileSync(fullPath, content, 'utf8');
  }

  // Initialize Git Repository with isomorphic-git
  await git.init({ fs, dir: TARGET_DIR, defaultBranch: 'main' });
  console.log('✓ Initialized Git repository in:', TARGET_DIR);

  const author = {
    name: 'StockSense Team',
    email: 'dev@stocksense.com',
  };

  // Define 5 Atomic Commits
  const commitGroups = [
    {
      message: 'chore: initialize project scaffolding and workspace configuration\n\n- Add root package.json and workspace scripts\n- Configure .gitignore for Node, Vite, and environment files\n- Add comprehensive architecture and setup README',
      files: [
        '.gitignore',
        'package.json',
        'README.md',
      ],
    },
    {
      message: 'feat(server): setup Express server, MongoDB connection, and Mongoose schemas\n\n- Configure MongoDB connection with automatic in-memory fallback\n- Define 11 core Mongoose schemas: User, OtpToken, Warehouse, Category, Product, StockLevel, StockLedger, Receipt, DeliveryOrder, InternalTransfer, Adjustment\n- Create database seed script with manager and staff demo accounts',
      files: [
        'server/package.json',
        'server/.env.example',
        'server/.env',
        'server/src/config/db.js',
        'server/src/models/User.js',
        'server/src/models/OtpToken.js',
        'server/src/models/Warehouse.js',
        'server/src/models/Category.js',
        'server/src/models/Product.js',
        'server/src/models/StockLevel.js',
        'server/src/models/StockLedger.js',
        'server/src/models/Receipt.js',
        'server/src/models/DeliveryOrder.js',
        'server/src/models/InternalTransfer.js',
        'server/src/models/Adjustment.js',
        'server/src/models/index.js',
        'server/src/seed.js',
      ],
    },
    {
      message: 'feat(auth): implement JWT authentication, role guards, and OTP password recovery\n\n- Implement signup, login, and token verification with bcrypt & JWT\n- Build 6-digit OTP password reset workflow with 10-minute expiry\n- Add role-based access control middleware (manager vs staff)\n- Setup Socket.io real-time server and auth verification test script',
      files: [
        'server/src/controllers/authController.js',
        'server/src/controllers/dashboardController.js',
        'server/src/routes/authRoutes.js',
        'server/src/routes/dashboardRoutes.js',
        'server/src/routes/warehouseRoutes.js',
        'server/src/routes/productRoutes.js',
        'server/src/middleware/auth.js',
        'server/src/middleware/errorHandler.js',
        'server/src/socket.js',
        'server/src/server.js',
        'server/src/testAuth.js',
      ],
    },
    {
      message: 'feat(client): configure Vite, TailwindCSS design system, and core app layout\n\n- Configure Vite 5 build tool, TailwindCSS, PostCSS, and Autoprefixer\n- Build dark/light theme foundation, typography, and glassmorphic styles\n- Create responsive Layout with collapsible Sidebar and modern Navbar\n- Configure Axios HTTP interceptor and Auth/Socket React contexts',
      files: [
        'client/package.json',
        'client/vite.config.js',
        'client/tailwind.config.js',
        'client/postcss.config.js',
        'client/index.html',
        'client/.env.example',
        'client/.env',
        'client/src/index.css',
        'client/src/api/axios.js',
        'client/src/context/AuthContext.jsx',
        'client/src/context/SocketContext.jsx',
        'client/src/components/layout/Navbar.jsx',
        'client/src/components/layout/Sidebar.jsx',
        'client/src/components/layout/Layout.jsx',
      ],
    },
    {
      message: 'feat(client): implement authentication pages, OTP recovery flow, and protected routing\n\n- Build Login page with demo credentials quick-fill buttons\n- Build Signup page with role selection (Manager / Staff)\n- Build Forgot Password & Reset Password OTP verification pages\n- Implement protected route guards and core navigation pages\n- Wire React Router v6 in App.jsx and mount in main.jsx',
      files: [
        'client/src/pages/auth/Login.jsx',
        'client/src/pages/auth/Signup.jsx',
        'client/src/pages/auth/ForgotPassword.jsx',
        'client/src/pages/auth/ResetPassword.jsx',
        'client/src/pages/dashboard/Dashboard.jsx',
        'client/src/pages/products/ProductsPage.jsx',
        'client/src/pages/receipts/ReceiptsPage.jsx',
        'client/src/pages/deliveries/DeliveryOrdersPage.jsx',
        'client/src/pages/transfers/TransfersPage.jsx',
        'client/src/pages/adjustments/AdjustmentsPage.jsx',
        'client/src/pages/move-history/MoveHistoryPage.jsx',
        'client/src/pages/settings/WarehouseSettingsPage.jsx',
        'client/src/pages/profile/ProfilePage.jsx',
        'client/src/App.jsx',
        'client/src/main.jsx',
      ],
    },
  ];

  for (let i = 0; i < commitGroups.length; i++) {
    const group = commitGroups[i];
    console.log(`\nCreating Commit ${i + 1}/${commitGroups.length}: ${group.message.split('\n')[0]}`);

    for (const rel of group.files) {
      const normalizedRel = rel.replace(/\//g, path.sep);
      if (fs.existsSync(path.join(TARGET_DIR, normalizedRel))) {
        await git.add({ fs, dir: TARGET_DIR, filepath: rel.replace(/\\/g, '/') });
      } else {
        console.warn(`Warning: File not found for commit ${i + 1}: ${rel}`);
      }
    }

    const sha = await git.commit({
      fs,
      dir: TARGET_DIR,
      message: group.message,
      author: {
        ...author,
        timestamp: Math.floor(Date.now() / 1000) - (commitGroups.length - i) * 60,
      },
    });

    console.log(`✓ Commit created: ${sha.substring(0, 7)}`);
  }

  // Verify commit log
  const commits = await git.log({ fs, dir: TARGET_DIR, depth: 10 });
  console.log('\n--- Git Commit History in Step 1 Repository ---');
  commits.forEach((c) => {
    console.log(`* ${c.oid.substring(0, 7)} - ${c.commit.message.split('\n')[0]} (${new Date(c.commit.author.timestamp * 1000).toLocaleTimeString()})`);
  });

  console.log('\n🎉 Step 1 Git repository built successfully with 5 atomic commits!');
}

buildStep1().catch((err) => {
  console.error('Error building step 1 repo:', err);
  process.exit(1);
});
